import React from 'react';
import { GraduationCap, Shield, FlaskConical, CheckCircle2, Terminal } from 'lucide-react';

interface FooterProps {
  onNavigate: (view: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  return (
    <footer className="border-t border-slate-800 bg-slate-950 text-slate-400 text-xs mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 pb-8 border-b border-slate-800/80">
          {/* Brand & Project Info */}
          <div className="md:col-span-2 space-y-3">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-cyan-600 flex items-center justify-center text-white font-bold">
                <GraduationCap className="w-4 h-4" />
              </div>
              <span className="font-bold text-white text-base">
                Course<span className="text-cyan-400">Reserve</span>
              </span>
              <span className="text-[10px] uppercase font-bold tracking-wider px-1.5 py-0.5 rounded bg-blue-500/15 text-blue-300 border border-blue-500/30">
                SE Lab Project
              </span>
            </div>
            <p className="text-slate-400 text-xs leading-relaxed max-w-md">
              College Software Engineering Laboratory Project — Online Course Reservation System.
              Engineered with atomic concurrency locking, server-authoritative role-based access, and an end-to-end verification and testing module.
            </p>
            <div className="flex items-center gap-3 pt-1">
              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-[11px] font-medium">
                <CheckCircle2 className="w-3.5 h-3.5" /> Backend Operational & Mutex Guard Active
              </span>
            </div>
          </div>

          {/* Quick Navigation */}
          <div>
            <h4 className="text-slate-200 font-semibold text-xs uppercase tracking-wider mb-3">
              Application Modules
            </h4>
            <ul className="space-y-2">
              <li>
                <button
                  onClick={() => onNavigate('catalogue')}
                  className="hover:text-cyan-400 transition-colors"
                >
                  Course Catalogue
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('student-dashboard')}
                  className="hover:text-cyan-400 transition-colors"
                >
                  Student Portal & Reservations
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('admin-dashboard')}
                  className="hover:text-cyan-400 transition-colors"
                >
                  Administrator Operations
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('testing-dashboard')}
                  className="hover:text-amber-400 transition-colors text-amber-400/90 font-medium"
                >
                  Software Testing Dashboard
                </button>
              </li>
            </ul>
          </div>

          {/* Technical Specifications */}
          <div>
            <h4 className="text-slate-200 font-semibold text-xs uppercase tracking-wider mb-3">
              Tech Stack & Lab Spec
            </h4>
            <div className="flex flex-wrap gap-1.5">
              <span className="px-2 py-0.5 rounded bg-slate-900 border border-slate-800 text-[11px] text-slate-300">
                React 19
              </span>
              <span className="px-2 py-0.5 rounded bg-slate-900 border border-slate-800 text-[11px] text-slate-300">
                TypeScript
              </span>
              <span className="px-2 py-0.5 rounded bg-slate-900 border border-slate-800 text-[11px] text-slate-300">
                Tailwind CSS
              </span>
              <span className="px-2 py-0.5 rounded bg-slate-900 border border-slate-800 text-[11px] text-slate-300">
                Node / Express
              </span>
              <span className="px-2 py-0.5 rounded bg-slate-900 border border-slate-800 text-[11px] text-slate-300">
                ACID Mutex
              </span>
              <span className="px-2 py-0.5 rounded bg-slate-900 border border-slate-800 text-[11px] text-slate-300">
                Vitest
              </span>
              <span className="px-2 py-0.5 rounded bg-slate-900 border border-slate-800 text-[11px] text-slate-300">
                HMAC-SHA256 Auth
              </span>
            </div>
            <div className="mt-3 text-[11px] text-slate-500">
              Department of Computer Science & Software Engineering
            </div>
          </div>
        </div>

        <div className="pt-6 flex flex-col sm:flex-row items-center justify-between gap-3 text-slate-500">
          <div>
            © 2026 CourseReserve. College Software Engineering Laboratory Assignment.
          </div>
          <div className="flex items-center gap-4 text-[11px]">
            <span className="flex items-center gap-1 text-slate-400">
              <Terminal className="w-3.5 h-3.5 text-cyan-400" /> Free-Tier Standard Architecture
            </span>
            <span>•</span>
            <span className="flex items-center gap-1 text-slate-400">
              <Shield className="w-3.5 h-3.5 text-blue-400" /> Server-Authoritative RBAC
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
};
