import React, { useState } from 'react';
import { 
  GraduationCap, 
  BookOpen, 
  CalendarCheck, 
  User as UserIcon, 
  LogOut, 
  ShieldCheck, 
  FlaskConical, 
  Menu, 
  X, 
  ChevronDown, 
  LayoutDashboard,
  Layers,
  FileSpreadsheet
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useToast } from './Toast';

interface NavbarProps {
  currentView: string;
  onNavigate: (view: string, params?: any) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ currentView, onNavigate }) => {
  const { user, isAuthenticated, isAdmin, isStudent, logout, quickLogin } = useAuth();
  const { success } = useToast();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [demoMenuOpen, setDemoMenuOpen] = useState(false);

  const handleQuickSwitch = async (role: 'admin' | 'student1' | 'student2') => {
    try {
      const u = await quickLogin(role);
      setDemoMenuOpen(false);
      setMobileMenuOpen(false);
      success(`Switched session to ${u.fullName} (${u.role.toUpperCase()})`);
      if (u.role === 'admin') {
        onNavigate('admin-dashboard');
      } else {
        onNavigate('student-dashboard');
      }
    } catch {
      // Handled
    }
  };

  const navItemClass = (view: string) => `
    px-3.5 py-2 rounded-lg text-sm font-medium transition-all duration-150 flex items-center gap-1.5
    ${currentView === view 
      ? 'bg-cyan-500/15 text-cyan-400 font-semibold border border-cyan-500/30' 
      : 'text-slate-300 hover:text-white hover:bg-slate-800/60'}
  `;

  return (
    <header className="sticky top-0 z-40 w-full border-b border-slate-800/80 bg-slate-950/90 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => onNavigate('landing')}
              className="flex items-center gap-2.5 text-left group"
            >
              <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-600 to-blue-600 flex items-center justify-center shadow-lg shadow-cyan-900/30 group-hover:scale-105 transition-transform">
                <GraduationCap className="w-6 h-6 text-white" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-extrabold text-lg sm:text-xl tracking-tight text-white">
                    Course<span className="text-cyan-400">Reserve</span>
                  </span>
                  <span className="hidden sm:inline-block text-[10px] uppercase font-bold tracking-wider px-1.5 py-0.5 rounded bg-blue-500/15 text-blue-300 border border-blue-500/30">
                    SE Lab
                  </span>
                </div>
                <p className="text-[11px] text-slate-400 leading-none hidden sm:block">
                  Online Course Reservation System
                </p>
              </div>
            </button>
          </div>

          {/* Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center gap-1">
            <button onClick={() => onNavigate('catalogue')} className={navItemClass('catalogue')}>
              <BookOpen className="w-4 h-4" />
              Course Catalogue
            </button>

            {isStudent && (
              <>
                <button onClick={() => onNavigate('student-dashboard')} className={navItemClass('student-dashboard')}>
                  <LayoutDashboard className="w-4 h-4" />
                  Dashboard
                </button>
                <button onClick={() => onNavigate('my-reservations')} className={navItemClass('my-reservations')}>
                  <CalendarCheck className="w-4 h-4" />
                  My Reservations
                </button>
              </>
            )}

            {isAdmin && (
              <>
                <button onClick={() => onNavigate('admin-dashboard')} className={navItemClass('admin-dashboard')}>
                  <LayoutDashboard className="w-4 h-4" />
                  Admin Dashboard
                </button>
                <button onClick={() => onNavigate('admin-courses')} className={navItemClass('admin-courses')}>
                  <Layers className="w-4 h-4" />
                  Manage Courses
                </button>
                <button onClick={() => onNavigate('admin-reservations')} className={navItemClass('admin-reservations')}>
                  <CalendarCheck className="w-4 h-4" />
                  Reservations
                </button>
                <button onClick={() => onNavigate('admin-reports')} className={navItemClass('admin-reports')}>
                  <FileSpreadsheet className="w-4 h-4" />
                  Reports
                </button>
              </>
            )}

            {/* Always accessible Testing Module for Lab Evaluation */}
            <button
              onClick={() => onNavigate('testing-dashboard')}
              className={`px-3.5 py-2 rounded-lg text-sm font-semibold transition-all duration-150 flex items-center gap-1.5 ${
                currentView === 'testing-dashboard'
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                  : 'text-amber-400/90 hover:text-amber-300 hover:bg-amber-500/10'
              }`}
            >
              <FlaskConical className="w-4 h-4" />
              Testing Module
            </button>
          </nav>

          {/* Right Action Bar */}
          <div className="hidden lg:flex items-center gap-3">
            {/* Quick Demo Account Switcher */}
            <div className="relative">
              <button
                onClick={() => setDemoMenuOpen(!demoMenuOpen)}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg bg-slate-800/80 hover:bg-slate-700/80 text-slate-300 border border-slate-700 transition-colors"
                title="Switch demo role without manual typing"
              >
                <span>Demo Switcher</span>
                <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
              </button>

              {demoMenuOpen && (
                <div
                  className="absolute right-0 mt-2 w-64 rounded-xl bg-slate-900 border border-slate-700 shadow-2xl py-2 z-50 animate-in fade-in zoom-in-95"
                  onMouseLeave={() => setDemoMenuOpen(false)}
                >
                  <div className="px-3 py-1.5 text-[11px] font-semibold text-slate-400 uppercase tracking-wider border-b border-slate-800">
                    Switch Test Account
                  </div>
                  <button
                    onClick={() => handleQuickSwitch('student1')}
                    className="w-full text-left px-3 py-2 text-xs text-slate-200 hover:bg-slate-800 hover:text-cyan-400 flex items-center justify-between"
                  >
                    <div>
                      <div className="font-medium">Alex Rivera</div>
                      <div className="text-[10px] text-slate-400">student@college.edu</div>
                    </div>
                    <span className="text-[10px] bg-cyan-950 text-cyan-400 border border-cyan-800 px-1.5 py-0.5 rounded">Student</span>
                  </button>
                  <button
                    onClick={() => handleQuickSwitch('student2')}
                    className="w-full text-left px-3 py-2 text-xs text-slate-200 hover:bg-slate-800 hover:text-cyan-400 flex items-center justify-between"
                  >
                    <div>
                      <div className="font-medium">Sarah Chen</div>
                      <div className="text-[10px] text-slate-400">sarah.chen@college.edu</div>
                    </div>
                    <span className="text-[10px] bg-cyan-950 text-cyan-400 border border-cyan-800 px-1.5 py-0.5 rounded">Student</span>
                  </button>
                  <button
                    onClick={() => handleQuickSwitch('admin')}
                    className="w-full text-left px-3 py-2 text-xs text-slate-200 hover:bg-slate-800 hover:text-amber-400 flex items-center justify-between"
                  >
                    <div>
                      <div className="font-medium">Prof. Katherine Vance</div>
                      <div className="text-[10px] text-slate-400">admin@college.edu</div>
                    </div>
                    <span className="text-[10px] bg-amber-950 text-amber-400 border border-amber-800 px-1.5 py-0.5 rounded">Admin</span>
                  </button>
                </div>
              )}
            </div>

            {/* User Profile / Auth State */}
            {isAuthenticated ? (
              <div className="flex items-center gap-3 pl-2 border-l border-slate-800">
                <button
                  onClick={() => onNavigate(isAdmin ? 'admin-dashboard' : 'student-profile')}
                  className="flex items-center gap-2 group text-left"
                >
                  <div className={`w-8 h-8 rounded-lg flex items-center justify-center font-bold text-xs ${
                    isAdmin ? 'bg-amber-500 text-slate-950' : 'bg-cyan-500 text-slate-950'
                  }`}>
                    {user?.fullName.charAt(0) || 'U'}
                  </div>
                  <div className="leading-tight">
                    <div className="text-xs font-semibold text-white group-hover:text-cyan-400 transition-colors">
                      {user?.fullName.split(' ')[0]}
                    </div>
                    <div className="text-[10px] text-slate-400 flex items-center gap-1">
                      {isAdmin ? (
                        <span className="text-amber-400 font-medium flex items-center gap-0.5">
                          <ShieldCheck className="w-2.5 h-2.5" /> Admin
                        </span>
                      ) : (
                        <span className="text-cyan-400">Student</span>
                      )}
                    </div>
                  </div>
                </button>

                <button
                  onClick={() => {
                    logout();
                    onNavigate('landing');
                  }}
                  className="p-1.5 text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 rounded-lg transition-colors"
                  title="Sign out"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <button
                  onClick={() => onNavigate('login')}
                  className="px-3.5 py-1.5 text-xs sm:text-sm font-medium text-slate-200 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
                >
                  Log in
                </button>
                <button
                  onClick={() => onNavigate('register')}
                  className="px-4 py-1.5 text-xs sm:text-sm font-semibold text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded-lg shadow-sm transition-all"
                >
                  Register
                </button>
              </div>
            )}
          </div>

          {/* Mobile Menu Button */}
          <div className="flex lg:hidden items-center gap-2">
            <button
              onClick={() => onNavigate('testing-dashboard')}
              className="p-2 text-amber-400 rounded-lg hover:bg-slate-800"
              title="Testing Module"
            >
              <FlaskConical className="w-5 h-5" />
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-b border-slate-800 bg-slate-950/98 px-4 pt-3 pb-6 space-y-3">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="text-xs text-slate-400 font-medium">Quick Role Demo Switch:</div>
            <div className="flex items-center gap-1.5">
              <button
                onClick={() => handleQuickSwitch('student1')}
                className="px-2 py-1 text-[11px] rounded bg-cyan-950 text-cyan-400 border border-cyan-800 font-medium"
              >
                Alex (Std)
              </button>
              <button
                onClick={() => handleQuickSwitch('admin')}
                className="px-2 py-1 text-[11px] rounded bg-amber-950 text-amber-400 border border-amber-800 font-medium"
              >
                Prof. Vance (Admin)
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 gap-1">
            <button
              onClick={() => { onNavigate('catalogue'); setMobileMenuOpen(false); }}
              className="w-full text-left px-3 py-2 text-sm text-slate-200 hover:bg-slate-800 rounded-lg flex items-center gap-2"
            >
              <BookOpen className="w-4 h-4 text-cyan-400" /> Course Catalogue
            </button>

            {isStudent && (
              <>
                <button
                  onClick={() => { onNavigate('student-dashboard'); setMobileMenuOpen(false); }}
                  className="w-full text-left px-3 py-2 text-sm text-slate-200 hover:bg-slate-800 rounded-lg flex items-center gap-2"
                >
                  <LayoutDashboard className="w-4 h-4 text-cyan-400" /> Student Dashboard
                </button>
                <button
                  onClick={() => { onNavigate('my-reservations'); setMobileMenuOpen(false); }}
                  className="w-full text-left px-3 py-2 text-sm text-slate-200 hover:bg-slate-800 rounded-lg flex items-center gap-2"
                >
                  <CalendarCheck className="w-4 h-4 text-cyan-400" /> My Reservations
                </button>
                <button
                  onClick={() => { onNavigate('student-profile'); setMobileMenuOpen(false); }}
                  className="w-full text-left px-3 py-2 text-sm text-slate-200 hover:bg-slate-800 rounded-lg flex items-center gap-2"
                >
                  <UserIcon className="w-4 h-4 text-cyan-400" /> Student Profile
                </button>
              </>
            )}

            {isAdmin && (
              <>
                <button
                  onClick={() => { onNavigate('admin-dashboard'); setMobileMenuOpen(false); }}
                  className="w-full text-left px-3 py-2 text-sm text-slate-200 hover:bg-slate-800 rounded-lg flex items-center gap-2"
                >
                  <LayoutDashboard className="w-4 h-4 text-amber-400" /> Admin Dashboard
                </button>
                <button
                  onClick={() => { onNavigate('admin-courses'); setMobileMenuOpen(false); }}
                  className="w-full text-left px-3 py-2 text-sm text-slate-200 hover:bg-slate-800 rounded-lg flex items-center gap-2"
                >
                  <Layers className="w-4 h-4 text-amber-400" /> Manage Courses
                </button>
                <button
                  onClick={() => { onNavigate('admin-reservations'); setMobileMenuOpen(false); }}
                  className="w-full text-left px-3 py-2 text-sm text-slate-200 hover:bg-slate-800 rounded-lg flex items-center gap-2"
                >
                  <CalendarCheck className="w-4 h-4 text-amber-400" /> Student Reservations
                </button>
                <button
                  onClick={() => { onNavigate('admin-reports'); setMobileMenuOpen(false); }}
                  className="w-full text-left px-3 py-2 text-sm text-slate-200 hover:bg-slate-800 rounded-lg flex items-center gap-2"
                >
                  <FileSpreadsheet className="w-4 h-4 text-amber-400" /> Reports & Analytics
                </button>
              </>
            )}

            <button
              onClick={() => { onNavigate('testing-dashboard'); setMobileMenuOpen(false); }}
              className="w-full text-left px-3 py-2 text-sm text-amber-300 font-semibold bg-amber-500/10 hover:bg-amber-500/20 rounded-lg flex items-center gap-2"
            >
              <FlaskConical className="w-4 h-4 text-amber-400" /> Software Testing Lab Module
            </button>
          </div>

          <div className="pt-3 border-t border-slate-800">
            {isAuthenticated ? (
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-sm font-semibold text-white">{user?.fullName}</div>
                  <div className="text-xs text-slate-400">{user?.email}</div>
                </div>
                <button
                  onClick={() => { logout(); setMobileMenuOpen(false); onNavigate('landing'); }}
                  className="px-3 py-1.5 text-xs text-rose-400 border border-rose-800 rounded-lg hover:bg-rose-950"
                >
                  Sign out
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => { onNavigate('login'); setMobileMenuOpen(false); }}
                  className="w-full py-2 text-sm font-medium text-slate-200 bg-slate-800 rounded-lg text-center"
                >
                  Log In
                </button>
                <button
                  onClick={() => { onNavigate('register'); setMobileMenuOpen(false); }}
                  className="w-full py-2 text-sm font-semibold text-slate-950 bg-cyan-400 rounded-lg text-center"
                >
                  Register
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </header>
  );
};
