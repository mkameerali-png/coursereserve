import React from 'react';
import { 
  Clock, 
  Calendar, 
  User as UserIcon, 
  Users, 
  ArrowRight, 
  CheckCircle, 
  AlertTriangle,
  Lock
} from 'lucide-react';
import { Course } from '../types/index';

interface CourseCardProps {
  course: Course;
  onSelect: (course: Course) => void;
  onReserve?: (course: Course) => void;
  isReservedByStudent?: boolean;
}

export const CourseCard: React.FC<CourseCardProps> = ({
  course,
  onSelect,
  onReserve,
  isReservedByStudent = false,
}) => {
  const percentOccupied = Math.round(
    ((course.capacity - course.availableSeats) / course.capacity) * 100
  );

  const isFull = course.availableSeats <= 0;
  const isOneSeatLeft = course.availableSeats === 1;
  const isUnpublished = course.status !== 'published';

  return (
    <div className="group relative flex flex-col justify-between bg-slate-900/90 border border-slate-800 hover:border-cyan-500/50 rounded-2xl p-5 sm:p-6 transition-all duration-200 hover:shadow-xl hover:shadow-cyan-950/20">
      <div>
        {/* Top Badges */}
        <div className="flex items-center justify-between gap-2 mb-3">
          <span className="text-xs font-bold text-cyan-400 bg-cyan-950/80 border border-cyan-800/80 px-2.5 py-1 rounded-md tracking-wider">
            {course.code}
          </span>

          <div className="flex items-center gap-1.5">
            {isUnpublished && (
              <span className="text-[11px] font-semibold text-slate-400 bg-slate-800 px-2 py-0.5 rounded-full border border-slate-700">
                Draft / Unpublished
              </span>
            )}

            {isFull ? (
              <span className="text-[11px] font-bold text-rose-300 bg-rose-950/80 border border-rose-800 px-2 py-0.5 rounded-full flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-rose-500 animate-pulse" />
                Course Full (0 Seats)
              </span>
            ) : isOneSeatLeft ? (
              <span className="text-[11px] font-bold text-amber-300 bg-amber-950/80 border border-amber-800 px-2 py-0.5 rounded-full flex items-center gap-1">
                <AlertTriangle className="w-3 h-3 text-amber-400" />
                Only 1 Seat Left!
              </span>
            ) : (
              <span className="text-[11px] font-semibold text-emerald-300 bg-emerald-950/60 border border-emerald-800/60 px-2 py-0.5 rounded-full">
                {course.availableSeats} of {course.capacity} Seats Available
              </span>
            )}
          </div>
        </div>

        {/* Title and Category */}
        <h3
          onClick={() => onSelect(course)}
          className="text-lg font-bold text-white group-hover:text-cyan-400 transition-colors cursor-pointer line-clamp-1"
        >
          {course.title}
        </h3>
        <p className="text-xs text-cyan-300/80 font-medium mt-0.5 mb-2.5">{course.category}</p>

        {/* Description */}
        <p className="text-xs text-slate-400 line-clamp-2 leading-relaxed mb-4">
          {course.description}
        </p>

        {/* Metadata Grid */}
        <div className="grid grid-cols-2 gap-2 text-xs text-slate-300 mb-4 bg-slate-950/60 p-3 rounded-xl border border-slate-800/80">
          <div className="flex items-center gap-1.5">
            <UserIcon className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
            <span className="truncate">{course.instructor}</span>
          </div>
          <div className="flex items-center gap-1.5">
            <Clock className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
            <span>{course.duration}</span>
          </div>
          <div className="flex items-center gap-1.5 col-span-2">
            <Calendar className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
            <span className="truncate">{course.schedule}</span>
          </div>
        </div>

        {/* Capacity Progress Bar */}
        <div className="space-y-1 mb-5">
          <div className="flex justify-between text-[11px] font-medium text-slate-400">
            <span className="flex items-center gap-1">
              <Users className="w-3 h-3 text-slate-400" /> Enrollment Capacity
            </span>
            <span>
              {course.capacity - course.availableSeats}/{course.capacity} ({percentOccupied}%)
            </span>
          </div>
          <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
            <div
              className={`h-full transition-all duration-500 rounded-full ${
                isFull
                  ? 'bg-rose-500'
                  : isOneSeatLeft
                  ? 'bg-amber-400'
                  : percentOccupied > 70
                  ? 'bg-blue-400'
                  : 'bg-cyan-500'
              }`}
              style={{ width: `${percentOccupied}%` }}
            />
          </div>
        </div>
      </div>

      {/* Footer / Action */}
      <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between gap-3">
        <div>
          <div className="text-[10px] text-slate-400 uppercase font-semibold">Course Fee</div>
          <div className="text-base font-extrabold text-white">
            ${course.fee} <span className="text-[11px] font-normal text-slate-400">USD</span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => onSelect(course)}
            className="px-3 py-1.5 text-xs font-semibold text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors"
          >
            Details
          </button>

          {isReservedByStudent ? (
            <span className="px-3 py-1.5 text-xs font-semibold text-emerald-400 bg-emerald-950/60 border border-emerald-800/60 rounded-lg flex items-center gap-1">
              <CheckCircle className="w-3.5 h-3.5" /> Enrolled
            </span>
          ) : isFull ? (
            <button
              disabled
              className="px-3 py-1.5 text-xs font-semibold text-slate-500 bg-slate-800/60 border border-slate-700/50 rounded-lg cursor-not-allowed flex items-center gap-1"
            >
              <Lock className="w-3 h-3" /> Full
            </button>
          ) : onReserve ? (
            <button
              onClick={() => onReserve(course)}
              className="px-3.5 py-1.5 text-xs font-bold text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded-lg transition-all flex items-center gap-1 shadow-sm hover:shadow-cyan-500/20"
            >
              Reserve <ArrowRight className="w-3.5 h-3.5" />
            </button>
          ) : null}
        </div>
      </div>
    </div>
  );
};
