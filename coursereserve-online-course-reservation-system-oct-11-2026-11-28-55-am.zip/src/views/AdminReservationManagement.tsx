import React, { useState, useEffect } from 'react';
import { 
  CalendarCheck, 
  Search, 
  Filter, 
  Download, 
  RotateCcw, 
  CheckCircle2, 
  XCircle, 
  ArrowLeft, 
  User, 
  Copy,
  AlertTriangle
} from 'lucide-react';
import { Reservation } from '../types/index';
import { api } from '../services/api';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../components/Toast';
import { Modal } from '../components/Modal';

interface AdminReservationManagementProps {
  onNavigate: (view: string, params?: any) => void;
}

export const AdminReservationManagement: React.FC<AdminReservationManagementProps> = ({ onNavigate }) => {
  const { isAdmin } = useAuth();
  const { success, error } = useToast();

  const [reservations, setReservations] = useState<Reservation[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');

  // Cancel Modal State
  const [cancelModalOpen, setCancelModalOpen] = useState(false);
  const [selectedRes, setSelectedRes] = useState<Reservation | null>(null);
  const [adminReason, setAdminReason] = useState('Administrative reassignment / prerequisite non-compliance');
  const [isCancelling, setIsCancelling] = useState(false);

  const fetchReservations = async () => {
    setLoading(true);
    try {
      const res = await api.reservations.getAll({
        search: searchTerm,
        status: statusFilter === 'all' ? undefined : statusFilter,
      });
      setReservations(res.reservations);
    } catch (err: any) {
      error(err.message || 'Failed to fetch reservations');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isAdmin) {
      fetchReservations();
    }
  }, [isAdmin, searchTerm, statusFilter]);

  const handleOpenCancelModal = (res: Reservation) => {
    setSelectedRes(res);
    setAdminReason('Administrative reassignment / prerequisite non-compliance');
    setCancelModalOpen(true);
  };

  const handleAdminCancel = async () => {
    if (!selectedRes) return;
    setIsCancelling(true);
    try {
      await api.reservations.cancel(selectedRes.id, adminReason);
      success(`Admin cancelled reservation ${selectedRes.confirmationCode}. Seat restored!`);
      setCancelModalOpen(false);
      setSelectedRes(null);
      fetchReservations();
    } catch (err: any) {
      error(err.message || 'Cancellation error');
    } finally {
      setIsCancelling(false);
    }
  };

  const handleExportCsv = () => {
    window.location.href = '/api/reservations/export';
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-6">
        <div>
          <button
            onClick={() => onNavigate('admin-dashboard')}
            className="inline-flex items-center gap-1.5 text-xs text-slate-400 hover:text-white mb-2 transition-colors"
          >
            <ArrowLeft className="w-3.5 h-3.5" /> Back to Admin Dashboard
          </button>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            Student Reservation Records
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Audit, verify, and administratively manage student course reservations with atomic capacity tracking.
          </p>
        </div>

        <button
          onClick={handleExportCsv}
          className="self-start sm:self-auto px-4 py-2 text-xs font-bold text-slate-950 bg-emerald-400 hover:bg-emerald-300 rounded-xl transition-all shadow-md shadow-emerald-500/20 flex items-center gap-1.5"
        >
          <Download className="w-4 h-4" /> Export All as CSV
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 sm:p-5 flex flex-col sm:flex-row items-center justify-between gap-4">
        {/* Status Filters */}
        <div className="flex items-center gap-1.5 bg-slate-950 p-1 rounded-xl border border-slate-800 w-full sm:w-auto text-xs">
          {['all', 'active', 'completed', 'cancelled'].map((tab) => (
            <button
              key={tab}
              onClick={() => setStatusFilter(tab)}
              className={`flex-1 sm:flex-initial px-3.5 py-1.5 rounded-lg capitalize font-medium transition-all ${
                statusFilter === tab
                  ? 'bg-amber-400 text-slate-950 font-bold shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>

        {/* Search Input */}
        <div className="relative w-full sm:w-80">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            placeholder="Search student, email, confirmation code..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3 py-2 bg-slate-950 border border-slate-800 focus:border-amber-500 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none"
          />
        </div>
      </div>

      {/* Reservations Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950 text-slate-400 uppercase tracking-wider font-semibold border-b border-slate-800">
              <tr>
                <th className="px-5 py-3.5">Confirmation Code</th>
                <th className="px-5 py-3.5">Student Details</th>
                <th className="px-5 py-3.5">Course Enrolled</th>
                <th className="px-5 py-3.5">Fee</th>
                <th className="px-5 py-3.5">Reserved Timestamp</th>
                <th className="px-5 py-3.5">Status</th>
                <th className="px-5 py-3.5 text-right">Admin Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80">
              {loading ? (
                <tr>
                  <td colSpan={7} className="px-5 py-8 text-center text-slate-500">
                    Loading reservation records...
                  </td>
                </tr>
              ) : reservations.length === 0 ? (
                <tr>
                  <td colSpan={7} className="px-5 py-12 text-center text-slate-500">
                    No reservations found matching search criteria.
                  </td>
                </tr>
              ) : (
                reservations.map((r) => {
                  const isActive = r.reservationStatus === 'active';
                  const isCancelled = r.reservationStatus === 'cancelled';

                  return (
                    <tr key={r.id} className="hover:bg-slate-800/40 transition-colors">
                      <td className="px-5 py-4">
                        <span className="font-mono font-bold text-cyan-400 bg-cyan-950/80 px-2 py-0.5 rounded border border-cyan-800">
                          {r.confirmationCode}
                        </span>
                      </td>

                      <td className="px-5 py-4">
                        <div className="font-semibold text-white">{r.studentName || 'Student User'}</div>
                        <div className="text-[11px] text-slate-400 font-mono">{r.studentEmail}</div>
                      </td>

                      <td className="px-5 py-4">
                        <div className="font-semibold text-white">
                          <span className="text-cyan-400 font-mono mr-1.5">{r.courseCode}</span>
                          {r.courseTitle}
                        </div>
                        <div className="text-[11px] text-slate-400">{r.courseCategory}</div>
                      </td>

                      <td className="px-5 py-4 font-bold text-white">
                        ${r.courseFee || 0}
                      </td>

                      <td className="px-5 py-4 text-slate-300">
                        <div>{new Date(r.reservedAt).toLocaleDateString()}</div>
                        <div className="text-[10px] text-slate-500">
                          {new Date(r.reservedAt).toLocaleTimeString()}
                        </div>
                      </td>

                      <td className="px-5 py-4">
                        <span
                          className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold ${
                            isActive
                              ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                              : isCancelled
                              ? 'bg-rose-950 text-rose-300 border border-rose-800'
                              : 'bg-blue-950 text-blue-300 border border-blue-800'
                          }`}
                        >
                          {r.reservationStatus}
                        </span>
                        {isCancelled && r.cancellationReason && (
                          <div className="text-[10px] text-slate-400 mt-1 max-w-xs truncate" title={r.cancellationReason}>
                            Reason: {r.cancellationReason}
                          </div>
                        )}
                      </td>

                      <td className="px-5 py-4 text-right">
                        {isActive ? (
                          <button
                            onClick={() => handleOpenCancelModal(r)}
                            className="px-2.5 py-1 text-[11px] font-semibold text-rose-400 hover:text-white bg-rose-950/40 hover:bg-rose-900/60 border border-rose-800/60 rounded-lg transition-colors inline-flex items-center gap-1"
                          >
                            <RotateCcw className="w-3 h-3" /> Cancel & Free Seat
                          </button>
                        ) : (
                          <span className="text-[11px] text-slate-500">—</span>
                        )}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Admin Cancellation Modal */}
      <Modal
        isOpen={cancelModalOpen}
        onClose={() => setCancelModalOpen(false)}
        title="Admin Override: Cancel Student Reservation"
        subtitle={`Reservation: ${selectedRes?.confirmationCode} for ${selectedRes?.studentName}`}
      >
        <div className="space-y-4 text-xs">
          <div className="p-3.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-300 flex items-start gap-2">
            <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
            <div>
              <strong>Administrative Action:</strong> Cancelling this reservation will immediately restore 1 seat to course capacity and write an immutable audit log entry.
            </div>
          </div>

          <div className="space-y-1">
            <label className="text-slate-300 font-semibold">Administrative Reason / Justification *</label>
            <textarea
              rows={3}
              value={adminReason}
              onChange={(e) => setAdminReason(e.target.value)}
              className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white focus:outline-none focus:border-amber-500"
            />
          </div>

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
            <button
              onClick={() => setCancelModalOpen(false)}
              className="px-4 py-2 text-xs font-semibold text-slate-300 hover:text-white bg-slate-800 rounded-lg hover:bg-slate-700"
            >
              Close
            </button>
            <button
              onClick={handleAdminCancel}
              disabled={isCancelling}
              className="px-4 py-2 text-xs font-bold text-white bg-rose-600 hover:bg-rose-500 disabled:opacity-50 rounded-lg transition-colors flex items-center gap-1"
            >
              {isCancelling ? 'Processing...' : 'Execute Cancellation'}
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
};
