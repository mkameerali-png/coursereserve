import React, { useEffect, useState } from 'react';
import { 
  GraduationCap, 
  ArrowRight, 
  ShieldCheck, 
  Zap, 
  FlaskConical, 
  CheckCircle2, 
  Users, 
  BookOpen, 
  Lock,
  Layers,
  Sparkles
} from 'lucide-react';
import { api } from '../services/api';
import { Course } from '../types/index';
import { CourseCard } from '../components/CourseCard';
import { useAuth } from '../context/AuthContext';

interface LandingPageProps {
  onNavigate: (view: string, params?: any) => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({ onNavigate }) => {
  const { quickLogin } = useAuth();
  const [featuredCourses, setFeaturedCourses] = useState<Course[]>([]);
  const [stats, setStats] = useState({
    courses: 9,
    students: 2,
    passRate: 100,
    testsCount: 18,
  });

  useEffect(() => {
    async function loadData() {
      try {
        const res = await api.courses.getAll();
        setFeaturedCourses(res.courses.slice(0, 3));
      } catch {
        // Fallback
      }
    }
    loadData();
  }, []);

  return (
    <div className="space-y-16 pb-16">
      {/* Hero Section */}
      <section className="relative overflow-hidden pt-12 pb-16 md:pt-20 md:pb-24 border-b border-slate-800/80 bg-gradient-to-b from-slate-900/60 via-slate-950 to-slate-950">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_top,_var(--tw-gradient-stops))] from-cyan-900/20 via-slate-950/0 to-transparent pointer-events-none" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-cyan-950/80 border border-cyan-800/60 text-cyan-300 text-xs font-semibold mb-6 shadow-sm">
            <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
            <span>College Software Engineering Laboratory Project</span>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
            <div className="lg:col-span-7 space-y-6">
              <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-extrabold text-white tracking-tight leading-[1.1]">
                Online Course <br />
                <span className="bg-gradient-to-r from-cyan-400 via-blue-400 to-indigo-400 bg-clip-text text-transparent">
                  Reservation System
                </span>
              </h1>

              <p className="text-base sm:text-lg text-slate-300 leading-relaxed max-w-2xl font-normal">
                Engineered for college academic registration. Features atomic database concurrency,
                zero-overbooking guarantees, server-authoritative role-based access, and a full Software Engineering laboratory testing dashboard.
              </p>

              {/* Action Buttons */}
              <div className="flex flex-wrap items-center gap-3 pt-2">
                <button
                  onClick={() => onNavigate('catalogue')}
                  className="px-6 py-3 rounded-xl font-bold text-sm text-slate-950 bg-cyan-400 hover:bg-cyan-300 transition-all flex items-center gap-2 shadow-lg shadow-cyan-500/20 hover:scale-[1.02]"
                >
                  <BookOpen className="w-4 h-4" />
                  Browse Course Catalogue
                  <ArrowRight className="w-4 h-4" />
                </button>

                <button
                  onClick={() => onNavigate('testing-dashboard')}
                  className="px-5 py-3 rounded-xl font-semibold text-sm text-amber-300 bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 transition-all flex items-center gap-2"
                >
                  <FlaskConical className="w-4 h-4 text-amber-400" />
                  Software Testing Lab
                </button>
              </div>

              {/* Verified Features Pill Bar */}
              <div className="flex flex-wrap items-center gap-4 pt-4 text-xs text-slate-400 font-medium">
                <span className="flex items-center gap-1.5 text-slate-300">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" /> ACID Mutex Protected
                </span>
                <span className="flex items-center gap-1.5 text-slate-300">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" /> Zero Negative Seats
                </span>
                <span className="flex items-center gap-1.5 text-slate-300">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" /> 18 Automated Test Cases
                </span>
              </div>
            </div>

            {/* Quick Demo Credentials Card */}
            <div className="lg:col-span-5">
              <div className="bg-slate-900/90 border border-slate-700/80 rounded-2xl p-6 shadow-2xl backdrop-blur-sm space-y-4">
                <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                  <div>
                    <h3 className="text-base font-bold text-white flex items-center gap-2">
                      <Lock className="w-4 h-4 text-cyan-400" /> Instant Lab Access
                    </h3>
                    <p className="text-xs text-slate-400">One-click evaluation profiles</p>
                  </div>
                  <span className="text-[10px] font-mono bg-cyan-950 text-cyan-400 px-2 py-0.5 rounded border border-cyan-800">
                    Pre-seeded
                  </span>
                </div>

                <div className="space-y-3">
                  {/* Student 1 */}
                  <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800 hover:border-cyan-500/40 transition-colors flex items-center justify-between">
                    <div>
                      <div className="text-xs font-semibold text-white flex items-center gap-1.5">
                        <Users className="w-3.5 h-3.5 text-cyan-400" /> Alex Rivera (Student)
                      </div>
                      <div className="text-[11px] text-slate-400 font-mono">student@college.edu</div>
                    </div>
                    <button
                      onClick={async () => {
                        await quickLogin('student1');
                        onNavigate('student-dashboard');
                      }}
                      className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-cyan-400 text-slate-950 hover:bg-cyan-300 transition-colors"
                    >
                      Login
                    </button>
                  </div>

                  {/* Student 2 */}
                  <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800 hover:border-cyan-500/40 transition-colors flex items-center justify-between">
                    <div>
                      <div className="text-xs font-semibold text-white flex items-center gap-1.5">
                        <Users className="w-3.5 h-3.5 text-cyan-400" /> Sarah Chen (Student)
                      </div>
                      <div className="text-[11px] text-slate-400 font-mono">sarah.chen@college.edu</div>
                    </div>
                    <button
                      onClick={async () => {
                        await quickLogin('student2');
                        onNavigate('student-dashboard');
                      }}
                      className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-cyan-400 text-slate-950 hover:bg-cyan-300 transition-colors"
                    >
                      Login
                    </button>
                  </div>

                  {/* Administrator */}
                  <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800 hover:border-amber-500/40 transition-colors flex items-center justify-between">
                    <div>
                      <div className="text-xs font-semibold text-amber-300 flex items-center gap-1.5">
                        <ShieldCheck className="w-3.5 h-3.5 text-amber-400" /> Prof. Vance (Administrator)
                      </div>
                      <div className="text-[11px] text-slate-400 font-mono">admin@college.edu</div>
                    </div>
                    <button
                      onClick={async () => {
                        await quickLogin('admin');
                        onNavigate('admin-dashboard');
                      }}
                      className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-amber-400 text-slate-950 hover:bg-amber-300 transition-colors"
                    >
                      Admin
                    </button>
                  </div>
                </div>

                <div className="text-[11px] text-slate-400 pt-1 text-center">
                  Or register a new student account with custom credentials.
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Metrics Counter */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="bg-slate-900/60 border border-slate-800 p-5 rounded-2xl">
            <div className="text-2xl sm:text-3xl font-extrabold text-white">9+</div>
            <div className="text-xs text-slate-400 mt-1">Computer Science Courses</div>
          </div>
          <div className="bg-slate-900/60 border border-slate-800 p-5 rounded-2xl">
            <div className="text-2xl sm:text-3xl font-extrabold text-cyan-400">100%</div>
            <div className="text-xs text-slate-400 mt-1">Atomic Race-Condition Safety</div>
          </div>
          <div className="bg-slate-900/60 border border-slate-800 p-5 rounded-2xl">
            <div className="text-2xl sm:text-3xl font-extrabold text-amber-400">18</div>
            <div className="text-xs text-slate-400 mt-1">Documented Lab Test Cases</div>
          </div>
          <div className="bg-slate-900/60 border border-slate-800 p-5 rounded-2xl">
            <div className="text-2xl sm:text-3xl font-extrabold text-emerald-400">0</div>
            <div className="text-xs text-slate-400 mt-1">Overbooking Tolerated</div>
          </div>
        </div>
      </section>

      {/* Software Engineering Principles Highlights */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-10 space-y-3">
          <h2 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">
            Software Engineering Architecture
          </h2>
          <p className="text-sm text-slate-400">
            Built strictly in accordance with Software Engineering Laboratory principles:
            requirements traceability, transactional integrity, and multi-technique verification.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-slate-900/80 border border-slate-800 p-6 rounded-2xl space-y-3">
            <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center text-cyan-400">
              <Zap className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold text-white">Atomic Concurrency & ACID Mutex</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Course capacity increments and decrements are serialized using database-level locking.
              Simultaneous bookings for the last remaining seat guarantee zero overbooking and exactly one confirmation.
            </p>
          </div>

          <div className="bg-slate-900/80 border border-slate-800 p-6 rounded-2xl space-y-3">
            <div className="w-10 h-10 rounded-xl bg-blue-500/10 border border-blue-500/20 flex items-center justify-center text-blue-400">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold text-white">Server-Authoritative RBAC</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Student and Administrator privileges are enforced by verified HMAC cryptographic signatures.
              Administrative actions, course mutations, and CSV data exports are protected against client-side tampering.
            </p>
          </div>

          <div className="bg-slate-900/80 border border-slate-800 p-6 rounded-2xl space-y-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400">
              <FlaskConical className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold text-white">Comprehensive Testing Matrix</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Features White-Box testing (Statement, Branch, Condition, Path coverage), Black-Box testing
              (Equivalence Partitioning, Boundary Value, Decision Tables, Error Guessing), and Generative AI test reviews.
            </p>
          </div>
        </div>
      </section>

      {/* Featured Courses Showcase */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h2 className="text-2xl font-bold text-white tracking-tight">Featured Courses</h2>
            <p className="text-xs text-slate-400 mt-1">
              Top enrollment courses available for reservation in the current semester
            </p>
          </div>
          <button
            onClick={() => onNavigate('catalogue')}
            className="text-xs font-semibold text-cyan-400 hover:text-cyan-300 flex items-center gap-1"
          >
            View all courses <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {featuredCourses.map((course) => (
            <CourseCard
              key={course.id}
              course={course}
              onSelect={() => onNavigate('course-details', { courseId: course.id })}
              onReserve={() => onNavigate('course-details', { courseId: course.id })}
            />
          ))}
        </div>
      </section>
    </div>
  );
};
