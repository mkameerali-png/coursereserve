import React from 'react';
import { 
  CheckCircle2, 
  Calendar, 
  Clock, 
  User as UserIcon, 
  ArrowRight, 
  Download, 
  Printer, 
  BookOpen, 
  Copy, 
  Ticket
} from 'lucide-react';
import { Reservation } from '../types/index';
import { useToast } from '../components/Toast';

interface ReservationConfirmationPageProps {
  reservation: Reservation;
  onNavigate: (view: string, params?: any) => void;
}

export const ReservationConfirmationPage: React.FC<ReservationConfirmationPageProps> = ({
  reservation,
  onNavigate,
}) => {
  const { success } = useToast();

  const handleCopyCode = () => {
    navigator.clipboard.writeText(reservation.confirmationCode);
    success(`Confirmation code copied: ${reservation.confirmationCode}`);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      {/* Success Banner */}
      <div className="text-center space-y-3">
        <div className="w-16 h-16 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center mx-auto text-emerald-400 shadow-xl shadow-emerald-950/40 animate-in zoom-in-75">
          <CheckCircle2 className="w-10 h-10" />
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
          Reservation Confirmed!
        </h1>
        <p className="text-xs sm:text-sm text-slate-400 max-w-md mx-auto">
          Your seat in this course has been atomically reserved and guaranteed in the college database.
        </p>
      </div>

      {/* Confirmation Ticket Card */}
      <div className="bg-slate-900 border border-slate-700/80 rounded-3xl overflow-hidden shadow-2xl relative">
        <div className="bg-gradient-to-r from-cyan-600/30 via-blue-600/20 to-indigo-600/30 p-6 sm:p-8 border-b border-slate-800">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <span className="text-[11px] font-bold uppercase tracking-wider text-cyan-400 bg-cyan-950/80 px-2.5 py-0.5 rounded border border-cyan-800">
                Official Reservation Voucher
              </span>
              <h2 className="text-xl sm:text-2xl font-black text-white mt-2">
                {reservation.courseCode} — {reservation.courseTitle}
              </h2>
              <p className="text-xs text-slate-300 mt-1">{reservation.courseCategory}</p>
            </div>

            {/* Unique Confirmation Code Box */}
            <div className="bg-slate-950/90 border border-slate-800 p-3 rounded-2xl shrink-0 text-center space-y-1">
              <div className="text-[10px] text-slate-400 font-medium uppercase tracking-wider">
                Reservation ID
              </div>
              <div className="text-lg font-mono font-extrabold text-cyan-400">
                {reservation.confirmationCode}
              </div>
              <button
                onClick={handleCopyCode}
                className="text-[11px] text-slate-400 hover:text-white flex items-center gap-1 mx-auto transition-colors"
              >
                <Copy className="w-3 h-3" /> Copy
              </button>
            </div>
          </div>
        </div>

        {/* Ticket Body */}
        <div className="p-6 sm:p-8 space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div className="space-y-1 bg-slate-950/60 p-3.5 rounded-xl border border-slate-800">
              <span className="text-slate-400">Enrolled Student</span>
              <div className="font-semibold text-white text-sm">{reservation.studentName}</div>
              <div className="text-slate-400 font-mono text-[11px]">{reservation.studentEmail}</div>
            </div>

            <div className="space-y-1 bg-slate-950/60 p-3.5 rounded-xl border border-slate-800">
              <span className="text-slate-400">Course Schedule</span>
              <div className="font-semibold text-white text-sm flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-cyan-400" />
                {reservation.courseSchedule || 'Weekly sessions'}
              </div>
              <div className="text-slate-400 text-[11px]">Starts {reservation.courseStartDate || 'TBA'}</div>
            </div>

            <div className="space-y-1 bg-slate-950/60 p-3.5 rounded-xl border border-slate-800">
              <span className="text-slate-400">Reservation Status</span>
              <div className="font-semibold text-emerald-400 text-sm flex items-center gap-1.5 uppercase">
                <span className="w-2 h-2 rounded-full bg-emerald-400" />
                {reservation.reservationStatus}
              </div>
              <div className="text-slate-400 text-[11px]">Timestamp: {new Date(reservation.reservedAt).toLocaleString()}</div>
            </div>

            <div className="space-y-1 bg-slate-950/60 p-3.5 rounded-xl border border-slate-800">
              <span className="text-slate-400">Course Registration Fee</span>
              <div className="font-extrabold text-white text-base">
                ${reservation.courseFee || 0} USD
              </div>
              <div className="text-emerald-400 text-[11px]">Reserved & Locked</div>
            </div>
          </div>

          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-400 space-y-1">
            <div className="font-semibold text-slate-300 flex items-center gap-1.5">
              <Ticket className="w-4 h-4 text-cyan-400" /> Academic Notice
            </div>
            <p>
              Please retain your confirmation ID <strong>{reservation.confirmationCode}</strong> for laboratory check-in and attendance verification. You may cancel this reservation any time prior to the syllabus commencement date from your student dashboard.
            </p>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="bg-slate-950/80 p-5 sm:p-6 border-t border-slate-800 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="px-3.5 py-2 text-xs font-semibold text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg flex items-center gap-1.5 transition-colors"
            >
              <Printer className="w-3.5 h-3.5" /> Print Receipt
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => onNavigate('catalogue')}
              className="px-4 py-2 text-xs font-semibold text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors flex items-center gap-1"
            >
              <BookOpen className="w-3.5 h-3.5" /> Browse Catalogue
            </button>
            <button
              onClick={() => onNavigate('my-reservations')}
              className="px-5 py-2 text-xs font-bold text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded-lg transition-all flex items-center gap-1.5 shadow-md shadow-cyan-500/20"
            >
              View My Reservations <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
