import React, { useState, useEffect } from 'react';
import { 
  ShieldCheck, 
  BookOpen, 
  Users, 
  CalendarCheck, 
  AlertCircle, 
  DollarSign, 
  Layers, 
  FileSpreadsheet, 
  FlaskConical, 
  RefreshCw, 
  ArrowRight,
  TrendingUp,
  Activity,
  History
} from 'lucide-react';
import { AdminStats, AuditLog } from '../types/index';
import { api } from '../services/api';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../components/Toast';

interface AdminDashboardProps {
  onNavigate: (view: string, params?: any) => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ onNavigate }) => {
  const { user, isAdmin } = useAuth();
  const { success, error } = useToast();

  const [stats, setStats] = useState<AdminStats | null>(null);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [resetting, setResetting] = useState<boolean>(false);

  const fetchDashboardData = async () => {
    setLoading(true);
    try {
      const [statsRes, logsRes] = await Promise.all([
        api.admin.getStats(),
        api.admin.getAuditLogs(),
      ]);
      setStats(statsRes.stats);
      setAuditLogs(logsRes.logs.slice(0, 5));
    } catch (err: any) {
      error(err.message || 'Failed to fetch administrative data');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isAdmin) {
      fetchDashboardData();
    }
  }, [isAdmin]);

  const handleResetDemo = async () => {
    if (!window.confirm('Reset all courses, reservations, and test cases to clean demonstration seed data?')) {
      return;
    }
    setResetting(true);
    try {
      await api.admin.resetDemo();
      success('System database reset to initial seed state.');
      fetchDashboardData();
    } catch (err: any) {
      error(err.message || 'Failed to reset database');
    } finally {
      setResetting(false);
    }
  };

  if (!isAdmin) {
    return (
      <div className="max-w-md mx-auto px-4 py-20 text-center space-y-4">
        <ShieldCheck className="w-12 h-12 text-rose-400 mx-auto" />
        <h2 className="text-xl font-bold text-white">Administrative Access Required</h2>
        <p className="text-xs text-slate-400">
          You must be authenticated as an administrator to view this portal.
        </p>
        <button
          onClick={() => onNavigate('login')}
          className="px-4 py-2 text-xs font-semibold text-slate-950 bg-amber-400 rounded-lg hover:bg-amber-300"
        >
          Sign In as Administrator
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-6">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-amber-400 bg-amber-950/80 border border-amber-800 px-2.5 py-0.5 rounded-full flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5" /> Administrator Console
            </span>
            <span className="text-xs text-slate-400 font-mono">
              Signed in as: {user?.fullName}
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            System Operations & Metrics
          </h1>
          <p className="text-xs sm:text-sm text-slate-400">
            Real-time control over course inventory, capacity quotas, student reservations, and testing protocols.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={fetchDashboardData}
            className="p-2 text-slate-400 hover:text-white bg-slate-900 border border-slate-800 rounded-xl hover:bg-slate-800 transition-colors"
            title="Refresh statistics"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </button>

          <button
            onClick={handleResetDemo}
            disabled={resetting}
            className="px-3 py-2 text-xs font-semibold text-slate-300 hover:text-white bg-slate-900 border border-slate-800 rounded-xl hover:bg-slate-800 transition-colors"
          >
            {resetting ? 'Resetting...' : 'Reset Demo Data'}
          </button>

          <button
            onClick={() => onNavigate('admin-courses')}
            className="px-4 py-2 text-xs font-bold text-slate-950 bg-amber-400 hover:bg-amber-300 rounded-xl transition-all shadow-md shadow-amber-500/20"
          >
            + Add New Course
          </button>
        </div>
      </div>

      {/* KPI Metric Cards */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        {/* Total Courses */}
        <div className="bg-slate-900/90 border border-slate-800 p-4 rounded-2xl space-y-1">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Total Courses</span>
            <BookOpen className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-2xl font-extrabold text-white">{stats?.totalCourses || 0}</div>
          <div className="text-[10px] text-slate-400">{stats?.publishedCourses || 0} Published Active</div>
        </div>

        {/* Registered Students */}
        <div className="bg-slate-900/90 border border-slate-800 p-4 rounded-2xl space-y-1">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Students</span>
            <Users className="w-4 h-4 text-blue-400" />
          </div>
          <div className="text-2xl font-extrabold text-white">{stats?.totalStudents || 0}</div>
          <div className="text-[10px] text-slate-400">Enrolled collegiate users</div>
        </div>

        {/* Active Reservations */}
        <div className="bg-slate-900/90 border border-slate-800 p-4 rounded-2xl space-y-1">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Active Resv.</span>
            <CalendarCheck className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-extrabold text-emerald-400">{stats?.activeReservations || 0}</div>
          <div className="text-[10px] text-slate-400">{stats?.cancelledReservations || 0} Cancelled / Restored</div>
        </div>

        {/* Available Seats */}
        <div className="bg-slate-900/90 border border-slate-800 p-4 rounded-2xl space-y-1">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Available Seats</span>
            <Layers className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-2xl font-extrabold text-white">{stats?.totalAvailableSeats || 0}</div>
          <div className="text-[10px] text-slate-400">Of {stats?.totalCapacity || 0} Total Quota</div>
        </div>

        {/* Courses with Zero Seats */}
        <div className="bg-slate-900/90 border border-slate-800 p-4 rounded-2xl space-y-1">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Full Courses</span>
            <AlertCircle className="w-4 h-4 text-rose-400" />
          </div>
          <div className="text-2xl font-extrabold text-rose-400">{stats?.fullCoursesCount || 0}</div>
          <div className="text-[10px] text-rose-300">0 Available Seats Remaining</div>
        </div>

        {/* Estimated Tuition Revenue */}
        <div className="bg-slate-900/90 border border-slate-800 p-4 rounded-2xl space-y-1">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Est. Revenue</span>
            <DollarSign className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl font-extrabold text-amber-400">${stats?.estimatedRevenue || 0}</div>
          <div className="text-[10px] text-slate-400">Active enrollments</div>
        </div>
      </div>

      {/* Main Charts & Breakdown Section */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column: Category Distribution & Capacity */}
        <div className="lg:col-span-8 space-y-6">
          {/* Capacity Utilization Progress */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <TrendingUp className="w-4 h-4 text-cyan-400" /> Capacity Utilization & Occupancy
                </h3>
                <p className="text-xs text-slate-400">Overall seat allocation ratio across catalogue</p>
              </div>
              <span className="text-lg font-extrabold text-cyan-400">
                {stats?.capacityUtilization || 0}% Booked
              </span>
            </div>

            <div className="w-full bg-slate-950 h-3 rounded-full overflow-hidden border border-slate-800">
              <div
                className="bg-gradient-to-r from-cyan-500 to-blue-500 h-full rounded-full transition-all duration-700"
                style={{ width: `${stats?.capacityUtilization || 0}%` }}
              />
            </div>

            <div className="grid grid-cols-3 gap-2 text-xs pt-1">
              <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800 text-center">
                <div className="text-slate-400 text-[11px]">Occupied Seats</div>
                <div className="font-bold text-white">
                  {(stats?.totalCapacity || 0) - (stats?.totalAvailableSeats || 0)}
                </div>
              </div>
              <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800 text-center">
                <div className="text-slate-400 text-[11px]">Unbooked Seats</div>
                <div className="font-bold text-emerald-400">{stats?.totalAvailableSeats || 0}</div>
              </div>
              <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800 text-center">
                <div className="text-slate-400 text-[11px]">Total Capacity</div>
                <div className="font-bold text-white">{stats?.totalCapacity || 0}</div>
              </div>
            </div>
          </div>

          {/* Category Breakdown Table */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Layers className="w-4 h-4 text-cyan-400" /> Department Course Categories
            </h3>

            <div className="space-y-3">
              {(stats?.categoryBreakdown || []).map((cat) => (
                <div
                  key={cat.category}
                  className="bg-slate-950/70 border border-slate-800/80 p-3.5 rounded-xl flex items-center justify-between gap-4"
                >
                  <div className="space-y-0.5">
                    <div className="text-xs font-semibold text-white">{cat.category}</div>
                    <div className="text-[11px] text-slate-400">{cat.courses} course sections</div>
                  </div>

                  <div className="flex items-center gap-4 text-xs">
                    <div className="text-right">
                      <div className="font-bold text-cyan-400">{cat.reservations} Active Enrolled</div>
                      <div className="text-[10px] text-slate-400">Reservations</div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column: Quick Operations & Recent Audit Logs */}
        <div className="lg:col-span-4 space-y-6">
          {/* Quick Shortcuts */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-3">
            <h3 className="text-sm font-bold text-white">Administrative Modules</h3>

            <div className="grid grid-cols-1 gap-2 text-xs">
              <button
                onClick={() => onNavigate('admin-courses')}
                className="w-full text-left p-3 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-800 transition-colors flex items-center justify-between text-slate-200"
              >
                <div className="flex items-center gap-2">
                  <Layers className="w-4 h-4 text-amber-400" />
                  <span>Course Management</span>
                </div>
                <ArrowRight className="w-3.5 h-3.5 text-slate-400" />
              </button>

              <button
                onClick={() => onNavigate('admin-reservations')}
                className="w-full text-left p-3 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-800 transition-colors flex items-center justify-between text-slate-200"
              >
                <div className="flex items-center gap-2">
                  <CalendarCheck className="w-4 h-4 text-emerald-400" />
                  <span>Student Reservations</span>
                </div>
                <ArrowRight className="w-3.5 h-3.5 text-slate-400" />
              </button>

              <button
                onClick={() => onNavigate('admin-reports')}
                className="w-full text-left p-3 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-800 transition-colors flex items-center justify-between text-slate-200"
              >
                <div className="flex items-center gap-2">
                  <FileSpreadsheet className="w-4 h-4 text-blue-400" />
                  <span>CSV Reports & Analytics</span>
                </div>
                <ArrowRight className="w-3.5 h-3.5 text-slate-400" />
              </button>

              <button
                onClick={() => onNavigate('testing-dashboard')}
                className="w-full text-left p-3 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 transition-colors flex items-center justify-between text-amber-300 font-semibold"
              >
                <div className="flex items-center gap-2">
                  <FlaskConical className="w-4 h-4 text-amber-400" />
                  <span>Software Testing Lab</span>
                </div>
                <ArrowRight className="w-3.5 h-3.5 text-amber-400" />
              </button>
            </div>
          </div>

          {/* Audit Trail Snippet */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
                <History className="w-4 h-4 text-cyan-400" /> Recent System Audit Logs
              </h3>
            </div>

            <div className="space-y-2.5">
              {auditLogs.map((log) => (
                <div key={log.id} className="p-2.5 bg-slate-950/70 border border-slate-800 rounded-xl space-y-1">
                  <div className="flex items-center justify-between text-[10px]">
                    <span className="font-mono font-bold text-cyan-400">{log.action}</span>
                    <span className="text-slate-500">{new Date(log.timestamp).toLocaleTimeString()}</span>
                  </div>
                  <p className="text-[11px] text-slate-300 leading-snug line-clamp-2">
                    {log.details}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
