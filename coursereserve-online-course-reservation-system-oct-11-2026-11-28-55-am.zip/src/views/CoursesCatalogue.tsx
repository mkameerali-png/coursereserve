import React, { useState, useEffect, useMemo } from 'react';
import { 
  Search, 
  Filter, 
  ArrowUpDown, 
  Sparkles, 
  BookOpen, 
  X,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';
import { Course } from '../types/index';
import { api } from '../services/api';
import { CourseCard } from '../components/CourseCard';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../components/Toast';

interface CoursesCatalogueProps {
  onNavigate: (view: string, params?: any) => void;
}

export const CoursesCatalogue: React.FC<CoursesCatalogueProps> = ({ onNavigate }) => {
  const { user, isAdmin, isStudent } = useAuth();
  const { success, error } = useToast();

  const [courses, setCourses] = useState<Course[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [search, setSearch] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [availabilityFilter, setAvailabilityFilter] = useState<'all' | 'available' | 'full'>('all');
  const [sortBy, setSortBy] = useState<'title' | 'fee' | 'availableSeats' | 'startDate'>('title');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc');
  const [studentReservations, setStudentReservations] = useState<string[]>([]);

  // Fetch courses and student active reservations
  const fetchCourses = async () => {
    setLoading(true);
    try {
      const res = await api.courses.getAll({
        search,
        category: selectedCategory,
        sortBy,
        sortOrder,
      });
      setCourses(res.courses);

      if (isStudent && user) {
        const resv = await api.reservations.getAll({ status: 'active', studentId: user.id });
        setStudentReservations(resv.reservations.map((r) => r.courseId));
      }
    } catch (err: any) {
      error(err.message || 'Failed to load courses');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCourses();
  }, [search, selectedCategory, sortBy, sortOrder]);

  const categories = useMemo(() => [
    'all',
    'Programming & Software',
    'Web Technologies',
    'Core Computer Science',
    'Artificial Intelligence',
    'Systems & Architecture',
    'Software Engineering',
  ], []);

  // Filter courses by availability locally
  const filteredCourses = useMemo(() => {
    return courses.filter((c) => {
      if (availabilityFilter === 'available') return c.availableSeats > 0;
      if (availabilityFilter === 'full') return c.availableSeats === 0;
      return true;
    });
  }, [courses, availabilityFilter]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-slate-800 pb-6">
        <div>
          <div className="flex items-center gap-2 text-cyan-400 text-xs font-semibold uppercase tracking-wider mb-1">
            <BookOpen className="w-4 h-4" /> Academic Course Catalogue
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            Explore & Reserve Courses
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Select high-demand university computer science courses with real-time seat reservation.
          </p>
        </div>

        {isAdmin && (
          <button
            onClick={() => onNavigate('admin-courses')}
            className="self-start md:self-auto px-4 py-2 text-xs font-bold text-slate-950 bg-amber-400 hover:bg-amber-300 rounded-xl transition-colors shadow-sm"
          >
            + Add New Course (Admin)
          </button>
        )}
      </div>

      {/* Search and Filters Bar */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 sm:p-5 space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-3">
          {/* Search Input */}
          <div className="md:col-span-6 relative">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="text"
              placeholder="Search by course code, title, instructor, or keywords..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 bg-slate-950 border border-slate-800 focus:border-cyan-500 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none transition-colors"
            />
            {search && (
              <button
                onClick={() => setSearch('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Availability Filter */}
          <div className="md:col-span-3">
            <select
              value={availabilityFilter}
              onChange={(e) => setAvailabilityFilter(e.target.value as any)}
              className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-800 focus:border-cyan-500 rounded-xl text-xs sm:text-sm text-slate-300 focus:outline-none transition-colors"
            >
              <option value="all">Availability: All Courses</option>
              <option value="available">Only Available Seats (&gt;0)</option>
              <option value="full">Only Full Courses (0 Seats)</option>
            </select>
          </div>

          {/* Sorting */}
          <div className="md:col-span-3 flex gap-2">
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-800 focus:border-cyan-500 rounded-xl text-xs sm:text-sm text-slate-300 focus:outline-none transition-colors"
            >
              <option value="title">Sort by Title</option>
              <option value="fee">Sort by Course Fee</option>
              <option value="availableSeats">Sort by Available Seats</option>
              <option value="startDate">Sort by Start Date</option>
            </select>
            <button
              onClick={() => setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc')}
              className="px-3 bg-slate-950 border border-slate-800 hover:bg-slate-800 text-slate-300 rounded-xl flex items-center justify-center transition-colors shrink-0"
              title={`Switch to ${sortOrder === 'asc' ? 'Descending' : 'Ascending'}`}
            >
              <ArrowUpDown className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Category Pills */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 pt-1 scrollbar-none text-xs">
          <span className="text-slate-400 font-medium shrink-0 flex items-center gap-1 mr-1">
            <Filter className="w-3.5 h-3.5" /> Category:
          </span>
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 rounded-lg whitespace-nowrap font-medium transition-all ${
                selectedCategory === cat
                  ? 'bg-cyan-400 text-slate-950 font-bold shadow-sm'
                  : 'bg-slate-950 text-slate-300 hover:bg-slate-800 border border-slate-800/80'
              }`}
            >
              {cat === 'all' ? 'All Categories' : cat}
            </button>
          ))}
        </div>
      </div>

      {/* Course Grid / Loading / Empty States */}
      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {Array.from({ length: 6 }).map((_, i) => (
            <div
              key={i}
              className="h-80 bg-slate-900/50 border border-slate-800/80 rounded-2xl animate-pulse p-6"
            />
          ))}
        </div>
      ) : filteredCourses.length === 0 ? (
        <div className="text-center py-16 bg-slate-900/40 border border-slate-800 rounded-2xl p-8 space-y-3">
          <div className="w-12 h-12 rounded-full bg-slate-800 flex items-center justify-center mx-auto text-slate-400">
            <Search className="w-6 h-6" />
          </div>
          <h3 className="text-lg font-bold text-white">No courses match your criteria</h3>
          <p className="text-xs text-slate-400 max-w-sm mx-auto">
            Try adjusting your search keywords, clearing category filters, or selecting "All Courses".
          </p>
          <button
            onClick={() => {
              setSearch('');
              setSelectedCategory('all');
              setAvailabilityFilter('all');
            }}
            className="px-4 py-2 text-xs font-semibold text-cyan-400 bg-cyan-950/60 border border-cyan-800 rounded-lg hover:bg-cyan-900/60 transition-colors"
          >
            Reset All Filters
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          <div className="text-xs text-slate-400 flex items-center justify-between">
            <span>
              Showing <strong className="text-white">{filteredCourses.length}</strong> courses
            </span>
            <span className="text-cyan-400 font-medium">
              Real-time seat synchronizer active
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredCourses.map((course) => (
              <CourseCard
                key={course.id}
                course={course}
                isReservedByStudent={studentReservations.includes(course.id)}
                onSelect={() => onNavigate('course-details', { courseId: course.id })}
                onReserve={() => onNavigate('course-details', { courseId: course.id })}
              />
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
