import React, { useState, useEffect } from 'react';
import { 
  FileSpreadsheet, 
  Download, 
  ArrowLeft, 
  TrendingUp, 
  DollarSign, 
  Users, 
  Layers, 
  Calendar,
  CheckCircle2
} from 'lucide-react';
import { AdminStats } from '../types/index';
import { api } from '../services/api';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../components/Toast';

interface AdminReportsProps {
  onNavigate: (view: string, params?: any) => void;
}

export const AdminReports: React.FC<AdminReportsProps> = ({ onNavigate }) => {
  const { isAdmin } = useAuth();
  const { error } = useToast();

  const [stats, setStats] = useState<AdminStats | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadStats() {
      setLoading(true);
      try {
        const res = await api.admin.getStats();
        setStats(res.stats);
      } catch (err: any) {
        error('Failed to load reports');
      } finally {
        setLoading(false);
      }
    }
    if (isAdmin) {
      loadStats();
    }
  }, [isAdmin]);

  const handleDownloadCsv = () => {
    window.location.href = '/api/reservations/export';
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-6">
        <div>
          <button
            onClick={() => onNavigate('admin-dashboard')}
            className="inline-flex items-center gap-1.5 text-xs text-slate-400 hover:text-white mb-2 transition-colors"
          >
            <ArrowLeft className="w-3.5 h-3.5" /> Back to Admin Dashboard
          </button>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            Academic Reports & Analytics
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Export comprehensive student reservation reports and evaluate department enrollment statistics.
          </p>
        </div>

        <button
          onClick={handleDownloadCsv}
          className="self-start sm:self-auto px-5 py-2.5 text-xs font-bold text-slate-950 bg-emerald-400 hover:bg-emerald-300 rounded-xl transition-all shadow-md shadow-emerald-500/20 flex items-center gap-2"
        >
          <Download className="w-4 h-4" /> Download Complete CSV Report
        </button>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl space-y-1">
          <div className="text-xs text-slate-400">Total Enrolled Revenue</div>
          <div className="text-2xl sm:text-3xl font-extrabold text-emerald-400">
            ${stats?.estimatedRevenue || 0}
          </div>
          <div className="text-[11px] text-slate-400">Tuition fees collected</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl space-y-1">
          <div className="text-xs text-slate-400">Active Seat Occupancy</div>
          <div className="text-2xl sm:text-3xl font-extrabold text-cyan-400">
            {stats?.capacityUtilization || 0}%
          </div>
          <div className="text-[11px] text-slate-400">Quota filled ratio</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl space-y-1">
          <div className="text-xs text-slate-400">Confirmed Reservations</div>
          <div className="text-2xl sm:text-3xl font-extrabold text-white">
            {stats?.activeReservations || 0}
          </div>
          <div className="text-[11px] text-slate-400">Active student vouchers</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl space-y-1">
          <div className="text-xs text-slate-400">Restored Cancellations</div>
          <div className="text-2xl sm:text-3xl font-extrabold text-slate-300">
            {stats?.cancelledReservations || 0}
          </div>
          <div className="text-[11px] text-slate-400">100% capacity restored</div>
        </div>
      </div>

      {/* Department Breakdown Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4 shadow-xl">
        <div className="flex items-center justify-between">
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <Layers className="w-4 h-4 text-cyan-400" /> Department Breakdown & Enrollment Revenue
          </h2>
          <span className="text-xs text-slate-400">Server-authoritative database aggregate</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950 text-slate-400 uppercase tracking-wider font-semibold border-b border-slate-800">
              <tr>
                <th className="px-4 py-3">Academic Category</th>
                <th className="px-4 py-3">Courses Offered</th>
                <th className="px-4 py-3">Active Student Reservations</th>
                <th className="px-4 py-3 text-right">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {(stats?.categoryBreakdown || []).map((cat) => (
                <tr key={cat.category} className="hover:bg-slate-800/40">
                  <td className="px-4 py-3.5 font-bold text-white">{cat.category}</td>
                  <td className="px-4 py-3.5 text-slate-300">{cat.courses} active sections</td>
                  <td className="px-4 py-3.5 font-bold text-cyan-400">{cat.reservations} enrolled seats</td>
                  <td className="px-4 py-3.5 text-right">
                    <span className="inline-flex items-center gap-1 text-[11px] text-emerald-400 bg-emerald-950/80 px-2 py-0.5 rounded border border-emerald-800">
                      <CheckCircle2 className="w-3 h-3" /> Synchronized
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
