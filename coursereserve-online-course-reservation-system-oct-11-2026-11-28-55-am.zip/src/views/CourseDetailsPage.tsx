import React, { useState, useEffect } from 'react';
import { 
  ArrowLeft, 
  Calendar, 
  Clock, 
  User as UserIcon, 
  Users, 
  CreditCard, 
  ShieldCheck, 
  CheckCircle2, 
  AlertTriangle, 
  BookOpen, 
  MapPin, 
  Award, 
  FileText,
  Lock
} from 'lucide-react';
import { Course, Reservation } from '../types/index';
import { api } from '../services/api';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../components/Toast';
import { Modal } from '../components/Modal';

interface CourseDetailsPageProps {
  courseId: string;
  onNavigate: (view: string, params?: any) => void;
}

export const CourseDetailsPage: React.FC<CourseDetailsPageProps> = ({ courseId, onNavigate }) => {
  const { user, isAuthenticated, isStudent, isAdmin } = useAuth();
  const { success, error } = useToast();

  const [course, setCourse] = useState<Course | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [existingReservation, setExistingReservation] = useState<Reservation | null>(null);
  const [confirmModalOpen, setConfirmModalOpen] = useState<boolean>(false);
  const [reserving, setReserving] = useState<boolean>(false);
  const [agreeTerms, setAgreeTerms] = useState<boolean>(true);

  useEffect(() => {
    async function loadData() {
      setLoading(true);
      try {
        const res = await api.courses.getById(courseId);
        setCourse(res.course);

        if (isAuthenticated && isStudent && user) {
          const resv = await api.reservations.getAll({ courseId, studentId: user.id, status: 'active' });
          if (resv.reservations.length > 0) {
            setExistingReservation(resv.reservations[0]);
          }
        }
      } catch (err: any) {
        error(err.message || 'Course not found');
      } finally {
        setLoading(false);
      }
    }
    loadData();
  }, [courseId, isAuthenticated, isStudent, user]);

  const handleConfirmReservation = async () => {
    if (!agreeTerms) {
      error('Please acknowledge the reservation and cancellation policy.');
      return;
    }

    setReserving(true);
    try {
      const res = await api.reservations.create(course!.id);
      success('Seat reserved successfully! Confirmation generated.');
      setConfirmModalOpen(false);
      onNavigate('reservation-confirmation', { reservation: res.reservation });
    } catch (err: any) {
      error(err.message || 'Failed to complete reservation');
    } finally {
      setReserving(false);
    }
  };

  if (loading) {
    return (
      <div className="max-w-5xl mx-auto px-4 py-16">
        <div className="h-96 bg-slate-900/60 rounded-2xl animate-pulse border border-slate-800" />
      </div>
    );
  }

  if (!course) {
    return (
      <div className="max-w-md mx-auto px-4 py-20 text-center space-y-4">
        <AlertTriangle className="w-12 h-12 text-amber-400 mx-auto" />
        <h2 className="text-xl font-bold text-white">Course Not Found</h2>
        <p className="text-xs text-slate-400">The requested course could not be located in the catalogue.</p>
        <button
          onClick={() => onNavigate('catalogue')}
          className="px-4 py-2 text-xs font-semibold text-slate-950 bg-cyan-400 rounded-lg hover:bg-cyan-300"
        >
          Back to Catalogue
        </button>
      </div>
    );
  }

  const isFull = course.availableSeats <= 0;
  const isOneLeft = course.availableSeats === 1;
  const percentOccupied = Math.round(
    ((course.capacity - course.availableSeats) / course.capacity) * 100
  );

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Back Button */}
      <div>
        <button
          onClick={() => onNavigate('catalogue')}
          className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-400 hover:text-white transition-colors py-1 px-2.5 rounded-lg hover:bg-slate-800"
        >
          <ArrowLeft className="w-4 h-4" /> Back to Catalogue
        </button>
      </div>

      {/* Main Course Header Box */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 sm:p-8 space-y-6 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-start justify-between gap-6">
          <div className="space-y-2 max-w-3xl">
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-xs font-bold text-cyan-400 bg-cyan-950/90 border border-cyan-800 px-3 py-1 rounded-md">
                {course.code}
              </span>
              <span className="text-xs font-semibold text-slate-300 bg-slate-800 px-3 py-1 rounded-md">
                {course.category}
              </span>
              <span className="text-xs font-medium text-slate-400">
                {course.credits || 3} Academic Credits
              </span>
            </div>

            <h1 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-white tracking-tight">
              {course.title}
            </h1>
            <p className="text-sm text-slate-300 leading-relaxed pt-1">
              {course.description}
            </p>
          </div>

          {/* Pricing & Seat Availability Card */}
          <div className="bg-slate-950 border border-slate-800 p-5 rounded-2xl shrink-0 w-full md:w-72 space-y-4">
            <div>
              <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                Registration Fee
              </div>
              <div className="text-2xl font-extrabold text-white flex items-baseline gap-1">
                ${course.fee} <span className="text-xs font-normal text-slate-400">USD</span>
              </div>
            </div>

            {/* Seat Availability Status */}
            <div className="space-y-1.5 pt-2 border-t border-slate-800">
              <div className="flex justify-between text-xs font-semibold">
                <span className="text-slate-300">Available Seats:</span>
                <span className={isFull ? 'text-rose-400 font-bold' : isOneLeft ? 'text-amber-400 font-bold' : 'text-emerald-400 font-bold'}>
                  {course.availableSeats} of {course.capacity}
                </span>
              </div>
              <div className="w-full bg-slate-800 h-2.5 rounded-full overflow-hidden">
                <div
                  className={`h-full rounded-full ${
                    isFull ? 'bg-rose-500' : isOneLeft ? 'bg-amber-400' : 'bg-cyan-500'
                  }`}
                  style={{ width: `${percentOccupied}%` }}
                />
              </div>
              <div className="text-[11px] text-slate-400 text-right">
                {percentOccupied}% Booked
              </div>
            </div>

            {/* Reservation CTA */}
            <div className="pt-2">
              {!isAuthenticated ? (
                <button
                  onClick={() => onNavigate('login')}
                  className="w-full py-2.5 text-xs font-bold text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded-xl transition-all shadow-md shadow-cyan-500/20"
                >
                  Log In to Reserve Seat
                </button>
              ) : existingReservation ? (
                <div className="space-y-2">
                  <div className="px-3 py-2 rounded-xl bg-emerald-950/60 border border-emerald-800/80 text-emerald-300 text-xs font-semibold text-center flex items-center justify-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    Enrolled ({existingReservation.confirmationCode})
                  </div>
                  <button
                    onClick={() => onNavigate('my-reservations')}
                    className="w-full py-2 text-xs font-medium text-slate-300 hover:text-white bg-slate-800 rounded-lg hover:bg-slate-700 transition-colors"
                  >
                    View in My Reservations
                  </button>
                </div>
              ) : isFull ? (
                <button
                  disabled
                  className="w-full py-2.5 text-xs font-bold text-slate-500 bg-slate-800 border border-slate-700 rounded-xl cursor-not-allowed flex items-center justify-center gap-1.5"
                >
                  <Lock className="w-3.5 h-3.5" /> Full (0 Seats Left)
                </button>
              ) : (
                <button
                  onClick={() => setConfirmModalOpen(true)}
                  className="w-full py-2.5 text-xs font-bold text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded-xl transition-all shadow-lg shadow-cyan-500/20 hover:scale-[1.02]"
                >
                  Reserve Course Seat
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Course Attributes Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-4 border-t border-slate-800/80">
          <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800/60 space-y-1">
            <div className="flex items-center gap-1.5 text-xs text-slate-400">
              <UserIcon className="w-3.5 h-3.5 text-cyan-400" /> Instructor
            </div>
            <div className="text-sm font-semibold text-white truncate">{course.instructor}</div>
            <div className="text-[11px] text-slate-400 truncate">{course.instructorTitle}</div>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800/60 space-y-1">
            <div className="flex items-center gap-1.5 text-xs text-slate-400">
              <Clock className="w-3.5 h-3.5 text-cyan-400" /> Duration
            </div>
            <div className="text-sm font-semibold text-white">{course.duration}</div>
            <div className="text-[11px] text-slate-400">Starting {course.startDate}</div>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800/60 space-y-1">
            <div className="flex items-center gap-1.5 text-xs text-slate-400">
              <Calendar className="w-3.5 h-3.5 text-cyan-400" /> Schedule
            </div>
            <div className="text-sm font-semibold text-white truncate">{course.schedule}</div>
            <div className="text-[11px] text-slate-400">Weekly Laboratory Session</div>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800/60 space-y-1">
            <div className="flex items-center gap-1.5 text-xs text-slate-400">
              <MapPin className="w-3.5 h-3.5 text-cyan-400" /> Location
            </div>
            <div className="text-sm font-semibold text-white truncate">{course.location}</div>
            <div className="text-[11px] text-slate-400">Hybrid / Campus Room</div>
          </div>
        </div>
      </div>

      {/* Prerequisites & Cancellation Policy */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Prerequisites */}
        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 space-y-4">
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <Award className="w-4 h-4 text-cyan-400" /> Course Prerequisites & Requirements
          </h3>
          <p className="text-xs text-slate-300">
            Ensure you meet the academic background recommendations before registering:
          </p>
          <ul className="space-y-2">
            {(course.prerequisites && course.prerequisites.length > 0
              ? course.prerequisites
              : ['Basic computer science literacy']
            ).map((prereq, idx) => (
              <li key={idx} className="flex items-center gap-2 text-xs text-slate-300">
                <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                <span>{prereq}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Cancellation Policy */}
        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 space-y-4">
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-400" /> Academic Cancellation Policy
          </h3>
          <div className="space-y-2 text-xs text-slate-300 leading-relaxed">
            <p>
              • Reservations can be cancelled by students directly from the <strong>My Reservations</strong> portal.
            </p>
            <p>
              • When a cancellation is submitted, the course seat is <strong>atomically restored</strong> to the catalogue capacity immediately.
            </p>
            <p>
              • All cancellation actions generate an immutable audit log timestamp with the reason specified.
            </p>
          </div>
          <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800 text-[11px] text-slate-400 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>Server-Authoritative Policy: 100% capacity restored on cancellation.</span>
          </div>
        </div>
      </div>

      {/* Confirmation Modal */}
      <Modal
        isOpen={confirmModalOpen}
        onClose={() => setConfirmModalOpen(false)}
        title="Confirm Course Reservation"
        subtitle={`Review details for ${course.code} ${course.title}`}
        maxWidth="lg"
      >
        <div className="space-y-5">
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2 text-xs">
            <div className="flex justify-between py-1 border-b border-slate-800/80">
              <span className="text-slate-400">Student:</span>
              <span className="text-white font-semibold">{user?.fullName}</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-800/80">
              <span className="text-slate-400">Student Email:</span>
              <span className="text-white font-mono">{user?.email}</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-800/80">
              <span className="text-slate-400">Course Code & Title:</span>
              <span className="text-white font-semibold">{course.code} - {course.title}</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-800/80">
              <span className="text-slate-400">Schedule:</span>
              <span className="text-white">{course.schedule}</span>
            </div>
            <div className="flex justify-between py-1 pt-2">
              <span className="text-slate-400">Total Fee:</span>
              <span className="text-cyan-400 font-bold text-sm">${course.fee} USD</span>
            </div>
          </div>

          <label className="flex items-start gap-2.5 cursor-pointer text-xs text-slate-300">
            <input
              type="checkbox"
              checked={agreeTerms}
              onChange={(e) => setAgreeTerms(e.target.checked)}
              className="mt-0.5 rounded border-slate-700 text-cyan-500 focus:ring-cyan-500 bg-slate-950"
            />
            <span>
              I confirm my intention to enroll in this course and agree to the academic reservation attendance and cancellation policy.
            </span>
          </label>

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
            <button
              onClick={() => setConfirmModalOpen(false)}
              className="px-4 py-2 text-xs font-semibold text-slate-300 hover:text-white bg-slate-800 rounded-lg hover:bg-slate-700 transition-colors"
            >
              Cancel
            </button>
            <button
              onClick={handleConfirmReservation}
              disabled={reserving || !agreeTerms}
              className="px-5 py-2 text-xs font-bold text-slate-950 bg-cyan-400 hover:bg-cyan-300 disabled:opacity-50 disabled:cursor-not-allowed rounded-lg transition-all shadow-md shadow-cyan-500/20"
            >
              {reserving ? 'Processing Atomic Reservation...' : 'Confirm & Reserve Seat'}
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
};
