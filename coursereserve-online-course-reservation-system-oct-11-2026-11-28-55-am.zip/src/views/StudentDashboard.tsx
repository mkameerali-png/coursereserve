import React, { useState, useEffect } from 'react';
import { 
  CalendarCheck, 
  BookOpen, 
  Clock, 
  ArrowRight, 
  CheckCircle2, 
  XCircle, 
  Award, 
  GraduationCap, 
  Calendar,
  AlertCircle
} from 'lucide-react';
import { Reservation, Course } from '../types/index';
import { api } from '../services/api';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../components/Toast';

interface StudentDashboardProps {
  onNavigate: (view: string, params?: any) => void;
}

export const StudentDashboard: React.FC<StudentDashboardProps> = ({ onNavigate }) => {
  const { user } = useAuth();
  const { error } = useToast();

  const [reservations, setReservations] = useState<Reservation[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    async function loadData() {
      setLoading(true);
      try {
        const res = await api.reservations.getAll();
        setReservations(res.reservations);
      } catch (err: any) {
        error(err.message || 'Failed to load reservations');
      } finally {
        setLoading(false);
      }
    }
    loadData();
  }, [user]);

  const activeReservations = reservations.filter((r) => r.reservationStatus === 'active');
  const cancelledReservations = reservations.filter((r) => r.reservationStatus === 'cancelled');
  const completedReservations = reservations.filter((r) => r.reservationStatus === 'completed');

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Welcome Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-900 to-cyan-950/40 border border-slate-800 rounded-3xl p-6 sm:p-8 flex flex-col md:flex-row md:items-center justify-between gap-6 shadow-xl">
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold text-cyan-400 bg-cyan-950/80 border border-cyan-800 px-2.5 py-0.5 rounded-full">
              Student Academic Portal
            </span>
            <span className="text-xs text-slate-400 font-mono">
              ID: {user?.studentIdCode || 'CS-2026-REG'}
            </span>
          </div>

          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            Welcome back, {user?.fullName}!
          </h1>

          <p className="text-xs sm:text-sm text-slate-300 max-w-xl">
            {user?.department || 'Computer Science Department'} — Manage your reserved lecture and laboratory sessions.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => onNavigate('catalogue')}
            className="px-5 py-2.5 text-xs font-bold text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded-xl transition-all shadow-md shadow-cyan-500/20 flex items-center gap-2 shrink-0"
          >
            <BookOpen className="w-4 h-4" /> Reserve New Course
          </button>
        </div>
      </div>

      {/* KPI Stats Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-slate-900/80 border border-slate-800 p-5 rounded-2xl space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Active Reservations</span>
            <CalendarCheck className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-white">
            {activeReservations.length}
          </div>
          <div className="text-[11px] text-emerald-400 font-medium">Guaranteed seat reservations</div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 p-5 rounded-2xl space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Total Enrolled Credits</span>
            <Award className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-cyan-400">
            {activeReservations.length * 4}
          </div>
          <div className="text-[11px] text-slate-400">Semester credit hours</div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 p-5 rounded-2xl space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Completed Sessions</span>
            <CheckCircle2 className="w-4 h-4 text-blue-400" />
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-white">
            {completedReservations.length}
          </div>
          <div className="text-[11px] text-slate-400">Verified academic courses</div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 p-5 rounded-2xl space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Cancelled Records</span>
            <XCircle className="w-4 h-4 text-rose-400" />
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-slate-300">
            {cancelledReservations.length}
          </div>
          <div className="text-[11px] text-slate-400">Seats restored to capacity</div>
        </div>
      </div>

      {/* Active Enrolled Courses & Schedule */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column: Active Courses */}
        <div className="lg:col-span-2 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-lg font-bold text-white">Active Course Enrollments</h2>
              <p className="text-xs text-slate-400">Courses where your seat is currently secured</p>
            </div>
            <button
              onClick={() => onNavigate('my-reservations')}
              className="text-xs font-semibold text-cyan-400 hover:text-cyan-300 flex items-center gap-1"
            >
              Manage all ({reservations.length}) <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {loading ? (
            <div className="space-y-3">
              {[1, 2].map((i) => (
                <div key={i} className="h-28 bg-slate-900/50 rounded-2xl animate-pulse border border-slate-800" />
              ))}
            </div>
          ) : activeReservations.length === 0 ? (
            <div className="p-8 text-center bg-slate-900/40 border border-slate-800 rounded-2xl space-y-3">
              <CalendarCheck className="w-10 h-10 text-slate-500 mx-auto" />
              <h3 className="text-sm font-bold text-white">No active reservations yet</h3>
              <p className="text-xs text-slate-400 max-w-sm mx-auto">
                Explore the course catalogue to select and reserve upcoming Computer Science courses.
              </p>
              <button
                onClick={() => onNavigate('catalogue')}
                className="px-4 py-2 text-xs font-semibold text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded-lg transition-colors"
              >
                Browse Catalogue
              </button>
            </div>
          ) : (
            <div className="space-y-3">
              {activeReservations.map((res) => (
                <div
                  key={res.id}
                  className="bg-slate-900/90 border border-slate-800 hover:border-cyan-500/40 rounded-2xl p-5 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                >
                  <div className="space-y-1.5">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-cyan-400 bg-cyan-950 border border-cyan-800 px-2 py-0.5 rounded">
                        {res.courseCode}
                      </span>
                      <span className="text-[11px] font-mono text-slate-400">
                        {res.confirmationCode}
                      </span>
                      <span className="text-[10px] font-semibold text-emerald-400 bg-emerald-950/80 px-2 py-0.5 rounded-full border border-emerald-800">
                        Active
                      </span>
                    </div>

                    <h4 className="text-base font-bold text-white">{res.courseTitle}</h4>

                    <div className="flex flex-wrap items-center gap-3 text-xs text-slate-400 pt-0.5">
                      <span className="flex items-center gap-1">
                        <Calendar className="w-3.5 h-3.5 text-cyan-400" />
                        {res.courseSchedule || 'Weekly Lecture'}
                      </span>
                      <span>•</span>
                      <span>Fee: ${res.courseFee} USD</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0 self-end sm:self-auto">
                    <button
                      onClick={() => onNavigate('my-reservations')}
                      className="px-3.5 py-1.5 text-xs font-semibold text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors"
                    >
                      View Details & Policy
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Right Column: Academic Calendar & Guidelines */}
        <div className="space-y-6">
          {/* Quick Notice Card */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 space-y-4">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Calendar className="w-4 h-4 text-cyan-400" /> Semester Lab Calendar
            </h3>
            <div className="space-y-3 text-xs text-slate-300">
              <div className="flex items-start gap-2.5">
                <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 mt-1.5 shrink-0" />
                <div>
                  <div className="font-semibold text-white">Course Reservation Window</div>
                  <div className="text-[11px] text-slate-400">Open until Nov 01, 2026</div>
                </div>
              </div>
              <div className="flex items-start gap-2.5">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 mt-1.5 shrink-0" />
                <div>
                  <div className="font-semibold text-white">Laboratory Onboarding</div>
                  <div className="text-[11px] text-slate-400">Engineering Labs 101 - 302</div>
                </div>
              </div>
              <div className="flex items-start gap-2.5">
                <span className="w-1.5 h-1.5 rounded-full bg-amber-400 mt-1.5 shrink-0" />
                <div>
                  <div className="font-semibold text-white">Cancellation Deadline</div>
                  <div className="text-[11px] text-slate-400">Up to 24h before lecture start</div>
                </div>
              </div>
            </div>
          </div>

          {/* College Lab Info */}
          <div className="bg-cyan-950/30 border border-cyan-800/40 rounded-2xl p-5 space-y-2 text-xs">
            <div className="font-bold text-cyan-300 flex items-center gap-1.5">
              <GraduationCap className="w-4 h-4" /> Software Engineering Lab
            </div>
            <p className="text-slate-300 leading-relaxed text-[11px]">
              Every reservation is recorded with an immutable audit timestamp. Seats cannot be double-booked or oversubscribed.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
