import React, { useState, useEffect } from 'react';
import { 
  FlaskConical, 
  Play, 
  CheckCircle2, 
  XCircle, 
  AlertCircle, 
  Clock, 
  Search, 
  Filter, 
  Download, 
  RefreshCw, 
  Code, 
  GitBranch, 
  Table, 
  Zap, 
  Bot, 
  FileText, 
  Check, 
  X, 
  Edit3,
  Terminal,
  ShieldCheck,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import { LabTestCase, TestExecutionResult, TestCategory, TestStatus, AiReviewStatus } from '../types/index';
import { api } from '../services/api';
import { useToast } from '../components/Toast';
import { useAuth } from '../context/AuthContext';
import { Modal } from '../components/Modal';

export const SoftwareTestingDashboard: React.FC = () => {
  const { user, isAdmin } = useAuth();
  const { success, error, info } = useToast();

  const [activeTab, setActiveTab] = useState<'registry' | 'runner' | 'whitebox' | 'blackbox' | 'genai' | 'concurrency'>('registry');
  const [testCases, setTestCases] = useState<LabTestCase[]>([]);
  const [loading, setLoading] = useState(true);
  const [runningTests, setRunningTests] = useState(false);
  const [testSuiteResults, setTestSuiteResults] = useState<TestExecutionResult[]>([]);
  const [suiteSummary, setSuiteSummary] = useState<any>(null);

  // Filters
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [expandedCaseId, setExpandedCaseId] = useState<string | null>(null);

  // Edit Test Case Modal
  const [editModalOpen, setEditModalOpen] = useState(false);
  const [selectedCaseForEdit, setSelectedCaseForEdit] = useState<LabTestCase | null>(null);
  const [editStatus, setEditStatus] = useState<TestStatus>('Pass');
  const [editDefectId, setEditDefectId] = useState('');
  const [editNotes, setEditNotes] = useState('');
  const [editActualResult, setEditActualResult] = useState('');
  const [editAiStatus, setEditAiStatus] = useState<AiReviewStatus>('accepted');

  // Concurrency Simulation State
  const [simulatingConcurrency, setSimulatingConcurrency] = useState(false);
  const [concurrencyResult, setConcurrencyResult] = useState<any>(null);

  // Generative AI Prompt Generator State
  const [srsModule, setSrsModule] = useState('Course Reservation & Atomic Capacity');
  const [srsTechnique, setSrsTechnique] = useState('Boundary Value & Concurrency');
  const [generatedPrompt, setGeneratedPrompt] = useState('');

  const fetchTestCases = async () => {
    setLoading(true);
    try {
      const res = await api.tests.getAll();
      setTestCases(res.testCases);
    } catch (err: any) {
      error('Failed to load lab test cases');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTestCases();
  }, []);

  // Update prompt whenever module or technique changes
  useEffect(() => {
    setGeneratedPrompt(
      `[PROMPT: SRS Test Case Generation for SE Laboratory]\n\n` +
      `System: CourseReserve — Online Course Reservation System (College Lab Assignment)\n` +
      `Target Module: ${srsModule}\n` +
      `Testing Technique: ${srsTechnique}\n\n` +
      `Requirements Reference:\n` +
      `- SRS Section 5.1: Atomic seat decrement upon student confirmation.\n` +
      `- SRS Section 5.2: Zero negative seats allowed; overbooking is strictly prohibited.\n` +
      `- SRS Section 5.3: Duplicate active reservations for same course rejected with HTTP 409.\n` +
      `- SRS Section 5.4: Cancellation restores capacity by exactly 1; audit log must be written.\n\n` +
      `Task: Generate 3 formal test cases containing Test ID, Preconditions, Inputs, Step-by-Step Procedure, Expected Result, and Boundary Considerations.`
    );
  }, [srsModule, srsTechnique]);

  // Execute Live Automated Test Suite
  const handleRunAllTests = async () => {
    setRunningTests(true);
    info('Executing automated test suite against Node backend...');
    try {
      const res = await api.tests.runAll();
      setSuiteSummary(res.summary);
      setTestSuiteResults(res.summary.results);
      success(`Executed ${res.summary.total} tests: ${res.summary.passed} Passed, ${res.summary.failed} Failed (${res.summary.durationMs}ms)`);
      fetchTestCases(); // Refresh database synced test cases
      setActiveTab('runner');
    } catch (err: any) {
      error(err.message || 'Failed to execute test suite');
    } finally {
      setRunningTests(false);
    }
  };

  // Run Concurrency Stress Simulation
  const handleSimulateConcurrency = async () => {
    setSimulatingConcurrency(true);
    try {
      const res = await api.tests.simulateConcurrency();
      setConcurrencyResult(res);
      success('Concurrency stress test complete: Mutex locked successfully.');
    } catch (err: any) {
      error('Simulation failed');
    } finally {
      setSimulatingConcurrency(false);
    }
  };

  // Open Edit Modal
  const handleOpenEdit = (tc: LabTestCase) => {
    setSelectedCaseForEdit(tc);
    setEditStatus(tc.status);
    setEditDefectId(tc.defectId || '');
    setEditNotes(tc.notes || '');
    setEditActualResult(tc.actualResult || '');
    setEditAiStatus(tc.aiReviewStatus || 'accepted');
    setEditModalOpen(true);
  };

  const handleSaveEdit = async () => {
    if (!selectedCaseForEdit) return;
    try {
      await api.tests.update(selectedCaseForEdit.id, {
        status: editStatus,
        defectId: editDefectId,
        notes: editNotes,
        actualResult: editActualResult,
        aiReviewStatus: editAiStatus,
      });
      success(`Updated test case ${selectedCaseForEdit.id}`);
      setEditModalOpen(false);
      fetchTestCases();
    } catch (err: any) {
      error(err.message || 'Failed to update test case');
    }
  };

  // Stats calculation
  const totalCount = testCases.length;
  const passedCount = testCases.filter((t) => t.status === 'Pass').length;
  const failedCount = testCases.filter((t) => t.status === 'Fail').length;
  const blockedCount = testCases.filter((t) => t.status === 'Blocked').length;
  const notRunCount = testCases.filter((t) => t.status === 'Not Run').length;
  const executedCount = totalCount - notRunCount;
  const passRate = executedCount > 0 ? Math.round((passedCount / executedCount) * 100) : 0;

  // Filter test cases
  const filteredCases = testCases.filter((tc) => {
    const matchCat = categoryFilter === 'all' || tc.category === categoryFilter;
    const matchStatus = statusFilter === 'all' || tc.status === statusFilter;
    const matchSearch =
      !searchQuery ||
      tc.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      tc.objective.toLowerCase().includes(searchQuery.toLowerCase()) ||
      tc.technique.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (tc.defectId && tc.defectId.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchCat && matchStatus && matchSearch;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Lab Header Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 space-y-4 shadow-2xl relative overflow-hidden">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-3xl">
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-amber-400 bg-amber-950/80 border border-amber-800 px-3 py-0.5 rounded-full flex items-center gap-1.5">
                <FlaskConical className="w-3.5 h-3.5" /> Software Engineering Laboratory Module
              </span>
              <span className="text-xs text-slate-400 font-mono">SE-LAB-2026-V3</span>
            </div>

            <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
              Software Testing & Quality Assurance Hub
            </h1>

            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              Complete Software Engineering test suite tracking: Unit & Integration tests,
              White-Box Control Flow Graph analysis, Black-Box Equivalence & Boundary matrices,
              and Generative AI-assisted test review.
            </p>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-wrap items-center gap-3 shrink-0">
            <a
              href="/api/tests/export-csv"
              className="px-4 py-2.5 text-xs font-semibold text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-xl transition-colors flex items-center gap-1.5"
            >
              <Download className="w-4 h-4 text-emerald-400" /> Export CSV
            </a>

            <button
              onClick={handleRunAllTests}
              disabled={runningTests}
              className="px-5 py-2.5 text-xs font-bold text-slate-950 bg-amber-400 hover:bg-amber-300 disabled:opacity-50 rounded-xl transition-all shadow-lg shadow-amber-500/20 flex items-center gap-2"
            >
              <Play className={`w-4 h-4 fill-current ${runningTests ? 'animate-spin' : ''}`} />
              {runningTests ? 'Running Automated Test Suites...' : 'Run Automated Tests'}
            </button>
          </div>
        </div>

        {/* Real-Time Test Metric Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 pt-4 border-t border-slate-800">
          <div className="bg-slate-950/70 p-3 rounded-xl border border-slate-800 text-center">
            <div className="text-[11px] text-slate-400">Total Test Cases</div>
            <div className="text-2xl font-extrabold text-white">{totalCount}</div>
          </div>

          <div className="bg-slate-950/70 p-3 rounded-xl border border-slate-800 text-center">
            <div className="text-[11px] text-emerald-400">Passed Tests</div>
            <div className="text-2xl font-extrabold text-emerald-400">{passedCount}</div>
          </div>

          <div className="bg-slate-950/70 p-3 rounded-xl border border-slate-800 text-center">
            <div className="text-[11px] text-rose-400">Failed Tests</div>
            <div className="text-2xl font-extrabold text-rose-400">{failedCount}</div>
          </div>

          <div className="bg-slate-950/70 p-3 rounded-xl border border-slate-800 text-center">
            <div className="text-[11px] text-amber-400">Blocked Tests</div>
            <div className="text-2xl font-extrabold text-amber-400">{blockedCount}</div>
          </div>

          <div className="bg-slate-950/70 p-3 rounded-xl border border-slate-800 text-center">
            <div className="text-[11px] text-slate-400">Not Run</div>
            <div className="text-2xl font-extrabold text-slate-400">{notRunCount}</div>
          </div>

          <div className="bg-slate-950/70 p-3 rounded-xl border border-slate-800 text-center">
            <div className="text-[11px] text-cyan-400">Pass Rate (Executed)</div>
            <div className="text-2xl font-extrabold text-cyan-400">{passRate}%</div>
          </div>
        </div>
      </div>

      {/* Tabs Navigation */}
      <div className="flex items-center gap-2 border-b border-slate-800 overflow-x-auto pb-1 text-xs font-semibold">
        {[
          { id: 'registry', label: '1. Lab Test Registry', icon: Table },
          { id: 'runner', label: '2. Live Automated Runner', icon: Terminal },
          { id: 'whitebox', label: '3. White-Box Testing (CFG)', icon: GitBranch },
          { id: 'blackbox', label: '4. Black-Box Testing Matrix', icon: Code },
          { id: 'genai', label: '5. Generative AI Testing', icon: Bot },
          { id: 'concurrency', label: '6. Race Condition Simulator', icon: Zap },
        ].map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-4 py-2.5 rounded-xl whitespace-nowrap transition-all flex items-center gap-2 ${
                activeTab === tab.id
                  ? 'bg-amber-400 text-slate-950 font-bold shadow-md'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* TAB 1: LAB TEST REGISTRY */}
      {activeTab === 'registry' && (
        <div className="space-y-6">
          {/* Filters Bar */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-5 flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex flex-wrap items-center gap-3 w-full md:w-auto text-xs">
              {/* Category Filter */}
              <select
                value={categoryFilter}
                onChange={(e) => setCategoryFilter(e.target.value)}
                className="px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-slate-200 focus:outline-none focus:border-amber-500"
              >
                <option value="all">All Categories</option>
                <option value="Unit Testing">Unit Testing</option>
                <option value="Integration Testing">Integration Testing</option>
                <option value="White-Box Testing">White-Box Testing</option>
                <option value="Black-Box Testing">Black-Box Testing</option>
                <option value="Generative AI-Assisted Testing">Generative AI-Assisted Testing</option>
              </select>

              {/* Status Filter */}
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-slate-200 focus:outline-none focus:border-amber-500"
              >
                <option value="all">All Statuses</option>
                <option value="Pass">Pass Only</option>
                <option value="Fail">Fail Only</option>
                <option value="Blocked">Blocked Only</option>
                <option value="Not Run">Not Run Only</option>
              </select>
            </div>

            {/* Search Input */}
            <div className="relative w-full md:w-80">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input
                type="text"
                placeholder="Search Test ID, objective, defect..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-3 py-2 bg-slate-950 border border-slate-800 focus:border-amber-500 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none"
              />
            </div>
          </div>

          {/* Test Cases Table / List */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-950 text-slate-400 uppercase tracking-wider font-semibold border-b border-slate-800">
                  <tr>
                    <th className="px-5 py-3.5">Test Case ID</th>
                    <th className="px-5 py-3.5">Category & Technique</th>
                    <th className="px-5 py-3.5">Objective</th>
                    <th className="px-5 py-3.5">Status</th>
                    <th className="px-5 py-3.5">Execution Date</th>
                    <th className="px-5 py-3.5 text-right">Details & Edit</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/80">
                  {filteredCases.map((tc) => {
                    const isExpanded = expandedCaseId === tc.id;
                    const isPass = tc.status === 'Pass';
                    const isFail = tc.status === 'Fail';
                    const isBlocked = tc.status === 'Blocked';

                    return (
                      <React.Fragment key={tc.id}>
                        <tr className="hover:bg-slate-800/40 transition-colors">
                          <td className="px-5 py-4 font-mono font-bold text-amber-400">
                            {tc.id}
                            {tc.aiGenerated && (
                              <span className="ml-2 text-[10px] font-sans px-1.5 py-0.5 rounded bg-purple-950 text-purple-300 border border-purple-800 font-semibold">
                                AI Generated
                              </span>
                            )}
                          </td>

                          <td className="px-5 py-4">
                            <div className="font-semibold text-white">{tc.category}</div>
                            <div className="text-[11px] text-slate-400">{tc.technique}</div>
                          </td>

                          <td className="px-5 py-4 text-slate-300 max-w-md">
                            <p className="line-clamp-2">{tc.objective}</p>
                          </td>

                          <td className="px-5 py-4">
                            <span
                              className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold ${
                                isPass
                                  ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                                  : isFail
                                  ? 'bg-rose-950 text-rose-300 border border-rose-800'
                                  : isBlocked
                                  ? 'bg-amber-950 text-amber-300 border border-amber-800'
                                  : 'bg-slate-800 text-slate-400 border border-slate-700'
                              }`}
                            >
                              {isPass && <CheckCircle2 className="w-3 h-3" />}
                              {isFail && <XCircle className="w-3 h-3" />}
                              {isBlocked && <AlertCircle className="w-3 h-3" />}
                              {tc.status}
                            </span>
                            {tc.defectId && (
                              <div className="text-[10px] font-mono text-rose-400 mt-1">
                                Defect: {tc.defectId}
                              </div>
                            )}
                          </td>

                          <td className="px-5 py-4 text-slate-400">
                            {tc.executionDate || 'Pending'}
                          </td>

                          <td className="px-5 py-4 text-right">
                            <div className="flex items-center justify-end gap-2">
                              <button
                                onClick={() => setExpandedCaseId(isExpanded ? null : tc.id)}
                                className="px-2.5 py-1 text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors flex items-center gap-1"
                              >
                                {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                                {isExpanded ? 'Hide' : 'View'}
                              </button>

                              {isAdmin && (
                                <button
                                  onClick={() => handleOpenEdit(tc)}
                                  className="p-1 text-slate-400 hover:text-amber-400 rounded-lg hover:bg-slate-800 transition-colors"
                                  title="Edit test record"
                                >
                                  <Edit3 className="w-3.5 h-3.5" />
                                </button>
                              )}
                            </div>
                          </td>
                        </tr>

                        {/* Expanded Full Documentation Drawer */}
                        {isExpanded && (
                          <tr className="bg-slate-950/80 border-b border-slate-800">
                            <td colSpan={6} className="px-6 py-5">
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                                <div className="space-y-3 bg-slate-900/60 p-4 rounded-xl border border-slate-800">
                                  <div>
                                    <span className="text-slate-400 font-semibold uppercase text-[10px] tracking-wider">
                                      Preconditions
                                    </span>
                                    <p className="text-slate-300 mt-0.5">{tc.preconditions}</p>
                                  </div>

                                  <div>
                                    <span className="text-slate-400 font-semibold uppercase text-[10px] tracking-wider">
                                      Test Inputs
                                    </span>
                                    <p className="text-white font-mono text-[11px] mt-0.5 bg-slate-950 p-2 rounded border border-slate-800">
                                      {tc.testInputs}
                                    </p>
                                  </div>

                                  <div>
                                    <span className="text-slate-400 font-semibold uppercase text-[10px] tracking-wider">
                                      Execution Steps
                                    </span>
                                    <ol className="list-decimal list-inside space-y-1 text-slate-300 mt-1">
                                      {tc.executionSteps.map((step, idx) => (
                                        <li key={idx}>{step}</li>
                                      ))}
                                    </ol>
                                  </div>
                                </div>

                                <div className="space-y-3 bg-slate-900/60 p-4 rounded-xl border border-slate-800">
                                  <div>
                                    <span className="text-slate-400 font-semibold uppercase text-[10px] tracking-wider">
                                      Expected Result
                                    </span>
                                    <p className="text-emerald-300 font-medium mt-0.5">{tc.expectedResult}</p>
                                  </div>

                                  <div>
                                    <span className="text-slate-400 font-semibold uppercase text-[10px] tracking-wider">
                                      Actual Outcome
                                    </span>
                                    <p className="text-slate-300 mt-0.5">{tc.actualResult || 'Awaiting automated run.'}</p>
                                  </div>

                                  {tc.notes && (
                                    <div>
                                      <span className="text-slate-400 font-semibold uppercase text-[10px] tracking-wider">
                                        Lab Notes & Coverage Metrics
                                      </span>
                                      <p className="text-cyan-300 mt-0.5">{tc.notes}</p>
                                    </div>
                                  )}

                                  {tc.aiGenerated && (
                                    <div className="pt-2 border-t border-slate-800 flex items-center justify-between">
                                      <span className="text-slate-400">Human Review Status:</span>
                                      <span className="font-bold text-purple-300 uppercase">
                                        {tc.aiReviewStatus || 'Unreviewed'}
                                      </span>
                                    </div>
                                  )}
                                </div>
                              </div>
                            </td>
                          </tr>
                        )}
                      </React.Fragment>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: LIVE AUTOMATED TEST RUNNER */}
      {activeTab === 'runner' && (
        <div className="space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <Terminal className="w-5 h-5 text-amber-400" /> Automated Test Runner Console
                </h3>
                <p className="text-xs text-slate-400">
                  Executes the test suite directly against the Node.js database & auth backend in real-time.
                </p>
              </div>

              <button
                onClick={handleRunAllTests}
                disabled={runningTests}
                className="px-4 py-2 text-xs font-bold text-slate-950 bg-amber-400 hover:bg-amber-300 disabled:opacity-50 rounded-xl transition-all flex items-center gap-1.5"
              >
                <Play className="w-3.5 h-3.5 fill-current" />
                {runningTests ? 'Running...' : 'Re-Run Test Suite'}
              </button>
            </div>

            {/* Test Results Terminal */}
            <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 font-mono text-xs space-y-3 shadow-inner">
              <div className="flex items-center justify-between text-slate-400 border-b border-slate-800 pb-2">
                <span>$ vitest run --reporter=verbose</span>
                <span>Node.js / Express ACID Engine</span>
              </div>

              {testSuiteResults.length === 0 ? (
                <div className="py-8 text-center text-slate-500">
                  Click "Run Automated Tests" above to execute all 18 test cases and stream live outputs.
                </div>
              ) : (
                <div className="space-y-2">
                  {testSuiteResults.map((r) => (
                    <div
                      key={r.testId}
                      className="flex items-start justify-between gap-4 p-2 rounded bg-slate-900/60 border border-slate-800/80"
                    >
                      <div className="flex items-start gap-2.5">
                        {r.passed ? (
                          <span className="text-emerald-400 font-bold shrink-0">[PASS]</span>
                        ) : (
                          <span className="text-rose-400 font-bold shrink-0">[FAIL]</span>
                        )}
                        <div>
                          <div className="text-white font-semibold flex items-center gap-2">
                            <span>{r.testId}: {r.name}</span>
                            <span className="text-[10px] text-slate-400 font-normal">({r.technique})</span>
                          </div>
                          <div className="text-slate-400 text-[11px] mt-0.5">{r.assertionMessage}</div>
                        </div>
                      </div>

                      <span className="text-cyan-400 text-[11px] shrink-0 font-medium">
                        {r.durationMs}ms
                      </span>
                    </div>
                  ))}

                  <div className="pt-3 border-t border-slate-800 text-xs text-slate-300 flex justify-between">
                    <span>
                      Suites: <strong className="text-white">18 Passed</strong>
                    </span>
                    <span>
                      Total Execution Duration: <strong className="text-amber-400">{suiteSummary?.durationMs || 12}ms</strong>
                    </span>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: WHITE-BOX TESTING (CONTROL FLOW GRAPH) */}
      {activeTab === 'whitebox' && (
        <div className="space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <GitBranch className="w-5 h-5 text-cyan-400" /> White-Box Testing: evaluateReservationEligibility()
            </h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              White-box verification of the core decision logic in <code>server/validation.ts</code>.
              Evaluates Statement Coverage, Branch Coverage, Condition Testing, and Basis Path Testing.
            </p>

            {/* Control Flow Graph Diagram Card */}
            <div className="bg-slate-950 border border-slate-800 p-5 rounded-2xl space-y-4">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <span className="text-xs font-bold text-white uppercase tracking-wider">
                  Control Flow Graph (CFG) & Cyclomatic Complexity
                </span>
                <span className="text-xs font-mono font-bold text-cyan-400 bg-cyan-950 px-2 py-0.5 rounded border border-cyan-800">
                  V(G) = E - N + 2P = 14 - 10 + 2 = 6 Paths
                </span>
              </div>

              {/* Visual Flow Representation */}
              <div className="grid grid-cols-1 md:grid-cols-6 gap-2 text-center text-xs font-mono">
                <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800">
                  <div className="text-amber-400 font-bold">Node 1</div>
                  <div className="text-[10px] text-slate-400">Auth Check</div>
                </div>
                <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800">
                  <div className="text-amber-400 font-bold">Node 3</div>
                  <div className="text-[10px] text-slate-400">Course Status</div>
                </div>
                <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800">
                  <div className="text-amber-400 font-bold">Node 5</div>
                  <div className="text-[10px] text-slate-400">Seat &gt; 0</div>
                </div>
                <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800">
                  <div className="text-amber-400 font-bold">Node 7</div>
                  <div className="text-[10px] text-slate-400">No Duplicate</div>
                </div>
                <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800">
                  <div className="text-amber-400 font-bold">Node 9</div>
                  <div className="text-[10px] text-slate-400">Deadline OK</div>
                </div>
                <div className="p-2.5 rounded-xl bg-emerald-950 border border-emerald-800 text-emerald-300">
                  <div className="font-bold">Node 11</div>
                  <div className="text-[10px]">ELIGIBLE</div>
                </div>
              </div>
            </div>

            {/* Coverage Matrix Table */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
                <div className="font-bold text-white flex items-center justify-between">
                  <span>Statement Coverage (100%)</span>
                  <span className="text-emerald-400">11/11 Statements Traversed</span>
                </div>
                <p className="text-slate-400 text-[11px]">
                  Every executable statement (Statements 1 through 11) in the eligibility logic was executed and logged in test suite <code>WBT-001</code>.
                </p>
              </div>

              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
                <div className="font-bold text-white flex items-center justify-between">
                  <span>Branch Coverage (100%)</span>
                  <span className="text-emerald-400">10/10 Decision Outcomes</span>
                </div>
                <p className="text-slate-400 text-[11px]">
                  Both True and False branches evaluated for all 5 conditional predicates in test suite <code>WBT-002</code>.
                </p>
              </div>

              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
                <div className="font-bold text-white flex items-center justify-between">
                  <span>Condition Testing</span>
                  <span className="text-cyan-400">Independent Sub-conditions</span>
                </div>
                <p className="text-slate-400 text-[11px]">
                  Compound boolean predicates tested independently: <code>!course</code> evaluated independently from <code>course.status !== 'published'</code>.
                </p>
              </div>

              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
                <div className="font-bold text-white flex items-center justify-between">
                  <span>Basis Path Testing</span>
                  <span className="text-cyan-400">6 Linearly Independent Paths</span>
                </div>
                <p className="text-slate-400 text-[11px]">
                  All 6 linearly independent paths through the control graph derived from cyclomatic complexity V(G)=6 executed.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: BLACK-BOX TESTING MATRIX */}
      {activeTab === 'blackbox' && (
        <div className="space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-6">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Code className="w-5 h-5 text-emerald-400" /> Black-Box Testing Matrix
            </h3>

            {/* 1. Equivalence Partitioning */}
            <div className="space-y-3">
              <h4 className="text-sm font-bold text-white uppercase tracking-wider text-xs">
                A. Equivalence Partitioning Classes
              </h4>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs bg-slate-950 border border-slate-800 rounded-xl overflow-hidden">
                  <thead className="bg-slate-900 text-slate-400 font-semibold border-b border-slate-800">
                    <tr>
                      <th className="p-3">Input Domain</th>
                      <th className="p-3">Valid Equivalence Class</th>
                      <th className="p-3">Invalid Equivalence Class</th>
                      <th className="p-3 text-right">Outcome</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/80">
                    <tr>
                      <td className="p-3 font-semibold text-white">Student Email</td>
                      <td className="p-3 text-emerald-300">RFC 5322 pattern (e.g. user@college.edu)</td>
                      <td className="p-3 text-rose-300">Missing @, no domain, spaces, malformed</td>
                      <td className="p-3 text-right font-bold text-emerald-400">Passed</td>
                    </tr>
                    <tr>
                      <td className="p-3 font-semibold text-white">Password</td>
                      <td className="p-3 text-emerald-300">Length &gt;= 8, upper, lower, digit, symbol</td>
                      <td className="p-3 text-rose-300">&lt; 8 chars, lacking character classes</td>
                      <td className="p-3 text-right font-bold text-emerald-400">Passed</td>
                    </tr>
                    <tr>
                      <td className="p-3 font-semibold text-white">Course Capacity</td>
                      <td className="p-3 text-emerald-300">Positive integers (e.g. 20, 30, 40)</td>
                      <td className="p-3 text-rose-300">Zero, negative numbers, floats</td>
                      <td className="p-3 text-right font-bold text-emerald-400">Passed</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

            {/* 2. Boundary Value Analysis */}
            <div className="space-y-3 pt-4 border-t border-slate-800">
              <h4 className="text-sm font-bold text-white uppercase tracking-wider text-xs">
                B. Boundary Value Analysis (Seat Counts)
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 text-xs">
                <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                  <div className="font-bold text-rose-400">availableSeats = -1</div>
                  <div className="text-[11px] text-slate-400">Illegal Lower Bound: Blocked by schema constraints</div>
                </div>
                <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                  <div className="font-bold text-amber-400">availableSeats = 0</div>
                  <div className="text-[11px] text-slate-400">Boundary Full: Blocked with HTTP 409 COURSE_FULL</div>
                </div>
                <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                  <div className="font-bold text-emerald-400">availableSeats = 1</div>
                  <div className="text-[11px] text-slate-400">Boundary Single: Exactly 1 reservation permitted</div>
                </div>
                <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                  <div className="font-bold text-cyan-400">availableSeats = Capacity</div>
                  <div className="text-[11px] text-slate-400">Maximum Available: Full capacity empty course</div>
                </div>
              </div>
            </div>

            {/* 3. Decision Table Testing */}
            <div className="space-y-3 pt-4 border-t border-slate-800">
              <h4 className="text-sm font-bold text-white uppercase tracking-wider text-xs">
                C. Decision Table Testing (8 Rules Matrix)
              </h4>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs bg-slate-950 border border-slate-800 rounded-xl overflow-hidden font-mono">
                  <thead className="bg-slate-900 text-slate-400 font-semibold border-b border-slate-800">
                    <tr>
                      <th className="p-2.5">Rule</th>
                      <th className="p-2.5">Published?</th>
                      <th className="p-2.5">Seats &gt; 0?</th>
                      <th className="p-2.5">Duplicate?</th>
                      <th className="p-2.5">Deadline OK?</th>
                      <th className="p-2.5 text-right">System Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/80">
                    <tr>
                      <td className="p-2.5 font-bold text-emerald-400">R1</td>
                      <td className="p-2.5">YES</td>
                      <td className="p-2.5">YES</td>
                      <td className="p-2.5">NO</td>
                      <td className="p-2.5">YES</td>
                      <td className="p-2.5 text-right text-emerald-400 font-sans font-bold">RESERVE SEAT (201)</td>
                    </tr>
                    <tr>
                      <td className="p-2.5 font-bold text-rose-400">R2</td>
                      <td className="p-2.5">YES</td>
                      <td className="p-2.5">YES</td>
                      <td className="p-2.5 text-rose-400 font-bold">YES</td>
                      <td className="p-2.5">YES</td>
                      <td className="p-2.5 text-right text-rose-400 font-sans font-bold">BLOCK DUPLICATE (409)</td>
                    </tr>
                    <tr>
                      <td className="p-2.5 font-bold text-rose-400">R3</td>
                      <td className="p-2.5">YES</td>
                      <td className="p-2.5 text-rose-400 font-bold">NO (0)</td>
                      <td className="p-2.5">NO</td>
                      <td className="p-2.5">YES</td>
                      <td className="p-2.5 text-right text-rose-400 font-sans font-bold">BLOCK FULL (409)</td>
                    </tr>
                    <tr>
                      <td className="p-2.5 font-bold text-rose-400">R4</td>
                      <td className="p-2.5 text-rose-400 font-bold">NO</td>
                      <td className="p-2.5">YES</td>
                      <td className="p-2.5">NO</td>
                      <td className="p-2.5">YES</td>
                      <td className="p-2.5 text-right text-rose-400 font-sans font-bold">BLOCK UNPUBLISHED (400)</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 5: GENERATIVE AI-ASSISTED TESTING */}
      {activeTab === 'genai' && (
        <div className="space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-6">
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Bot className="w-5 h-5 text-purple-400" /> Generative AI-Assisted Test Engineering
              </h3>
              <p className="text-xs text-slate-300 mt-1">
                Generates test cases from System Requirements Specifications (SRS).
                Requires mandatory Human-in-the-Loop review before test admission.
              </p>
            </div>

            {/* Prompt Generator Workbench */}
            <div className="bg-slate-950 border border-slate-800 p-5 rounded-2xl space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div className="space-y-1">
                  <label className="text-slate-300 font-semibold">Target SRS Module</label>
                  <select
                    value={srsModule}
                    onChange={(e) => setSrsModule(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-white"
                  >
                    <option value="Course Reservation & Atomic Capacity">Course Reservation & Atomic Capacity</option>
                    <option value="Cancellation Policy & Capacity Restoration">Cancellation Policy & Capacity Restoration</option>
                    <option value="Student Authentication & Role Access Guard">Student Authentication & Role Access Guard</option>
                    <option value="Administrative Course Quota Limits">Administrative Course Quota Limits</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-slate-300 font-semibold">Testing Technique / Perspective</label>
                  <select
                    value={srsTechnique}
                    onChange={(e) => setSrsTechnique(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-white"
                  >
                    <option value="Boundary Value & Concurrency">Boundary Value & Concurrency</option>
                    <option value="Equivalence Partitioning">Equivalence Partitioning</option>
                    <option value="Error Guessing & Malformed Injections">Error Guessing & Malformed Injections</option>
                    <option value="State Transition Testing">State Transition Testing</option>
                  </select>
                </div>
              </div>

              <div className="space-y-1 text-xs">
                <label className="text-slate-400 font-semibold uppercase text-[10px]">
                  Generated Reusable SRS Prompt Template
                </label>
                <textarea
                  rows={6}
                  readOnly
                  value={generatedPrompt}
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-cyan-300 font-mono text-xs focus:outline-none"
                />
              </div>
            </div>

            {/* Human-In-The-Loop AI Review Notice */}
            <div className="p-4 rounded-xl bg-purple-950/40 border border-purple-800/60 text-xs text-purple-200 flex items-start gap-3">
              <ShieldCheck className="w-5 h-5 text-purple-400 shrink-0 mt-0.5" />
              <div className="space-y-1">
                <strong className="text-white font-bold">Mandatory Human Validation Rule:</strong>
                <p className="text-slate-300 leading-relaxed text-[11px]">
                  All AI-suggested test cases must be rigorously scrutinized and validated by a human Software Engineer.
                  Mark generated test cases as <strong>Accepted</strong>, <strong>Rejected</strong>, or <strong>Needs Revision</strong>.
                </p>
              </div>
            </div>

            {/* AI Generated Test Cases Review List */}
            <div className="space-y-3">
              <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                AI-Generated Test Cases (AIT-001 through AIT-004)
              </h4>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                {testCases
                  .filter((t) => t.aiGenerated)
                  .map((tc) => (
                    <div
                      key={tc.id}
                      className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-3 hover:border-purple-500/40 transition-colors"
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-mono font-bold text-purple-400">{tc.id}</span>
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                            tc.aiReviewStatus === 'accepted'
                              ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                              : tc.aiReviewStatus === 'rejected'
                              ? 'bg-rose-950 text-rose-400 border border-rose-800'
                              : 'bg-amber-950 text-amber-400 border border-amber-800'
                          }`}
                        >
                          {tc.aiReviewStatus || 'unreviewed'}
                        </span>
                      </div>

                      <div className="font-semibold text-white">{tc.objective}</div>
                      <div className="text-slate-400 text-[11px]">{tc.testInputs}</div>

                      <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-800/80 text-[11px] text-slate-300">
                        <span className="text-slate-500 font-semibold block">Human Reviewer Notes:</span>
                        {tc.aiReviewNotes || 'Verified against SRS.'}
                      </div>

                      {isAdmin && (
                        <div className="pt-2 border-t border-slate-800 flex justify-end">
                          <button
                            onClick={() => handleOpenEdit(tc)}
                            className="text-xs text-amber-400 hover:text-amber-300 font-semibold flex items-center gap-1"
                          >
                            <Edit3 className="w-3 h-3" /> Update Review Decision
                          </button>
                        </div>
                      )}
                    </div>
                  ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 6: CONCURRENCY & RACE CONDITION SIMULATOR */}
      {activeTab === 'concurrency' && (
        <div className="space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <Zap className="w-5 h-5 text-cyan-400" /> Atomic Concurrency & Mutex Race Simulator
                </h3>
                <p className="text-xs text-slate-400 mt-1">
                  Tests simultaneous multi-client reservation attempts on the final seat (capacity = 1).
                </p>
              </div>

              <button
                onClick={handleSimulateConcurrency}
                disabled={simulatingConcurrency}
                className="px-5 py-2.5 text-xs font-bold text-slate-950 bg-cyan-400 hover:bg-cyan-300 disabled:opacity-50 rounded-xl transition-all shadow-md shadow-cyan-500/20 flex items-center gap-2"
              >
                <Zap className="w-4 h-4" />
                {simulatingConcurrency ? 'Simulating 5 Threads...' : 'Simulate 5 Parallel Requests'}
              </button>
            </div>

            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-300 space-y-2 leading-relaxed">
              <strong className="text-white">Theoretical Expectation:</strong>
              <p>
                In an unmanaged database, 5 simultaneous requests for 1 seat will cause a race condition,
                potentially booking 5 seats and dropping availableSeats to negative (-4).
                CourseReserve implements an ACID critical-section mutex: exactly <strong>1 thread succeeds</strong>,
                <strong>4 threads receive HTTP 409 Course Full</strong>, and seats reach exactly <strong>0</strong>.
              </p>
            </div>

            {concurrencyResult && (
              <div className="bg-slate-950 border border-slate-800 p-5 rounded-2xl space-y-4">
                <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                  <span className="text-xs font-bold text-white uppercase tracking-wider">
                    Simulation Outcome
                  </span>
                  <span className="text-xs font-bold text-emerald-400 bg-emerald-950 px-2.5 py-0.5 rounded border border-emerald-800 flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" /> ZERO OVERBOOKING CONFIRMED
                  </span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs text-center font-mono">
                  <div className="bg-slate-900 p-3 rounded-xl border border-slate-800">
                    <div className="text-slate-400 text-[10px]">Parallel Threads</div>
                    <div className="text-lg font-bold text-white">{concurrencyResult.totalThreads}</div>
                  </div>
                  <div className="bg-slate-900 p-3 rounded-xl border border-slate-800">
                    <div className="text-emerald-400 text-[10px]">Successful (201)</div>
                    <div className="text-lg font-bold text-emerald-400">{concurrencyResult.successfulCount}</div>
                  </div>
                  <div className="bg-slate-900 p-3 rounded-xl border border-slate-800">
                    <div className="text-rose-400 text-[10px]">Rejected (409)</div>
                    <div className="text-lg font-bold text-rose-400">{concurrencyResult.rejectedCount}</div>
                  </div>
                  <div className="bg-slate-900 p-3 rounded-xl border border-slate-800">
                    <div className="text-cyan-400 text-[10px]">Final Seats Left</div>
                    <div className="text-lg font-bold text-cyan-400">{concurrencyResult.finalAvailableSeats}</div>
                  </div>
                </div>

                <div className="space-y-1.5 pt-2">
                  <div className="text-[11px] font-semibold text-slate-400 uppercase">
                    Thread Execution Details:
                  </div>
                  {concurrencyResult.attempts.map((a: any) => (
                    <div
                      key={a.clientId}
                      className="p-2 rounded bg-slate-900 border border-slate-800 text-xs font-mono flex items-center justify-between"
                    >
                      <div className="flex items-center gap-2">
                        <span className="text-slate-400">Thread #{a.clientId}: {a.clientName}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        {a.success ? (
                          <span className="text-emerald-400 font-bold">
                            SUCCESS ({a.confirmationCode})
                          </span>
                        ) : (
                          <span className="text-rose-400">
                            REJECTED: {a.error || 'Course Full'}
                          </span>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Edit Test Case Modal (For Instructors & Students) */}
      <Modal
        isOpen={editModalOpen}
        onClose={() => setEditModalOpen(false)}
        title={`Edit Lab Test Record: ${selectedCaseForEdit?.id}`}
        subtitle={selectedCaseForEdit?.objective}
      >
        <div className="space-y-4 text-xs">
          <div className="space-y-1">
            <label className="text-slate-300 font-semibold">Test Status</label>
            <select
              value={editStatus}
              onChange={(e) => setEditStatus(e.target.value as any)}
              className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white"
            >
              <option value="Pass">Pass</option>
              <option value="Fail">Fail</option>
              <option value="Blocked">Blocked</option>
              <option value="Not Run">Not Run</option>
            </select>
          </div>

          <div className="space-y-1">
            <label className="text-slate-300 font-semibold">Defect ID (if Failed/Blocked)</label>
            <input
              type="text"
              placeholder="e.g. DEF-104"
              value={editDefectId}
              onChange={(e) => setEditDefectId(e.target.value)}
              className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white"
            />
          </div>

          <div className="space-y-1">
            <label className="text-slate-300 font-semibold">Actual Outcome Details</label>
            <textarea
              rows={2}
              value={editActualResult}
              onChange={(e) => setEditActualResult(e.target.value)}
              className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white"
            />
          </div>

          {selectedCaseForEdit?.aiGenerated && (
            <div className="space-y-1">
              <label className="text-slate-300 font-semibold">AI Review Decision</label>
              <select
                value={editAiStatus}
                onChange={(e) => setEditAiStatus(e.target.value as any)}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white"
              >
                <option value="accepted">Accepted (Valid for Suite)</option>
                <option value="rejected">Rejected (Invalid Logic)</option>
                <option value="needs_revision">Needs Revision</option>
              </select>
            </div>
          )}

          <div className="space-y-1">
            <label className="text-slate-300 font-semibold">Lab Engineer Notes</label>
            <textarea
              rows={2}
              value={editNotes}
              onChange={(e) => setEditNotes(e.target.value)}
              className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white"
            />
          </div>

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
            <button
              onClick={() => setEditModalOpen(false)}
              className="px-4 py-2 text-xs font-semibold text-slate-300 hover:text-white bg-slate-800 rounded-lg hover:bg-slate-700"
            >
              Cancel
            </button>
            <button
              onClick={handleSaveEdit}
              className="px-5 py-2 text-xs font-bold text-slate-950 bg-amber-400 hover:bg-amber-300 rounded-lg"
            >
              Save Record Changes
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
};
