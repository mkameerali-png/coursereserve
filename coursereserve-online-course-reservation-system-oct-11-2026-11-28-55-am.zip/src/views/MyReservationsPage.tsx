import React, { useState, useEffect } from 'react';
import { 
  CalendarCheck, 
  Search, 
  Filter, 
  Calendar, 
  Clock, 
  AlertTriangle, 
  CheckCircle2, 
  XCircle, 
  RotateCcw, 
  Ticket, 
  ArrowLeft,
  Copy
} from 'lucide-react';
import { Reservation } from '../types/index';
import { api } from '../services/api';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../components/Toast';
import { Modal } from '../components/Modal';

interface MyReservationsPageProps {
  onNavigate: (view: string, params?: any) => void;
}

export const MyReservationsPage: React.FC<MyReservationsPageProps> = ({ onNavigate }) => {
  const { user } = useAuth();
  const { success, error } = useToast();

  const [reservations, setReservations] = useState<Reservation[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'completed' | 'cancelled'>('all');
  const [searchTerm, setSearchTerm] = useState<string>('');

  // Cancellation Modal State
  const [cancelModalOpen, setCancelModalOpen] = useState<boolean>(false);
  const [selectedResForCancel, setSelectedResForCancel] = useState<Reservation | null>(null);
  const [cancelReason, setCancelReason] = useState<string>('Schedule conflict with another university commitment.');
  const [isCancelling, setIsCancelling] = useState<boolean>(false);

  const fetchReservations = async () => {
    setLoading(true);
    try {
      const res = await api.reservations.getAll({
        status: statusFilter === 'all' ? undefined : statusFilter,
        search: searchTerm,
      });
      setReservations(res.reservations);
    } catch (err: any) {
      error(err.message || 'Failed to fetch reservations');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchReservations();
  }, [statusFilter, searchTerm]);

  const handleOpenCancelModal = (res: Reservation) => {
    setSelectedResForCancel(res);
    setCancelReason('Schedule conflict with another university commitment.');
    setCancelModalOpen(true);
  };

  const handleExecuteCancel = async () => {
    if (!selectedResForCancel) return;
    setIsCancelling(true);
    try {
      await api.reservations.cancel(selectedResForCancel.id, cancelReason);
      success(`Reservation ${selectedResForCancel.confirmationCode} cancelled. Seat atomically restored!`);
      setCancelModalOpen(false);
      setSelectedResForCancel(null);
      fetchReservations(); // Refresh list to reflect restored seat and cancelled status
    } catch (err: any) {
      error(err.message || 'Failed to cancel reservation');
    } finally {
      setIsCancelling(false);
    }
  };

  const handleCopyCode = (code: string) => {
    navigator.clipboard.writeText(code);
    success(`Copied: ${code}`);
  };

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-6">
        <div>
          <button
            onClick={() => onNavigate('student-dashboard')}
            className="inline-flex items-center gap-1.5 text-xs text-slate-400 hover:text-white mb-2 transition-colors"
          >
            <ArrowLeft className="w-3.5 h-3.5" /> Back to Dashboard
          </button>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            My Course Reservations
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Track active seat allocations, download confirmation IDs, and manage enrollment requests.
          </p>
        </div>

        <button
          onClick={() => onNavigate('catalogue')}
          className="self-start sm:self-auto px-4 py-2 text-xs font-bold text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded-xl transition-all shadow-md shadow-cyan-500/20"
        >
          + Reserve More Courses
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 sm:p-5 flex flex-col sm:flex-row items-center justify-between gap-4">
        {/* Status Filter Tabs */}
        <div className="flex items-center gap-1.5 bg-slate-950 p-1 rounded-xl border border-slate-800 w-full sm:w-auto text-xs">
          {(['all', 'active', 'completed', 'cancelled'] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setStatusFilter(tab)}
              className={`flex-1 sm:flex-initial px-3.5 py-1.5 rounded-lg capitalize font-medium transition-all ${
                statusFilter === tab
                  ? 'bg-cyan-400 text-slate-950 font-bold shadow-sm'
                  : 'text-slate-400 hover:text-white hover:bg-slate-900'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>

        {/* Search */}
        <div className="relative w-full sm:w-72">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            placeholder="Search by ID, course, or code..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3 py-2 bg-slate-950 border border-slate-800 focus:border-cyan-500 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none transition-colors"
          />
        </div>
      </div>

      {/* Reservation List */}
      {loading ? (
        <div className="space-y-4">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-32 bg-slate-900/50 rounded-2xl animate-pulse border border-slate-800" />
          ))}
        </div>
      ) : reservations.length === 0 ? (
        <div className="text-center py-16 bg-slate-900/40 border border-slate-800 rounded-2xl p-8 space-y-3">
          <CalendarCheck className="w-12 h-12 text-slate-500 mx-auto" />
          <h3 className="text-base font-bold text-white">No reservations found</h3>
          <p className="text-xs text-slate-400 max-w-sm mx-auto">
            {statusFilter !== 'all'
              ? `You do not have any ${statusFilter} reservations matching your search.`
              : 'You have not enrolled in any courses yet.'}
          </p>
          <button
            onClick={() => onNavigate('catalogue')}
            className="px-4 py-2 text-xs font-semibold text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded-lg transition-colors"
          >
            Browse Catalogue
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          {reservations.map((res) => {
            const isActive = res.reservationStatus === 'active';
            const isCancelled = res.reservationStatus === 'cancelled';
            const isCompleted = res.reservationStatus === 'completed';

            return (
              <div
                key={res.id}
                className={`bg-slate-900/90 border rounded-2xl p-5 sm:p-6 transition-all space-y-4 ${
                  isActive
                    ? 'border-slate-800 hover:border-cyan-500/40 shadow-lg'
                    : isCancelled
                    ? 'border-slate-800/60 opacity-80 bg-slate-950/40'
                    : 'border-slate-800'
                }`}
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800/80 pb-4">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-cyan-400 bg-cyan-950 border border-cyan-800 px-2 py-0.5 rounded">
                        {res.courseCode}
                      </span>
                      <h3 className="text-base font-bold text-white">{res.courseTitle}</h3>
                    </div>
                    <div className="text-xs text-slate-400">{res.courseCategory}</div>
                  </div>

                  {/* Status Badge */}
                  <div className="flex items-center gap-2">
                    {isActive && (
                      <span className="inline-flex items-center gap-1 text-xs font-semibold text-emerald-400 bg-emerald-950/80 border border-emerald-800 px-2.5 py-1 rounded-full">
                        <CheckCircle2 className="w-3.5 h-3.5" /> Active Guaranteed
                      </span>
                    )}
                    {isCompleted && (
                      <span className="inline-flex items-center gap-1 text-xs font-semibold text-blue-400 bg-blue-950/80 border border-blue-800 px-2.5 py-1 rounded-full">
                        <CheckCircle2 className="w-3.5 h-3.5" /> Completed
                      </span>
                    )}
                    {isCancelled && (
                      <span className="inline-flex items-center gap-1 text-xs font-semibold text-rose-400 bg-rose-950/80 border border-rose-800 px-2.5 py-1 rounded-full">
                        <XCircle className="w-3.5 h-3.5" /> Cancelled
                      </span>
                    )}
                  </div>
                </div>

                {/* Details Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                  <div className="bg-slate-950/60 p-3 rounded-xl border border-slate-800 space-y-1">
                    <span className="text-slate-400">Confirmation ID</span>
                    <div className="flex items-center justify-between">
                      <span className="font-mono font-bold text-cyan-400">{res.confirmationCode}</span>
                      <button
                        onClick={() => handleCopyCode(res.confirmationCode)}
                        className="text-slate-400 hover:text-white"
                        title="Copy confirmation ID"
                      >
                        <Copy className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  <div className="bg-slate-950/60 p-3 rounded-xl border border-slate-800 space-y-1">
                    <span className="text-slate-400">Class Schedule</span>
                    <div className="font-semibold text-slate-200 flex items-center gap-1.5 truncate">
                      <Calendar className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                      {res.courseSchedule || 'Weekly sessions'}
                    </div>
                  </div>

                  <div className="bg-slate-950/60 p-3 rounded-xl border border-slate-800 space-y-1">
                    <span className="text-slate-400">Fee / Reserved At</span>
                    <div className="font-semibold text-slate-200">
                      ${res.courseFee} USD • {new Date(res.reservedAt).toLocaleDateString()}
                    </div>
                  </div>
                </div>

                {/* Cancellation Feedback Note if Cancelled */}
                {isCancelled && (
                  <div className="p-3 rounded-xl bg-rose-950/30 border border-rose-900/40 text-xs text-rose-300 space-y-1">
                    <div className="font-semibold flex items-center gap-1.5">
                      <AlertTriangle className="w-3.5 h-3.5 text-rose-400" />
                      Cancelled on {new Date(res.cancelledAt!).toLocaleString()}
                    </div>
                    <div className="text-[11px] text-slate-400">
                      Reason: "{res.cancellationReason || 'User request'}" — Seat has been restored to course capacity.
                    </div>
                  </div>
                )}

                {/* Actions Bar */}
                {isActive && (
                  <div className="flex items-center justify-between pt-2 border-t border-slate-800/80">
                    <div className="text-[11px] text-slate-400 flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> Seat reserved under college academic policy.
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => handleOpenCancelModal(res)}
                        className="px-3 py-1.5 text-xs font-semibold text-rose-400 hover:text-rose-300 bg-rose-950/40 hover:bg-rose-950 border border-rose-800/60 rounded-lg transition-colors flex items-center gap-1"
                      >
                        <RotateCcw className="w-3 h-3" /> Cancel Reservation
                      </button>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Cancellation Confirmation Modal */}
      <Modal
        isOpen={cancelModalOpen}
        onClose={() => setCancelModalOpen(false)}
        title="Cancel Course Reservation"
        subtitle={`Reservation ${selectedResForCancel?.confirmationCode}`}
      >
        <div className="space-y-4">
          <div className="p-4 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs flex items-start gap-2.5">
            <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
            <div>
              <strong>Atomic Capacity Restoration:</strong> Cancelling this reservation will immediately restore 1 seat to the course capacity in the catalogue and invalidate your confirmation ID.
            </div>
          </div>

          <div className="space-y-1 text-xs">
            <label className="text-slate-300 font-semibold">Reason for Cancellation</label>
            <select
              value={cancelReason}
              onChange={(e) => setCancelReason(e.target.value)}
              className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-slate-200 focus:outline-none focus:border-cyan-500"
            >
              <option value="Schedule conflict with another university commitment.">
                Schedule conflict with another university commitment
              </option>
              <option value="Enrolled in an alternate section or elective course.">
                Enrolled in an alternate section or elective course
              </option>
              <option value="Personal circumstances / academic withdrawal.">
                Personal circumstances / academic withdrawal
              </option>
              <option value="Financial or administrative reassignment.">
                Financial or administrative reassignment
              </option>
            </select>
          </div>

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
            <button
              onClick={() => setCancelModalOpen(false)}
              className="px-4 py-2 text-xs font-semibold text-slate-300 hover:text-white bg-slate-800 rounded-lg hover:bg-slate-700"
            >
              Keep Reservation
            </button>
            <button
              onClick={handleExecuteCancel}
              disabled={isCancelling}
              className="px-4 py-2 text-xs font-bold text-white bg-rose-600 hover:bg-rose-500 disabled:opacity-50 rounded-lg transition-colors flex items-center gap-1.5"
            >
              {isCancelling ? 'Processing...' : 'Confirm Cancellation'}
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
};
