import React, { useState } from 'react';
import { 
  GraduationCap, 
  Lock, 
  Mail, 
  ArrowRight, 
  ShieldCheck, 
  Users, 
  AlertCircle,
  Sparkles
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../components/Toast';

interface LoginPageProps {
  onNavigate: (view: string, params?: any) => void;
}

export const LoginPage: React.FC<LoginPageProps> = ({ onNavigate }) => {
  const { login } = useAuth();
  const { success, error } = useToast();

  const [activeTab, setActiveTab] = useState<'student' | 'admin'>('student');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [formError, setFormError] = useState('');

  const fillCredentials = (userEmail: string, userPass: string, tab: 'student' | 'admin') => {
    setEmail(userEmail);
    setPassword(userPass);
    setActiveTab(tab);
    setFormError('');
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');

    if (!email || !password) {
      setFormError('Please enter both email and password.');
      return;
    }

    setLoading(true);
    try {
      const u = await login(email, password);
      success(`Welcome back, ${u.fullName}!`);
      if (u.role === 'admin') {
        onNavigate('admin-dashboard');
      } else {
        onNavigate('student-dashboard');
      }
    } catch (err: any) {
      setFormError(err.message || 'Login failed. Please check your credentials.');
      error(err.message || 'Login failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center px-4 py-12">
      <div className="w-full max-w-md space-y-6">
        {/* Brand Header */}
        <div className="text-center space-y-2">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-cyan-600 to-blue-600 flex items-center justify-center text-white mx-auto shadow-lg shadow-cyan-900/30">
            <GraduationCap className="w-7 h-7" />
          </div>
          <h1 className="text-2xl font-extrabold text-white tracking-tight">
            Sign In to CourseReserve
          </h1>
          <p className="text-xs text-slate-400">
            College Online Course Reservation & Testing System
          </p>
        </div>

        {/* Login Card */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6">
          {/* Role Tabs */}
          <div className="flex bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs font-semibold">
            <button
              type="button"
              onClick={() => {
                setActiveTab('student');
                setFormError('');
              }}
              className={`flex-1 py-2 rounded-lg flex items-center justify-center gap-1.5 transition-all ${
                activeTab === 'student'
                  ? 'bg-cyan-400 text-slate-950 font-bold shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Users className="w-3.5 h-3.5" /> Student Login
            </button>
            <button
              type="button"
              onClick={() => {
                setActiveTab('admin');
                setFormError('');
              }}
              className={`flex-1 py-2 rounded-lg flex items-center justify-center gap-1.5 transition-all ${
                activeTab === 'admin'
                  ? 'bg-amber-400 text-slate-950 font-bold shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <ShieldCheck className="w-3.5 h-3.5" /> Administrator
            </button>
          </div>

          {/* Error Banner */}
          {formError && (
            <div className="p-3.5 rounded-xl bg-rose-950/80 border border-rose-800 text-xs text-rose-200 flex items-start gap-2">
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
              <span>{formError}</span>
            </div>
          )}

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-1 text-xs">
              <label className="text-slate-300 font-semibold">Email Address</label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input
                  type="email"
                  placeholder={activeTab === 'admin' ? 'admin@college.edu' : 'student@college.edu'}
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="w-full pl-9 pr-3 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-white text-xs focus:outline-none focus:border-cyan-500 transition-colors"
                />
              </div>
            </div>

            <div className="space-y-1 text-xs">
              <label className="text-slate-300 font-semibold">Password</label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input
                  type="password"
                  placeholder="••••••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  className="w-full pl-9 pr-3 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-white text-xs focus:outline-none focus:border-cyan-500 transition-colors"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className={`w-full py-2.5 text-xs font-bold text-slate-950 rounded-xl transition-all shadow-md flex items-center justify-center gap-1.5 ${
                activeTab === 'admin'
                  ? 'bg-amber-400 hover:bg-amber-300 shadow-amber-500/20'
                  : 'bg-cyan-400 hover:bg-cyan-300 shadow-cyan-500/20'
              }`}
            >
              {loading ? 'Authenticating...' : `Log In as ${activeTab === 'admin' ? 'Administrator' : 'Student'}`}
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </form>

          {/* Quick Click Demo Fillers */}
          <div className="pt-2 border-t border-slate-800/80 space-y-2">
            <div className="text-[11px] font-semibold text-slate-400 flex items-center gap-1">
              <Sparkles className="w-3 h-3 text-cyan-400" /> Quick-Fill Demo Credentials:
            </div>
            <div className="grid grid-cols-1 gap-1.5 text-xs">
              <button
                type="button"
                onClick={() => fillCredentials('student@college.edu', 'StudentPassword123!', 'student')}
                className="w-full text-left px-3 py-2 rounded-lg bg-slate-950 hover:bg-slate-800 border border-slate-800/80 text-slate-300 hover:text-white flex items-center justify-between text-[11px]"
              >
                <span>Alex Rivera (Student)</span>
                <span className="font-mono text-cyan-400">student@college.edu</span>
              </button>
              <button
                type="button"
                onClick={() => fillCredentials('sarah.chen@college.edu', 'StudentPassword123!', 'student')}
                className="w-full text-left px-3 py-2 rounded-lg bg-slate-950 hover:bg-slate-800 border border-slate-800/80 text-slate-300 hover:text-white flex items-center justify-between text-[11px]"
              >
                <span>Sarah Chen (Student)</span>
                <span className="font-mono text-cyan-400">sarah.chen@college.edu</span>
              </button>
              <button
                type="button"
                onClick={() => fillCredentials('admin@college.edu', 'AdminPassword123!', 'admin')}
                className="w-full text-left px-3 py-2 rounded-lg bg-slate-950 hover:bg-slate-800 border border-slate-800/80 text-slate-300 hover:text-white flex items-center justify-between text-[11px]"
              >
                <span>Prof. Katherine Vance (Admin)</span>
                <span className="font-mono text-amber-400">admin@college.edu</span>
              </button>
            </div>
          </div>
        </div>

        {/* Footer Link */}
        <div className="text-center text-xs text-slate-400">
          Don't have a student account?{' '}
          <button
            onClick={() => onNavigate('register')}
            className="font-bold text-cyan-400 hover:text-cyan-300 transition-colors"
          >
            Register Student Account
          </button>
        </div>
      </div>
    </div>
  );
};
