import React, { useState } from 'react';
import { 
  GraduationCap, 
  Lock, 
  Mail, 
  User as UserIcon, 
  ArrowRight, 
  CheckCircle2, 
  AlertCircle,
  Building,
  Phone,
  ShieldCheck
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../components/Toast';

interface RegisterPageProps {
  onNavigate: (view: string, params?: any) => void;
}

export const RegisterPage: React.FC<RegisterPageProps> = ({ onNavigate }) => {
  const { register } = useAuth();
  const { success, error } = useToast();

  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [department, setDepartment] = useState('Computer Science');
  const [phone, setPhone] = useState('');
  const [loading, setLoading] = useState(false);
  const [formError, setFormError] = useState('');

  // Password Strength Indicators
  const hasMinLength = password.length >= 8;
  const hasLower = /[a-z]/.test(password);
  const hasUpper = /[A-Z]/.test(password);
  const hasNumber = /[0-9]/.test(password);
  const hasSpecial = /[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(password);
  const passwordsMatch = password.length > 0 && password === confirmPassword;

  const strengthScore = [hasMinLength, hasLower, hasUpper, hasNumber, hasSpecial].filter(Boolean).length;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');

    if (password !== confirmPassword) {
      setFormError('Password and confirmation password do not match.');
      return;
    }

    if (strengthScore < 4) {
      setFormError('Please satisfy at least 4 of the password security requirements.');
      return;
    }

    setLoading(true);
    try {
      const u = await register({
        fullName,
        email,
        password,
        confirmPassword,
        department,
        phone,
      });
      success(`Welcome to CourseReserve, ${u.fullName}! Your student account is active.`);
      onNavigate('student-dashboard');
    } catch (err: any) {
      setFormError(err.message || 'Registration failed.');
      error(err.message || 'Registration error');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-[85vh] flex items-center justify-center px-4 py-12">
      <div className="w-full max-w-lg space-y-6">
        {/* Header */}
        <div className="text-center space-y-2">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-cyan-600 to-blue-600 flex items-center justify-center text-white mx-auto shadow-lg shadow-cyan-900/30">
            <GraduationCap className="w-7 h-7" />
          </div>
          <h1 className="text-2xl font-extrabold text-white tracking-tight">
            Create Student Account
          </h1>
          <p className="text-xs text-slate-400">
            Join CourseReserve to enroll in university computer science laboratory courses.
          </p>
        </div>

        {/* Form Card */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6">
          {formError && (
            <div className="p-3.5 rounded-xl bg-rose-950/80 border border-rose-800 text-xs text-rose-200 flex items-start gap-2">
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
              <span>{formError}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-1 text-xs">
              <label className="text-slate-300 font-semibold">Full Legal Name *</label>
              <div className="relative">
                <UserIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input
                  type="text"
                  placeholder="e.g. Jordan Hayes"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  required
                  className="w-full pl-9 pr-3 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-white text-xs focus:outline-none focus:border-cyan-500"
                />
              </div>
            </div>

            <div className="space-y-1 text-xs">
              <label className="text-slate-300 font-semibold">College / University Email *</label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input
                  type="email"
                  placeholder="jordan.hayes@college.edu"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="w-full pl-9 pr-3 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-white text-xs focus:outline-none focus:border-cyan-500"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1 text-xs">
                <label className="text-slate-300 font-semibold">Department / Major</label>
                <div className="relative">
                  <Building className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <input
                    type="text"
                    value={department}
                    onChange={(e) => setDepartment(e.target.value)}
                    className="w-full pl-9 pr-3 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-white text-xs focus:outline-none focus:border-cyan-500"
                  />
                </div>
              </div>

              <div className="space-y-1 text-xs">
                <label className="text-slate-300 font-semibold">Contact Phone (Optional)</label>
                <div className="relative">
                  <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <input
                    type="tel"
                    placeholder="+1 (555) 012-3456"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full pl-9 pr-3 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-white text-xs focus:outline-none focus:border-cyan-500"
                  />
                </div>
              </div>
            </div>

            {/* Password */}
            <div className="space-y-1 text-xs">
              <label className="text-slate-300 font-semibold">Password *</label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input
                  type="password"
                  placeholder="Min 8 chars, uppercase, lowercase, number, symbol"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  className="w-full pl-9 pr-3 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-white text-xs focus:outline-none focus:border-cyan-500"
                />
              </div>
            </div>

            {/* Password Strength Checklist */}
            <div className="p-3 bg-slate-950/70 border border-slate-800/80 rounded-xl space-y-2">
              <div className="flex items-center justify-between text-[11px]">
                <span className="text-slate-400">Password Strength:</span>
                <span
                  className={`font-semibold ${
                    strengthScore >= 4
                      ? 'text-emerald-400'
                      : strengthScore >= 3
                      ? 'text-amber-400'
                      : 'text-rose-400'
                  }`}
                >
                  {strengthScore === 5
                    ? 'Very Strong'
                    : strengthScore >= 4
                    ? 'Strong'
                    : strengthScore >= 3
                    ? 'Medium'
                    : 'Weak'}
                </span>
              </div>

              {/* Strength bar */}
              <div className="grid grid-cols-5 gap-1 h-1.5 w-full">
                {Array.from({ length: 5 }).map((_, i) => (
                  <div
                    key={i}
                    className={`rounded-full transition-colors ${
                      i < strengthScore
                        ? strengthScore >= 4
                          ? 'bg-emerald-400'
                          : strengthScore >= 3
                          ? 'bg-amber-400'
                          : 'bg-rose-400'
                        : 'bg-slate-800'
                    }`}
                  />
                ))}
              </div>

              <div className="grid grid-cols-2 gap-1 text-[10px] text-slate-400 pt-1">
                <span className={hasMinLength ? 'text-emerald-400' : ''}>
                  • Min 8 characters
                </span>
                <span className={hasUpper ? 'text-emerald-400' : ''}>
                  • Uppercase letter
                </span>
                <span className={hasLower ? 'text-emerald-400' : ''}>
                  • Lowercase letter
                </span>
                <span className={hasNumber ? 'text-emerald-400' : ''}>
                  • Number (0-9)
                </span>
                <span className={hasSpecial ? 'text-emerald-400 col-span-2' : 'col-span-2'}>
                  • Special symbol (!@#$%^&*)
                </span>
              </div>
            </div>

            {/* Confirm Password */}
            <div className="space-y-1 text-xs">
              <label className="text-slate-300 font-semibold">Confirm Password *</label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input
                  type="password"
                  placeholder="Re-enter password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  required
                  className="w-full pl-9 pr-3 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-white text-xs focus:outline-none focus:border-cyan-500"
                />
              </div>
              {confirmPassword && (
                <div className="text-[11px] pt-0.5">
                  {passwordsMatch ? (
                    <span className="text-emerald-400 flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3" /> Passwords match
                    </span>
                  ) : (
                    <span className="text-rose-400 flex items-center gap-1">
                      <AlertCircle className="w-3 h-3" /> Passwords do not match
                    </span>
                  )}
                </div>
              )}
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-2.5 text-xs font-bold text-slate-950 bg-cyan-400 hover:bg-cyan-300 disabled:opacity-50 rounded-xl transition-all shadow-md shadow-cyan-500/20 flex items-center justify-center gap-1.5"
            >
              {loading ? 'Creating Account...' : 'Complete Student Registration'}
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </form>
        </div>

        {/* Footer Link */}
        <div className="text-center text-xs text-slate-400">
          Already registered?{' '}
          <button
            onClick={() => onNavigate('login')}
            className="font-bold text-cyan-400 hover:text-cyan-300 transition-colors"
          >
            Sign In to Existing Account
          </button>
        </div>
      </div>
    </div>
  );
};
