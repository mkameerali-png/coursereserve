import React, { useState, useEffect } from 'react';
import { 
  Layers, 
  Search, 
  Plus, 
  Edit2, 
  Trash2, 
  Eye, 
  EyeOff, 
  Archive, 
  ArrowLeft, 
  AlertTriangle, 
  CheckCircle2, 
  Users 
} from 'lucide-react';
import { Course } from '../types/index';
import { api } from '../services/api';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../components/Toast';
import { Modal } from '../components/Modal';

interface AdminCourseManagementProps {
  onNavigate: (view: string, params?: any) => void;
}

export const AdminCourseManagement: React.FC<AdminCourseManagementProps> = ({ onNavigate }) => {
  const { isAdmin } = useAuth();
  const { success, error } = useToast();

  const [courses, setCourses] = useState<Course[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');

  // Modal State
  const [modalOpen, setModalOpen] = useState(false);
  const [editingCourse, setEditingCourse] = useState<Course | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Form Fields
  const [title, setTitle] = useState('');
  const [code, setCode] = useState('');
  const [category, setCategory] = useState('Programming & Software');
  const [instructor, setInstructor] = useState('');
  const [instructorTitle, setInstructorTitle] = useState('Professor');
  const [duration, setDuration] = useState('8 Weeks');
  const [fee, setFee] = useState<number>(250);
  const [startDate, setStartDate] = useState('2026-11-15');
  const [schedule, setSchedule] = useState('Mon & Wed 10:00 AM - 11:30 AM');
  const [capacity, setCapacity] = useState<number>(30);
  const [location, setLocation] = useState('Computer Lab 201');
  const [formError, setFormError] = useState('');

  const fetchCourses = async () => {
    setLoading(true);
    try {
      const res = await api.courses.getAll({
        search: searchTerm,
        status: statusFilter,
      });
      setCourses(res.courses);
    } catch (err: any) {
      error(err.message || 'Failed to load courses');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isAdmin) {
      fetchCourses();
    }
  }, [isAdmin, searchTerm, statusFilter]);

  const handleOpenCreateModal = () => {
    setEditingCourse(null);
    setTitle('');
    setCode('');
    setCategory('Programming & Software');
    setInstructor('');
    setInstructorTitle('Professor');
    setDuration('8 Weeks');
    setFee(250);
    setStartDate('2026-11-15');
    setSchedule('Mon & Wed 10:00 AM - 11:30 AM');
    setCapacity(30);
    setLocation('Computer Lab 201');
    setFormError('');
    setModalOpen(true);
  };

  const handleOpenEditModal = (c: Course) => {
    setEditingCourse(c);
    setTitle(c.title);
    setCode(c.code);
    setCategory(c.category);
    setInstructor(c.instructor);
    setInstructorTitle(c.instructorTitle || 'Professor');
    setDuration(c.duration);
    setFee(c.fee);
    setStartDate(c.startDate);
    setSchedule(c.schedule);
    setCapacity(c.capacity);
    setLocation(c.location || 'Computer Lab 201');
    setFormError('');
    setModalOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');

    if (fee < 0) {
      setFormError('Course fee cannot be negative.');
      return;
    }

    if (capacity <= 0) {
      setFormError('Course capacity must be greater than zero.');
      return;
    }

    setIsSubmitting(true);
    try {
      const payload: Partial<Course> = {
        title,
        code,
        category,
        instructor,
        instructorTitle,
        duration,
        fee: Number(fee),
        startDate,
        schedule,
        capacity: Number(capacity),
        location,
      };

      if (editingCourse) {
        await api.courses.update(editingCourse.id, payload);
        success(`Course ${code} updated successfully.`);
      } else {
        await api.courses.create(payload);
        success(`Course ${code} created successfully.`);
      }

      setModalOpen(false);
      fetchCourses();
    } catch (err: any) {
      setFormError(err.message || 'Failed to save course.');
      error(err.message || 'Course save error');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleToggleStatus = async (c: Course, newStatus: string) => {
    try {
      await api.courses.updateStatus(c.id, newStatus);
      success(`Course ${c.code} status changed to ${newStatus}.`);
      fetchCourses();
    } catch (err: any) {
      error(err.message || 'Failed to update course status');
    }
  };

  const handleDeleteCourse = async (c: Course) => {
    if (!window.confirm(`Are you sure you want to delete course ${c.code}? This action is irreversible.`)) {
      return;
    }
    try {
      await api.courses.delete(c.id);
      success(`Course ${c.code} removed from catalogue.`);
      fetchCourses();
    } catch (err: any) {
      error(err.message || 'Cannot delete course');
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-6">
        <div>
          <button
            onClick={() => onNavigate('admin-dashboard')}
            className="inline-flex items-center gap-1.5 text-xs text-slate-400 hover:text-white mb-2 transition-colors"
          >
            <ArrowLeft className="w-3.5 h-3.5" /> Back to Admin Dashboard
          </button>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            Course Management & Capacity
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Create, edit, publish/unpublish, and control seat quotas for university courses.
          </p>
        </div>

        <button
          onClick={handleOpenCreateModal}
          className="self-start sm:self-auto px-4 py-2 text-xs font-bold text-slate-950 bg-amber-400 hover:bg-amber-300 rounded-xl transition-all shadow-md shadow-amber-500/20 flex items-center gap-1.5"
        >
          <Plus className="w-4 h-4" /> Add New Course
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 sm:p-5 flex flex-col sm:flex-row items-center justify-between gap-4">
        {/* Status Filters */}
        <div className="flex items-center gap-1.5 bg-slate-950 p-1 rounded-xl border border-slate-800 w-full sm:w-auto text-xs">
          {[
            { id: 'all', label: 'All Courses' },
            { id: 'published', label: 'Published' },
            { id: 'unpublished', label: 'Draft / Unpublished' },
            { id: 'archived', label: 'Archived' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setStatusFilter(tab.id)}
              className={`flex-1 sm:flex-initial px-3 py-1.5 rounded-lg font-medium transition-all ${
                statusFilter === tab.id
                  ? 'bg-amber-400 text-slate-950 font-bold shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Search Input */}
        <div className="relative w-full sm:w-72">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            placeholder="Search code, title, instructor..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3 py-2 bg-slate-950 border border-slate-800 focus:border-amber-500 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none"
          />
        </div>
      </div>

      {/* Course Management Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950 text-slate-400 uppercase tracking-wider font-semibold border-b border-slate-800">
              <tr>
                <th className="px-5 py-3.5">Code & Title</th>
                <th className="px-5 py-3.5">Category</th>
                <th className="px-5 py-3.5">Instructor</th>
                <th className="px-5 py-3.5">Capacity & Seats</th>
                <th className="px-5 py-3.5">Fee</th>
                <th className="px-5 py-3.5">Status</th>
                <th className="px-5 py-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80">
              {loading ? (
                <tr>
                  <td colSpan={7} className="px-5 py-8 text-center text-slate-500">
                    Loading courses...
                  </td>
                </tr>
              ) : courses.length === 0 ? (
                <tr>
                  <td colSpan={7} className="px-5 py-12 text-center text-slate-500">
                    No courses match the current filter.
                  </td>
                </tr>
              ) : (
                courses.map((c) => {
                  const isFull = c.availableSeats <= 0;
                  const isPublished = c.status === 'published';

                  return (
                    <tr key={c.id} className="hover:bg-slate-800/40 transition-colors">
                      <td className="px-5 py-4">
                        <div className="font-bold text-white flex items-center gap-2">
                          <span className="font-mono text-cyan-400">{c.code}</span>
                          <span>{c.title}</span>
                        </div>
                        <div className="text-[11px] text-slate-400 mt-0.5">{c.duration} • Starts {c.startDate}</div>
                      </td>

                      <td className="px-5 py-4 text-slate-300">
                        {c.category}
                      </td>

                      <td className="px-5 py-4">
                        <div className="font-medium text-white">{c.instructor}</div>
                        <div className="text-[11px] text-slate-400">{c.instructorTitle}</div>
                      </td>

                      <td className="px-5 py-4">
                        <div className="flex items-center gap-2">
                          <span className={`font-bold ${isFull ? 'text-rose-400' : 'text-emerald-400'}`}>
                            {c.availableSeats}
                          </span>
                          <span className="text-slate-400">/ {c.capacity}</span>
                        </div>
                        <div className="text-[10px] text-slate-500">
                          {c.capacity - c.availableSeats} Students Enrolled
                        </div>
                      </td>

                      <td className="px-5 py-4 font-bold text-white">
                        ${c.fee}
                      </td>

                      <td className="px-5 py-4">
                        <span
                          className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold ${
                            c.status === 'published'
                              ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                              : c.status === 'unpublished'
                              ? 'bg-slate-800 text-slate-300 border border-slate-700'
                              : 'bg-rose-950 text-rose-300 border border-rose-800'
                          }`}
                        >
                          {c.status}
                        </span>
                      </td>

                      <td className="px-5 py-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => handleOpenEditModal(c)}
                            className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
                            title="Edit course"
                          >
                            <Edit2 className="w-4 h-4" />
                          </button>

                          {isPublished ? (
                            <button
                              onClick={() => handleToggleStatus(c, 'unpublished')}
                              className="p-1.5 text-slate-400 hover:text-amber-400 hover:bg-slate-800 rounded-lg transition-colors"
                              title="Unpublish course"
                            >
                              <EyeOff className="w-4 h-4" />
                            </button>
                          ) : (
                            <button
                              onClick={() => handleToggleStatus(c, 'published')}
                              className="p-1.5 text-slate-400 hover:text-emerald-400 hover:bg-slate-800 rounded-lg transition-colors"
                              title="Publish course"
                            >
                              <Eye className="w-4 h-4" />
                            </button>
                          )}

                          <button
                            onClick={() => handleToggleStatus(c, 'archived')}
                            className="p-1.5 text-slate-400 hover:text-rose-400 hover:bg-slate-800 rounded-lg transition-colors"
                            title="Archive course"
                          >
                            <Archive className="w-4 h-4" />
                          </button>

                          <button
                            onClick={() => handleDeleteCourse(c)}
                            className="p-1.5 text-slate-400 hover:text-rose-500 hover:bg-rose-500/10 rounded-lg transition-colors"
                            title="Delete course"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add / Edit Course Modal */}
      <Modal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        title={editingCourse ? `Edit Course ${editingCourse.code}` : 'Add New Academic Course'}
        subtitle="Server-authoritative course attributes and capacity quota"
        maxWidth="2xl"
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          {formError && (
            <div className="p-3 rounded-xl bg-rose-950/80 border border-rose-800 text-xs text-rose-200">
              {formError}
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
            <div className="space-y-1">
              <label className="text-slate-300 font-semibold">Course Code *</label>
              <input
                type="text"
                placeholder="CS-101"
                value={code}
                onChange={(e) => setCode(e.target.value)}
                required
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white font-mono focus:outline-none focus:border-amber-500"
              />
            </div>

            <div className="sm:col-span-2 space-y-1">
              <label className="text-slate-300 font-semibold">Course Title *</label>
              <input
                type="text"
                placeholder="e.g. Advanced Operating Systems"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                required
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white focus:outline-none focus:border-amber-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            <div className="space-y-1">
              <label className="text-slate-300 font-semibold">Category *</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white focus:outline-none focus:border-amber-500"
              >
                <option value="Programming & Software">Programming & Software</option>
                <option value="Web Technologies">Web Technologies</option>
                <option value="Core Computer Science">Core Computer Science</option>
                <option value="Artificial Intelligence">Artificial Intelligence</option>
                <option value="Systems & Architecture">Systems & Architecture</option>
                <option value="Software Engineering">Software Engineering</option>
              </select>
            </div>

            <div className="space-y-1">
              <label className="text-slate-300 font-semibold">Instructor Name *</label>
              <input
                type="text"
                placeholder="Dr. Jane Smith"
                value={instructor}
                onChange={(e) => setInstructor(e.target.value)}
                required
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white focus:outline-none focus:border-amber-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
            <div className="space-y-1">
              <label className="text-slate-300 font-semibold">Total Capacity (Seats) *</label>
              <input
                type="number"
                min="1"
                value={capacity}
                onChange={(e) => setCapacity(Number(e.target.value))}
                required
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white focus:outline-none focus:border-amber-500"
              />
            </div>

            <div className="space-y-1">
              <label className="text-slate-300 font-semibold">Course Fee ($ USD) *</label>
              <input
                type="number"
                min="0"
                value={fee}
                onChange={(e) => setFee(Number(e.target.value))}
                required
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white focus:outline-none focus:border-amber-500"
              />
            </div>

            <div className="space-y-1">
              <label className="text-slate-300 font-semibold">Start Date *</label>
              <input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                required
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white focus:outline-none focus:border-amber-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            <div className="space-y-1">
              <label className="text-slate-300 font-semibold">Weekly Schedule</label>
              <input
                type="text"
                placeholder="Tue & Thu 10:00 AM - 11:30 AM"
                value={schedule}
                onChange={(e) => setSchedule(e.target.value)}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white focus:outline-none focus:border-amber-500"
              />
            </div>

            <div className="space-y-1">
              <label className="text-slate-300 font-semibold">Duration</label>
              <input
                type="text"
                placeholder="8 Weeks"
                value={duration}
                onChange={(e) => setDuration(e.target.value)}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white focus:outline-none focus:border-amber-500"
              />
            </div>
          </div>

          <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-800">
            <button
              type="button"
              onClick={() => setModalOpen(false)}
              className="px-4 py-2 text-xs font-semibold text-slate-300 hover:text-white bg-slate-800 rounded-lg hover:bg-slate-700"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-5 py-2 text-xs font-bold text-slate-950 bg-amber-400 hover:bg-amber-300 disabled:opacity-50 rounded-lg transition-colors"
            >
              {isSubmitting ? 'Saving Course...' : editingCourse ? 'Save Updates' : 'Create Course'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
