import { 
  User, 
  Course, 
  Reservation, 
  AuditLog, 
  LabTestCase, 
  AdminStats, 
  TestExecutionResult 
} from '../types/index';

const API_BASE = '/api';

function getAuthHeaders(): HeadersInit {
  const token = localStorage.getItem('coursereserve_token');
  const headers: HeadersInit = {
    'Content-Type': 'application/json',
  };
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }
  return headers;
}

async function request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const url = `${API_BASE}${endpoint}`;
  const headers = {
    ...getAuthHeaders(),
    ...(options.headers || {}),
  };

  const response = await fetch(url, { ...options, headers });
  const data = await response.json().catch(() => ({}));

  if (!response.ok) {
    const errorMsg = data.error || (data.errors && data.errors[0]) || `Request failed with status ${response.status}`;
    throw new Error(errorMsg);
  }

  return data as T;
}

export const api = {
  // Auth
  auth: {
    async register(payload: any): Promise<{ message: string; user: User; token: string }> {
      return request('/auth/register', {
        method: 'POST',
        body: JSON.stringify(payload),
      });
    },

    async login(payload: { email: string; password: string }): Promise<{ message: string; user: User; token: string }> {
      return request('/auth/login', {
        method: 'POST',
        body: JSON.stringify(payload),
      });
    },

    async getMe(): Promise<{ user: User }> {
      return request('/auth/me');
    },

    async updateProfile(payload: Partial<User>): Promise<{ message: string; user: User }> {
      return request('/auth/profile', {
        method: 'PUT',
        body: JSON.stringify(payload),
      });
    },
  },

  // Courses
  courses: {
    async getAll(params?: {
      search?: string;
      category?: string;
      status?: string;
      sortBy?: string;
      sortOrder?: string;
    }): Promise<{ courses: Course[]; total: number }> {
      const query = new URLSearchParams();
      if (params?.search) query.set('search', params.search);
      if (params?.category) query.set('category', params.category);
      if (params?.status) query.set('status', params.status);
      if (params?.sortBy) query.set('sortBy', params.sortBy);
      if (params?.sortOrder) query.set('sortOrder', params.sortOrder);

      const qs = query.toString() ? `?${query.toString()}` : '';
      return request(`/courses${qs}`);
    },

    async getById(id: string): Promise<{ course: Course }> {
      return request(`/courses/${id}`);
    },

    async create(payload: Partial<Course>): Promise<{ message: string; course: Course }> {
      return request('/courses', {
        method: 'POST',
        body: JSON.stringify(payload),
      });
    },

    async update(id: string, payload: Partial<Course>): Promise<{ message: string; course: Course }> {
      return request(`/courses/${id}`, {
        method: 'PUT',
        body: JSON.stringify(payload),
      });
    },

    async updateStatus(id: string, status: string): Promise<{ message: string; course: Course }> {
      return request(`/courses/${id}/status`, {
        method: 'PATCH',
        body: JSON.stringify({ status }),
      });
    },

    async delete(id: string): Promise<{ message: string }> {
      return request(`/courses/${id}`, {
        method: 'DELETE',
      });
    },
  },

  // Reservations
  reservations: {
    async getAll(params?: {
      status?: string;
      search?: string;
      courseId?: string;
      studentId?: string;
    }): Promise<{ reservations: Reservation[]; total: number }> {
      const query = new URLSearchParams();
      if (params?.status) query.set('status', params.status);
      if (params?.search) query.set('search', params.search);
      if (params?.courseId) query.set('courseId', params.courseId);
      if (params?.studentId) query.set('studentId', params.studentId);

      const qs = query.toString() ? `?${query.toString()}` : '';
      return request(`/reservations${qs}`);
    },

    async getById(id: string): Promise<{ reservation: Reservation }> {
      return request(`/reservations/${id}`);
    },

    async create(courseId: string, targetStudentId?: string): Promise<{ message: string; reservation: Reservation }> {
      return request('/reservations', {
        method: 'POST',
        body: JSON.stringify({ courseId, targetStudentId }),
      });
    },

    async cancel(reservationId: string, reason?: string): Promise<{ message: string; reservation: Reservation }> {
      return request(`/reservations/${reservationId}/cancel`, {
        method: 'POST',
        body: JSON.stringify({ reason }),
      });
    },

    getExportCsvUrl(): string {
      const token = localStorage.getItem('coursereserve_token') || '';
      return `/api/reservations/export?token=${token}`;
    },
  },

  // Admin
  admin: {
    async getStats(): Promise<{ stats: AdminStats }> {
      return request('/admin/stats');
    },

    async getAuditLogs(): Promise<{ logs: AuditLog[] }> {
      return request('/admin/audit-logs');
    },

    async resetDemo(): Promise<{ message: string }> {
      return request('/system/reset-demo', {
        method: 'POST',
      });
    },
  },

  // Testing Dashboard
  tests: {
    async getAll(): Promise<{ testCases: LabTestCase[] }> {
      return request('/tests');
    },

    async runAll(): Promise<{
      message: string;
      summary: {
        total: number;
        passed: number;
        failed: number;
        durationMs: number;
        passPercentage: number;
        results: TestExecutionResult[];
      };
    }> {
      return request('/tests/run-all', {
        method: 'POST',
      });
    },

    async update(id: string, updates: Partial<LabTestCase>): Promise<{ message: string; testCase: LabTestCase }> {
      return request(`/tests/${id}`, {
        method: 'PUT',
        body: JSON.stringify(updates),
      });
    },

    async simulateConcurrency(): Promise<{
      totalThreads: number;
      initialAvailableSeats: number;
      durationMs: number;
      successfulCount: number;
      rejectedCount: number;
      finalAvailableSeats: number;
      zeroOverbookingConfirmed: boolean;
      attempts: Array<{
        clientId: number;
        clientName: string;
        success: boolean;
        status: number;
        confirmationCode?: string;
        error?: string;
      }>;
    }> {
      return request('/tests/simulate-concurrency', {
        method: 'POST',
      });
    },

    getExportCsvUrl(): string {
      return `/api/tests/export-csv`;
    },
  },
};
