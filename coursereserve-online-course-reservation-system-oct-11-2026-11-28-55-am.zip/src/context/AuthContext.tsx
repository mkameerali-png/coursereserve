import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, UserRole } from '../types/index';
import { api } from '../services/api';

interface AuthContextType {
  user: User | null;
  token: string | null;
  loading: boolean;
  login: (email: string, password: string) => Promise<User>;
  register: (payload: any) => Promise<User>;
  logout: () => void;
  updateUser: (updates: Partial<User>) => Promise<User>;
  quickLogin: (type: 'admin' | 'student1' | 'student2') => Promise<User>;
  isAdmin: boolean;
  isStudent: boolean;
  isAuthenticated: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(localStorage.getItem('coursereserve_token'));
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    async function loadUser() {
      const storedToken = localStorage.getItem('coursereserve_token');
      if (storedToken) {
        try {
          const res = await api.auth.getMe();
          setUser(res.user);
        } catch {
          localStorage.removeItem('coursereserve_token');
          setToken(null);
          setUser(null);
        }
      }
      setLoading(false);
    }
    loadUser();
  }, []);

  const login = async (email: string, password: string): Promise<User> => {
    const res = await api.auth.login({ email, password });
    localStorage.setItem('coursereserve_token', res.token);
    setToken(res.token);
    setUser(res.user);
    return res.user;
  };

  const register = async (payload: any): Promise<User> => {
    const res = await api.auth.register(payload);
    localStorage.setItem('coursereserve_token', res.token);
    setToken(res.token);
    setUser(res.user);
    return res.user;
  };

  const logout = () => {
    localStorage.removeItem('coursereserve_token');
    setToken(null);
    setUser(null);
  };

  const updateUser = async (updates: Partial<User>): Promise<User> => {
    const res = await api.auth.updateProfile(updates);
    setUser(res.user);
    return res.user;
  };

  const quickLogin = async (type: 'admin' | 'student1' | 'student2'): Promise<User> => {
    if (type === 'admin') {
      return login('admin@college.edu', 'AdminPassword123!');
    } else if (type === 'student1') {
      return login('student@college.edu', 'StudentPassword123!');
    } else {
      return login('sarah.chen@college.edu', 'StudentPassword123!');
    }
  };

  const isAdmin = user?.role === 'admin';
  const isStudent = user?.role === 'student';
  const isAuthenticated = !!user;

  return (
    <AuthContext.Provider
      value={{
        user,
        token,
        loading,
        login,
        register,
        logout,
        updateUser,
        quickLogin,
        isAdmin,
        isStudent,
        isAuthenticated,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
