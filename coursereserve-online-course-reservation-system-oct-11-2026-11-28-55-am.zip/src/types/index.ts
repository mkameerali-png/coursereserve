export type UserRole = 'student' | 'admin';

export interface User {
  id: string;
  fullName: string;
  email: string;
  role: UserRole;
  studentIdCode?: string;
  department?: string;
  phone?: string;
  createdAt: string;
}

export type CourseStatus = 'published' | 'unpublished' | 'archived';

export interface Course {
  id: string;
  code: string;
  title: string;
  description: string;
  category: string;
  instructor: string;
  instructorTitle?: string;
  duration: string;
  fee: number;
  startDate: string;
  schedule: string;
  capacity: number;
  availableSeats: number;
  status: CourseStatus;
  credits?: number;
  prerequisites?: string[];
  location?: string;
  createdAt: string;
  updatedAt: string;
}

export type ReservationStatus = 'active' | 'completed' | 'cancelled';

export interface Reservation {
  id: string;
  studentId: string;
  studentName?: string;
  studentEmail?: string;
  courseId: string;
  courseTitle?: string;
  courseCode?: string;
  courseCategory?: string;
  courseSchedule?: string;
  courseStartDate?: string;
  courseFee?: number;
  reservationStatus: ReservationStatus;
  reservedAt: string;
  cancelledAt?: string;
  cancellationReason?: string;
  confirmationCode: string;
}

export interface AuditLog {
  id: string;
  userId: string;
  userEmail: string;
  userRole: UserRole;
  action: string;
  entityType: 'course' | 'reservation' | 'user' | 'test';
  entityId: string;
  details: string;
  timestamp: string;
}

export type TestCategory = 
  | 'Unit Testing' 
  | 'Integration Testing' 
  | 'White-Box Testing' 
  | 'Black-Box Testing' 
  | 'Generative AI-Assisted Testing';

export type TestTechnique = 
  | 'Statement Coverage'
  | 'Branch Coverage'
  | 'Condition Testing'
  | 'Path Testing'
  | 'Equivalence Partitioning'
  | 'Boundary Value Analysis'
  | 'Decision Table Testing'
  | 'Error Guessing'
  | 'Input Validation'
  | 'State Transition'
  | 'Atomic Concurrency'
  | 'Role-Based Access Control'
  | 'Prompt-Engineered Validation';

export type TestStatus = 'Pass' | 'Fail' | 'Blocked' | 'Not Run';

export type AiReviewStatus = 'accepted' | 'rejected' | 'needs_revision' | 'unreviewed';

export interface LabTestCase {
  id: string;
  category: TestCategory;
  technique: TestTechnique;
  objective: string;
  preconditions: string;
  testInputs: string;
  executionSteps: string[];
  expectedResult: string;
  actualResult?: string;
  status: TestStatus;
  defectId?: string;
  notes?: string;
  executionDate?: string;
  isAutomated: boolean;
  aiGenerated?: boolean;
  aiReviewStatus?: AiReviewStatus;
  aiReviewNotes?: string;
}

export interface TestExecutionResult {
  testId: string;
  name: string;
  category: TestCategory;
  technique: TestTechnique;
  passed: boolean;
  durationMs: number;
  assertionMessage: string;
  executedAt: string;
  details?: Record<string, any>;
}

export interface AdminStats {
  totalCourses: number;
  publishedCourses: number;
  totalStudents: number;
  activeReservations: number;
  completedReservations: number;
  cancelledReservations: number;
  totalAvailableSeats: number;
  totalCapacity: number;
  fullCoursesCount: number;
  estimatedRevenue: number;
  categoryBreakdown: { category: string; courses: number; reservations: number }[];
  capacityUtilization: number;
}
