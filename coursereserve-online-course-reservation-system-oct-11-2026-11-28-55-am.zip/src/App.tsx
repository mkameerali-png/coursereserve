import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { ToastProvider } from './components/Toast';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';

// Views
import { LandingPage } from './views/LandingPage';
import { CoursesCatalogue } from './views/CoursesCatalogue';
import { CourseDetailsPage } from './views/CourseDetailsPage';
import { ReservationConfirmationPage } from './views/ReservationConfirmationPage';
import { StudentDashboard } from './views/StudentDashboard';
import { MyReservationsPage } from './views/MyReservationsPage';
import { StudentProfilePage } from './views/StudentProfilePage';
import { LoginPage } from './views/LoginPage';
import { RegisterPage } from './views/RegisterPage';
import { AdminDashboard } from './views/AdminDashboard';
import { AdminCourseManagement } from './views/AdminCourseManagement';
import { AdminReservationManagement } from './views/AdminReservationManagement';
import { AdminReports } from './views/AdminReports';
import { SoftwareTestingDashboard } from './views/SoftwareTestingDashboard';
import { UnauthorizedPage } from './views/UnauthorizedPage';
import { NotFoundPage } from './views/NotFoundPage';

function AppContent() {
  const { user, isAdmin, isStudent, isAuthenticated, loading } = useAuth();
  const [currentView, setCurrentView] = useState<string>('landing');
  const [viewParams, setViewParams] = useState<any>({});

  const handleNavigate = (view: string, params: any = {}) => {
    setViewParams(params);
    setCurrentView(view);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center">
        <div className="w-10 h-10 border-4 border-cyan-500/20 border-t-cyan-400 rounded-full animate-spin" />
      </div>
    );
  }

  // Render current view
  const renderView = () => {
    switch (currentView) {
      case 'landing':
        return <LandingPage onNavigate={handleNavigate} />;

      case 'catalogue':
        return <CoursesCatalogue onNavigate={handleNavigate} />;

      case 'course-details':
        return (
          <CourseDetailsPage
            courseId={viewParams.courseId || 'crs_101'}
            onNavigate={handleNavigate}
          />
        );

      case 'reservation-confirmation':
        if (!viewParams.reservation) {
          return <CoursesCatalogue onNavigate={handleNavigate} />;
        }
        return (
          <ReservationConfirmationPage
            reservation={viewParams.reservation}
            onNavigate={handleNavigate}
          />
        );

      case 'student-dashboard':
        if (!isAuthenticated) {
          return <LoginPage onNavigate={handleNavigate} />;
        }
        return <StudentDashboard onNavigate={handleNavigate} />;

      case 'my-reservations':
        if (!isAuthenticated) {
          return <LoginPage onNavigate={handleNavigate} />;
        }
        return <MyReservationsPage onNavigate={handleNavigate} />;

      case 'student-profile':
        if (!isAuthenticated) {
          return <LoginPage onNavigate={handleNavigate} />;
        }
        return <StudentProfilePage />;

      case 'login':
        return <LoginPage onNavigate={handleNavigate} />;

      case 'register':
        return <RegisterPage onNavigate={handleNavigate} />;

      case 'admin-dashboard':
        if (!isAdmin) {
          return <UnauthorizedPage onNavigate={handleNavigate} />;
        }
        return <AdminDashboard onNavigate={handleNavigate} />;

      case 'admin-courses':
        if (!isAdmin) {
          return <UnauthorizedPage onNavigate={handleNavigate} />;
        }
        return <AdminCourseManagement onNavigate={handleNavigate} />;

      case 'admin-reservations':
        if (!isAdmin) {
          return <UnauthorizedPage onNavigate={handleNavigate} />;
        }
        return <AdminReservationManagement onNavigate={handleNavigate} />;

      case 'admin-reports':
        if (!isAdmin) {
          return <UnauthorizedPage onNavigate={handleNavigate} />;
        }
        return <AdminReports onNavigate={handleNavigate} />;

      case 'testing-dashboard':
        return <SoftwareTestingDashboard />;

      case 'unauthorized':
        return <UnauthorizedPage onNavigate={handleNavigate} />;

      default:
        return <NotFoundPage onNavigate={handleNavigate} />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-cyan-500 selection:text-slate-950">
      <Navbar currentView={currentView} onNavigate={handleNavigate} />
      <main className="flex-1">{renderView()}</main>
      <Footer onNavigate={handleNavigate} />
    </div>
  );
}

export default function App() {
  return (
    <ToastProvider>
      <AuthProvider>
        <AppContent />
      </AuthProvider>
    </ToastProvider>
  );
}
