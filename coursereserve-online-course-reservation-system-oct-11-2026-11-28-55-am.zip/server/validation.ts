import { Course, Reservation, User } from '../src/types/index';

// Email validation
export function validateEmailFormat(email: string): { valid: boolean; error?: string } {
  if (!email || typeof email !== 'string') {
    return { valid: false, error: 'Email address is required.' };
  }
  const trimmed = email.trim();
  // RFC 5322 standard compliant pattern
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+$/;
  if (!emailRegex.test(trimmed)) {
    return { valid: false, error: 'Please provide a valid college or email address format (e.g., student@college.edu).' };
  }
  return { valid: true };
}

// Password strength calculation
export interface PasswordStrengthResult {
  score: number; // 0 to 4
  valid: boolean;
  errors: string[];
  label: 'Very Weak' | 'Weak' | 'Medium' | 'Strong' | 'Very Strong';
}

export function validatePasswordStrength(password: string): PasswordStrengthResult {
  const errors: string[] = [];
  if (!password || typeof password !== 'string') {
    return {
      score: 0,
      valid: false,
      errors: ['Password is required.'],
      label: 'Very Weak',
    };
  }

  let score = 0;
  if (password.length >= 8) score++;
  else errors.push('Password must be at least 8 characters long.');

  if (/[a-z]/.test(password)) score++;
  else errors.push('Password must include at least one lowercase letter.');

  if (/[A-Z]/.test(password)) score++;
  else errors.push('Password must include at least one uppercase letter.');

  if (/[0-9]/.test(password)) score++;
  else errors.push('Password must include at least one number.');

  if (/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(password)) score++;
  else errors.push('Password must include at least one special character (e.g. !@#$%).');

  const labels: ('Very Weak' | 'Weak' | 'Medium' | 'Strong' | 'Very Strong')[] = [
    'Very Weak',
    'Weak',
    'Medium',
    'Strong',
    'Very Strong',
  ];

  return {
    score,
    valid: errors.length === 0 && password.length >= 8,
    errors,
    label: labels[Math.min(score, 4)],
  };
}

// Validate registration inputs
export function validateRegistrationPayload(data: any): { valid: boolean; errors: string[] } {
  const errors: string[] = [];

  if (!data.fullName || typeof data.fullName !== 'string' || data.fullName.trim().length < 2) {
    errors.push('Full name must be at least 2 characters long.');
  }

  const emailVal = validateEmailFormat(data.email);
  if (!emailVal.valid) {
    errors.push(emailVal.error!);
  }

  const pwdVal = validatePasswordStrength(data.password);
  if (!pwdVal.valid) {
    errors.push(...pwdVal.errors);
  }

  if (data.password !== data.confirmPassword) {
    errors.push('Password and confirmation password do not match.');
  }

  return {
    valid: errors.length === 0,
    errors,
  };
}

// Validate course data
export function validateCoursePayload(data: any): { valid: boolean; errors: string[] } {
  const errors: string[] = [];

  if (!data.title || typeof data.title !== 'string' || data.title.trim().length < 3) {
    errors.push('Course title is required and must be at least 3 characters.');
  }

  if (!data.code || typeof data.code !== 'string' || data.code.trim().length < 2) {
    errors.push('Course code (e.g. CS-101) is required.');
  }

  if (!data.category || typeof data.category !== 'string' || data.category.trim().length < 2) {
    errors.push('Course category is required.');
  }

  if (!data.instructor || typeof data.instructor !== 'string' || data.instructor.trim().length < 2) {
    errors.push('Instructor name is required.');
  }

  if (typeof data.fee !== 'number' || data.fee < 0) {
    errors.push('Course fee must be a non-negative number.');
  }

  if (typeof data.capacity !== 'number' || data.capacity <= 0 || !Number.isInteger(data.capacity)) {
    errors.push('Total course capacity must be a positive integer greater than zero.');
  }

  if (!data.startDate || typeof data.startDate !== 'string') {
    errors.push('Course start date is required.');
  }

  return {
    valid: errors.length === 0,
    errors,
  };
}

// White-Box Testing Reference Function:
// Evaluates reservation eligibility with clear decision points for Statement, Branch, Condition, and Path coverage!
export interface EligibilityResult {
  eligible: boolean;
  statusCode: number;
  reasonCode: 'SUCCESS' | 'UNAUTHENTICATED' | 'COURSE_UNAVAILABLE' | 'COURSE_FULL' | 'DUPLICATE_RESERVATION' | 'EXPIRED_DEADLINE';
  message: string;
  statementTrace: number[];
}

export function evaluateReservationEligibility(
  user: User | null | undefined,
  course: Course | null | undefined,
  existingReservations: Reservation[] = [],
  currentDateStr?: string
): EligibilityResult {
  const trace: number[] = [];

  // Statement 1: Authenticity check
  trace.push(1);
  if (!user || !user.id) {
    trace.push(2);
    return {
      eligible: false,
      statusCode: 401,
      reasonCode: 'UNAUTHENTICATED',
      message: 'Student must be authenticated to reserve courses.',
      statementTrace: trace,
    };
  }

  // Statement 3: Course existence and publish status
  trace.push(3);
  if (!course || course.status !== 'published') {
    trace.push(4);
    return {
      eligible: false,
      statusCode: 400,
      reasonCode: 'COURSE_UNAVAILABLE',
      message: 'Course is not currently available or published for reservation.',
      statementTrace: trace,
    };
  }

  // Statement 5: Seat availability boundary
  trace.push(5);
  if (course.availableSeats <= 0) {
    trace.push(6);
    return {
      eligible: false,
      statusCode: 409,
      reasonCode: 'COURSE_FULL',
      message: 'Course is at full capacity with 0 available seats.',
      statementTrace: trace,
    };
  }

  // Statement 7: Duplicate active reservation check
  trace.push(7);
  const hasActiveDuplicate = existingReservations.some(
    (r) => r.studentId === user.id && r.courseId === course.id && r.reservationStatus === 'active'
  );
  if (hasActiveDuplicate) {
    trace.push(8);
    return {
      eligible: false,
      statusCode: 409,
      reasonCode: 'DUPLICATE_RESERVATION',
      message: 'Student already holds an active reservation for this course.',
      statementTrace: trace,
    };
  }

  // Statement 9: Start date registration deadline validation
  trace.push(9);
  const now = currentDateStr ? new Date(currentDateStr) : new Date();
  const start = new Date(course.startDate);
  if (start.getTime() < now.getTime() - 86400000) {
    trace.push(10);
    return {
      eligible: false,
      statusCode: 400,
      reasonCode: 'EXPIRED_DEADLINE',
      message: 'Course registration period has elapsed past the course start date.',
      statementTrace: trace,
    };
  }

  // Statement 11: Reservation eligible
  trace.push(11);
  return {
    eligible: true,
    statusCode: 200,
    reasonCode: 'SUCCESS',
    message: 'Course reservation eligibility criteria fully satisfied.',
    statementTrace: trace,
  };
}
