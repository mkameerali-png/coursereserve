import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { User, Course, Reservation, AuditLog, LabTestCase, AdminStats } from '../src/types/index';

const DATA_DIR = path.resolve(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'db.json');

// Simple Mutex for serializing atomic database updates and concurrency guarantees
class Mutex {
  private queue: (() => void)[] = [];
  private locked = false;

  async acquire(): Promise<() => void> {
    return new Promise((resolve) => {
      const execute = () => {
        this.locked = true;
        resolve(() => {
          this.locked = false;
          const next = this.queue.shift();
          if (next) next();
        });
      };

      if (this.locked) {
        this.queue.push(execute);
      } else {
        execute();
      }
    });
  }
}

export const dbMutex = new Mutex();

// Secure password hashing with PBKDF2/scrypt
export function hashPassword(password: string, salt?: string): { hash: string; salt: string } {
  const actualSalt = salt || crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(password, actualSalt, 64).toString('hex');
  return { hash, salt: actualSalt };
}

export function verifyPassword(password: string, storedHash: string, salt: string): boolean {
  try {
    const computed = crypto.scryptSync(password, salt, 64).toString('hex');
    return crypto.timingSafeEqual(Buffer.from(computed), Buffer.from(storedHash));
  } catch {
    return false;
  }
}

interface StoredUser extends User {
  passwordHash: string;
  salt: string;
}

interface DatabaseSchema {
  users: StoredUser[];
  courses: Course[];
  reservations: Reservation[];
  auditLogs: AuditLog[];
  testCases: LabTestCase[];
}

// Initial Seed Data
function getInitialSeed(): DatabaseSchema {
  const adminPass = hashPassword('AdminPassword123!', 'fixed_admin_salt_893');
  const student1Pass = hashPassword('StudentPassword123!', 'fixed_student1_salt_12');
  const student2Pass = hashPassword('StudentPassword123!', 'fixed_student2_salt_34');

  const users: StoredUser[] = [
    {
      id: 'usr_admin_01',
      fullName: 'Prof. Katherine Vance',
      email: 'admin@college.edu',
      role: 'admin',
      department: 'Computer Science & Software Engineering',
      phone: '+1 (555) 432-8800',
      createdAt: '2026-08-15T09:00:00Z',
      passwordHash: adminPass.hash,
      salt: adminPass.salt,
    },
    {
      id: 'usr_std_01',
      fullName: 'Alex Rivera',
      email: 'student@college.edu',
      role: 'student',
      studentIdCode: 'CS-2024-8842',
      department: 'Computer Science',
      phone: '+1 (555) 234-5678',
      createdAt: '2026-09-01T10:15:00Z',
      passwordHash: student1Pass.hash,
      salt: student1Pass.salt,
    },
    {
      id: 'usr_std_02',
      fullName: 'Sarah Chen',
      email: 'sarah.chen@college.edu',
      role: 'student',
      studentIdCode: 'SE-2025-1049',
      department: 'Software Engineering',
      phone: '+1 (555) 876-5432',
      createdAt: '2026-09-05T14:30:00Z',
      passwordHash: student2Pass.hash,
      salt: student2Pass.salt,
    },
  ];

  const courses: Course[] = [
    {
      id: 'crs_101',
      code: 'CS-101',
      title: 'Java Programming',
      description: 'Comprehensive introduction to object-oriented programming in Java, covering encapsulation, inheritance, polymorphism, abstract data structures, and multithreading.',
      category: 'Programming & Software',
      instructor: 'Dr. Robert Miller',
      instructorTitle: 'Associate Professor of Computer Science',
      duration: '8 Weeks',
      fee: 250,
      startDate: '2026-11-02',
      schedule: 'Mon & Wed 10:00 AM - 11:30 AM',
      capacity: 30,
      availableSeats: 12,
      status: 'published',
      credits: 4,
      prerequisites: ['Introduction to Computing'],
      location: 'Engineering Building Lab 302',
      createdAt: '2026-09-10T08:00:00Z',
      updatedAt: '2026-09-10T08:00:00Z',
    },
    {
      id: 'crs_102',
      code: 'CS-102',
      title: 'Python for Beginners',
      description: 'Hands-on Python essentials: syntax, control flow, functions, file I/O, error handling, and introduction to data science libraries (NumPy, Pandas).',
      category: 'Programming & Software',
      instructor: 'Prof. Anita Sharma',
      instructorTitle: 'Senior Lecturer, Computational Systems',
      duration: '6 Weeks',
      fee: 200,
      startDate: '2026-11-05',
      schedule: 'Tue & Thu 02:00 PM - 03:30 PM',
      capacity: 25,
      availableSeats: 1, // Only 1 seat left! Perfect for boundary tests and concurrency race condition demos!
      status: 'published',
      credits: 3,
      prerequisites: ['None'],
      location: 'Virtual Classroom A & Lab 104',
      createdAt: '2026-09-11T09:00:00Z',
      updatedAt: '2026-09-11T09:00:00Z',
    },
    {
      id: 'crs_201',
      code: 'CS-201',
      title: 'Web Development Full-Stack',
      description: 'End-to-end modern web applications: HTML5, CSS3, modern JavaScript, React 19, Node.js, Express, RESTful APIs, and secure deployment architectures.',
      category: 'Web Technologies',
      instructor: 'Michael Scott',
      instructorTitle: 'Industry Fellow & Full-Stack Architect',
      duration: '10 Weeks',
      fee: 320,
      startDate: '2026-11-10',
      schedule: 'Mon & Wed 04:00 PM - 05:30 PM',
      capacity: 20,
      availableSeats: 7,
      status: 'published',
      credits: 4,
      prerequisites: ['CS-101 or CS-102'],
      location: 'Software Engineering Studio 4',
      createdAt: '2026-09-12T11:00:00Z',
      updatedAt: '2026-09-12T11:00:00Z',
    },
    {
      id: 'crs_301',
      code: 'CS-301',
      title: 'Data Structures and Algorithms',
      description: 'Rigorous analysis of asymptotic complexity, linked lists, balanced trees, heaps, graphs, greedy algorithms, divide-and-conquer, and dynamic programming.',
      category: 'Core Computer Science',
      instructor: 'Dr. Elena Rostova',
      instructorTitle: 'Professor of Algorithms & Complexity',
      duration: '12 Weeks',
      fee: 350,
      startDate: '2026-11-16',
      schedule: 'Mon, Wed, Fri 09:00 AM - 10:00 AM',
      capacity: 40,
      availableSeats: 0, // Fully booked! Perfect for testing 0 seat rejection!
      status: 'published',
      credits: 4,
      prerequisites: ['CS-101', 'Discrete Mathematics'],
      location: 'Lecture Hall C1',
      createdAt: '2026-09-13T10:00:00Z',
      updatedAt: '2026-09-13T10:00:00Z',
    },
    {
      id: 'crs_401',
      code: 'CS-401',
      title: 'Machine Learning Fundamentals',
      description: 'Supervised and unsupervised learning, linear regression, decision trees, support vector machines, neural networks, and model evaluation metrics.',
      category: 'Artificial Intelligence',
      instructor: 'Dr. Marcus Vance',
      instructorTitle: 'AI Research Director',
      duration: '10 Weeks',
      fee: 450,
      startDate: '2026-11-24',
      schedule: 'Tue & Thu 11:00 AM - 12:30 PM',
      capacity: 25,
      availableSeats: 15,
      status: 'published',
      credits: 4,
      prerequisites: ['CS-102', 'Linear Algebra', 'Probability'],
      location: 'AI Center Lab 201',
      createdAt: '2026-09-14T13:00:00Z',
      updatedAt: '2026-09-14T13:00:00Z',
    },
    {
      id: 'crs_205',
      code: 'CS-205',
      title: 'Database Management Systems',
      description: 'Relational data model, relational algebra, SQL querying, normalization (1NF to BCNF), indexing, transactions, ACID properties, and crash recovery.',
      category: 'Systems & Architecture',
      instructor: 'Prof. David Lin',
      instructorTitle: 'Associate Professor of Information Systems',
      duration: '8 Weeks',
      fee: 280,
      startDate: '2026-12-01',
      schedule: 'Fri 01:00 PM - 04:00 PM',
      capacity: 35,
      availableSeats: 22,
      status: 'published',
      credits: 3,
      prerequisites: ['CS-101 or CS-102'],
      location: 'Computing Center 105',
      createdAt: '2026-09-15T15:00:00Z',
      updatedAt: '2026-09-15T15:00:00Z',
    },
    {
      id: 'crs_405',
      code: 'CS-405',
      title: 'Artificial Intelligence & Heuristics',
      description: 'Search algorithms (A*, minimax, alpha-beta pruning), constraint satisfaction, knowledge representation, Bayesian reasoning, and ethics in AI.',
      category: 'Artificial Intelligence',
      instructor: 'Dr. Sophia Loren',
      instructorTitle: 'Chair, Department of Cognitive Systems',
      duration: '12 Weeks',
      fee: 480,
      startDate: '2026-12-05',
      schedule: 'Sat 10:00 AM - 01:00 PM',
      capacity: 25,
      availableSeats: 18,
      status: 'published',
      credits: 4,
      prerequisites: ['CS-301', 'CS-401'],
      location: 'Virtual Auditorium & AI Lab',
      createdAt: '2026-09-16T12:00:00Z',
      updatedAt: '2026-09-16T12:00:00Z',
    },
    {
      id: 'crs_305',
      code: 'CS-305',
      title: 'Software Engineering & Testing',
      description: 'Software development lifecycle, requirements engineering, UML modeling, architectural patterns, verification, validation, unit, integration, and black-box/white-box testing.',
      category: 'Software Engineering',
      instructor: 'Prof. Katherine Vance',
      instructorTitle: 'Software Engineering Lab Director',
      duration: '8 Weeks',
      fee: 300,
      startDate: '2026-12-10',
      schedule: 'Tue & Thu 04:00 PM - 05:30 PM',
      capacity: 30,
      availableSeats: 26,
      status: 'published',
      credits: 4,
      prerequisites: ['CS-201 or CS-101'],
      location: 'Software Engineering Lab 101',
      createdAt: '2026-09-17T09:00:00Z',
      updatedAt: '2026-09-17T09:00:00Z',
    },
    {
      id: 'crs_501',
      code: 'CS-501',
      title: 'Cloud Computing & DevOps (Spring Preview)',
      description: 'Containerization with Docker, Kubernetes orchestration, CI/CD pipelines, Infrastructure as Code, microservices, and serverless compute.',
      category: 'Systems & Architecture',
      instructor: 'Kevin Patel',
      instructorTitle: 'DevOps Architect & Adjunct Faculty',
      duration: '6 Weeks',
      fee: 380,
      startDate: '2027-01-18',
      schedule: 'Mon & Wed 06:00 PM - 07:30 PM',
      capacity: 20,
      availableSeats: 20,
      status: 'unpublished', // Unpublished demo course
      credits: 3,
      prerequisites: ['CS-205', 'CS-201'],
      location: 'Cloud Sandbox Lab',
      createdAt: '2026-09-18T14:00:00Z',
      updatedAt: '2026-09-18T14:00:00Z',
    },
  ];

  const reservations: Reservation[] = [
    {
      id: 'res_08491',
      confirmationCode: 'RES-2026-08491',
      studentId: 'usr_std_01',
      studentName: 'Alex Rivera',
      studentEmail: 'student@college.edu',
      courseId: 'crs_101',
      courseCode: 'CS-101',
      courseTitle: 'Java Programming',
      courseCategory: 'Programming & Software',
      courseSchedule: 'Mon & Wed 10:00 AM - 11:30 AM',
      courseStartDate: '2026-11-02',
      courseFee: 250,
      reservationStatus: 'active',
      reservedAt: '2026-09-20T14:22:10Z',
    },
    {
      id: 'res_08492',
      confirmationCode: 'RES-2026-08492',
      studentId: 'usr_std_01',
      studentName: 'Alex Rivera',
      studentEmail: 'student@college.edu',
      courseId: 'crs_201',
      courseCode: 'CS-201',
      courseTitle: 'Web Development Full-Stack',
      courseCategory: 'Web Technologies',
      courseSchedule: 'Mon & Wed 04:00 PM - 05:30 PM',
      courseStartDate: '2026-11-10',
      courseFee: 320,
      reservationStatus: 'active',
      reservedAt: '2026-09-22T09:15:44Z',
    },
    {
      id: 'res_08493',
      confirmationCode: 'RES-2026-08493',
      studentId: 'usr_std_01',
      studentName: 'Alex Rivera',
      studentEmail: 'student@college.edu',
      courseId: 'crs_205',
      courseCode: 'CS-205',
      courseTitle: 'Database Management Systems',
      courseCategory: 'Systems & Architecture',
      courseSchedule: 'Fri 01:00 PM - 04:00 PM',
      courseStartDate: '2026-12-01',
      courseFee: 280,
      reservationStatus: 'cancelled',
      reservedAt: '2026-09-15T11:00:00Z',
      cancelledAt: '2026-09-18T16:45:00Z',
      cancellationReason: 'Schedule conflict with college varsity athletic meet.',
    },
    {
      id: 'res_08494',
      confirmationCode: 'RES-2026-08494',
      studentId: 'usr_std_02',
      studentName: 'Sarah Chen',
      studentEmail: 'sarah.chen@college.edu',
      courseId: 'crs_101',
      courseCode: 'CS-101',
      courseTitle: 'Java Programming',
      courseCategory: 'Programming & Software',
      courseSchedule: 'Mon & Wed 10:00 AM - 11:30 AM',
      courseStartDate: '2026-11-02',
      courseFee: 250,
      reservationStatus: 'active',
      reservedAt: '2026-09-25T13:40:12Z',
    },
    {
      id: 'res_08495',
      confirmationCode: 'RES-2026-08495',
      studentId: 'usr_std_02',
      studentName: 'Sarah Chen',
      studentEmail: 'sarah.chen@college.edu',
      courseId: 'crs_305',
      courseCode: 'CS-305',
      courseTitle: 'Software Engineering & Testing',
      courseCategory: 'Software Engineering',
      courseSchedule: 'Tue & Thu 04:00 PM - 05:30 PM',
      courseStartDate: '2026-12-10',
      courseFee: 300,
      reservationStatus: 'active',
      reservedAt: '2026-09-28T10:05:30Z',
    },
  ];

  const auditLogs: AuditLog[] = [
    {
      id: 'log_001',
      userId: 'usr_admin_01',
      userEmail: 'admin@college.edu',
      userRole: 'admin',
      action: 'SYSTEM_INITIALIZATION',
      entityType: 'course',
      entityId: 'SYSTEM',
      details: 'CourseReserve system database initialized with seed catalogue and laboratory test suites.',
      timestamp: '2026-09-10T08:00:00Z',
    },
    {
      id: 'log_002',
      userId: 'usr_std_01',
      userEmail: 'student@college.edu',
      userRole: 'student',
      action: 'RESERVATION_CREATED',
      entityType: 'reservation',
      entityId: 'res_08491',
      details: 'Student Alex Rivera successfully reserved 1 seat in CS-101 Java Programming.',
      timestamp: '2026-09-20T14:22:10Z',
    },
    {
      id: 'log_003',
      userId: 'usr_std_01',
      userEmail: 'student@college.edu',
      userRole: 'student',
      action: 'RESERVATION_CANCELLED',
      entityType: 'reservation',
      entityId: 'res_08493',
      details: 'Student Alex Rivera cancelled reservation in CS-205. Seat restored to capacity.',
      timestamp: '2026-09-18T16:45:00Z',
    },
  ];

  const testCases: LabTestCase[] = [
    // UNIT TESTING
    {
      id: 'UT-001',
      category: 'Unit Testing',
      technique: 'Input Validation',
      objective: 'Verify student email format validation accepts valid RFC 5322 college addresses and rejects invalid strings.',
      preconditions: 'Validator module initialized.',
      testInputs: 'Valid: "john.doe@college.edu", "s123@ac.in"; Invalid: "plainaddress", "missing@domain", "@college.edu"',
      executionSteps: [
        'Invoke validateEmailFormat() with valid and invalid string variants.',
        'Assert boolean return values match expected validity.',
      ],
      expectedResult: 'Returns true for valid email patterns; returns false with specific error message for invalid strings.',
      actualResult: 'All RFC 5322 regex assertions succeeded in 0.8ms.',
      status: 'Pass',
      executionDate: '2026-10-10',
      isAutomated: true,
      notes: 'Passed automated validator unit test suite.',
    },
    {
      id: 'UT-002',
      category: 'Unit Testing',
      technique: 'Input Validation',
      objective: 'Verify password complexity policy enforcement (min 8 chars, uppercase, lowercase, number, special char).',
      preconditions: 'Authentication service loaded.',
      testInputs: 'Weak: "pass", "password123", "NOLOW123!"; Strong: "ValidPass123!"',
      executionSteps: [
        'Call validatePasswordStrength() with test password permutations.',
        'Assert score and boolean pass status.',
      ],
      expectedResult: 'Passwords lacking required character classes return false with descriptive reason.',
      actualResult: 'Rejected weak passwords and verified score >= 4 on compliant input.',
      status: 'Pass',
      executionDate: '2026-10-10',
      isAutomated: true,
    },
    {
      id: 'UT-003',
      category: 'Unit Testing',
      technique: 'State Transition',
      objective: 'Verify course seat availability validator correctly checks remaining capacity against active count.',
      preconditions: 'Course entity instantiated with capacity=30 and availableSeats=0.',
      testInputs: 'Course CS-301 (availableSeats=0).',
      executionSteps: [
        'Call isCourseReservable(course).',
        'Assert return status.',
      ],
      expectedResult: 'Returns false with code COURSE_FULL when availableSeats <= 0.',
      actualResult: 'Returned false and blocked reservation attempt immediately.',
      status: 'Pass',
      executionDate: '2026-10-10',
      isAutomated: true,
    },
    {
      id: 'UT-004',
      category: 'Unit Testing',
      technique: 'Role-Based Access Control',
      objective: 'Verify role-based permission guard restricts administrative endpoints from student user tokens.',
      preconditions: 'User Alex Rivera (role="student") authenticated with valid JWT token.',
      testInputs: 'Request to POST /api/courses with student bearer token.',
      executionSteps: [
        'Execute authorizeAdmin() middleware with student session.',
        'Assert HTTP status code and response payload.',
      ],
      expectedResult: 'Responds with HTTP 403 Forbidden and error message "Administrative authorization required".',
      actualResult: 'Middleware halted processing and responded with 403 Forbidden.',
      status: 'Pass',
      executionDate: '2026-10-10',
      isAutomated: true,
    },
    {
      id: 'UT-005',
      category: 'Unit Testing',
      technique: 'Input Validation',
      objective: 'Verify course creation rejects negative fees, zero capacity, and empty titles.',
      preconditions: 'Admin authentication context.',
      testInputs: '{ title: "", capacity: -5, fee: -100 }',
      executionSteps: [
        'Validate payload using validateCoursePayload().',
        'Assert validation errors returned.',
      ],
      expectedResult: 'Throws 400 Bad Request with field-specific errors.',
      actualResult: 'Validation caught all 3 invalid attributes.',
      status: 'Pass',
      executionDate: '2026-10-10',
      isAutomated: true,
    },

    // INTEGRATION TESTING
    {
      id: 'IT-001',
      category: 'Integration Testing',
      technique: 'Atomic Concurrency',
      objective: 'Verify end-to-end course reservation decreases available seats by 1 and creates unique reservation record.',
      preconditions: 'Student authenticated; course CS-101 has 12 available seats.',
      testInputs: 'POST /api/reservations with studentId="usr_std_01", courseId="crs_102".',
      executionSteps: [
        'Dispatch reservation request to backend API.',
        'Inspect database course record availableSeats decrement.',
        'Inspect new reservation record confirmationCode format.',
      ],
      expectedResult: 'Available seats decremented by 1 atomically; reservation created with status "active" and unique confirmation ID.',
      actualResult: 'Available seats updated from 1 to 0; reservation confirmation generated successfully.',
      status: 'Pass',
      executionDate: '2026-10-10',
      isAutomated: true,
    },
    {
      id: 'IT-002',
      category: 'Integration Testing',
      technique: 'State Transition',
      objective: 'Verify reservation cancellation restores course capacity by exactly 1 and sets status to "cancelled".',
      preconditions: 'Active reservation exists for student.',
      testInputs: 'POST /api/reservations/:id/cancel with valid reason.',
      executionSteps: [
        'Record current course availableSeats count.',
        'Submit cancellation API call.',
        'Verify course availableSeats incremented by 1.',
        'Verify reservation cancelledAt timestamp is recorded.',
      ],
      expectedResult: 'Seat restored exactly once; status changed to cancelled; student receives confirmation.',
      actualResult: 'Course capacity restored from 12 to 13; cancelledAt timestamp logged.',
      status: 'Pass',
      executionDate: '2026-10-10',
      isAutomated: true,
    },
    {
      id: 'IT-003',
      category: 'Integration Testing',
      technique: 'Input Validation',
      objective: 'Verify duplicate reservation prevention: student cannot reserve the same course twice while active.',
      preconditions: 'Student Alex Rivera has active reservation in CS-101.',
      testInputs: 'POST /api/reservations with studentId="usr_std_01", courseId="crs_101".',
      executionSteps: [
        'Attempt second reservation for same course.',
        'Assert HTTP status and message.',
      ],
      expectedResult: 'HTTP 409 Conflict with message "Student already has an active reservation for this course".',
      actualResult: 'Correctly returned 409 Conflict without modifying database or seat counts.',
      status: 'Pass',
      executionDate: '2026-10-10',
      isAutomated: true,
    },
    {
      id: 'IT-004',
      category: 'Integration Testing',
      technique: 'Atomic Concurrency',
      objective: 'Verify race condition safety: simultaneous reservation attempts on 1 remaining seat yield exactly 1 success and N-1 capacity errors.',
      preconditions: 'Course CS-102 has availableSeats = 1. Five parallel client requests dispatched simultaneously.',
      testInputs: '5 concurrent POST /api/reservations requests.',
      executionSteps: [
        'Trigger Promise.all() with 5 simultaneous reservation requests.',
        'Count successful HTTP 201 responses vs HTTP 409/400 responses.',
        'Verify course availableSeats is exactly 0 (never negative).',
      ],
      expectedResult: 'Exactly 1 request succeeds (201); 4 requests rejected (409); availableSeats equals 0.',
      actualResult: 'Database mutex serialized transactions: 1 booked, 4 rejected with Course Full. Zero overbooking.',
      status: 'Pass',
      executionDate: '2026-10-10',
      isAutomated: true,
    },
    {
      id: 'IT-005',
      category: 'Integration Testing',
      technique: 'Role-Based Access Control',
      objective: 'Verify unauthorized reservation ownership access: Student B cannot view or cancel Student A\'s reservation.',
      preconditions: 'Reservation res_08491 belongs to Student A (Alex). Student B (Sarah) makes request.',
      testInputs: 'POST /api/reservations/res_08491/cancel with Sarah\'s bearer token.',
      executionSteps: [
        'Send cancellation request with non-owner student token.',
        'Verify response code.',
      ],
      expectedResult: 'HTTP 403 Forbidden with message "You are not authorized to manage this reservation".',
      actualResult: 'Forbidden response returned; reservation remains active.',
      status: 'Pass',
      executionDate: '2026-10-10',
      isAutomated: true,
    },

    // WHITE-BOX TESTING
    {
      id: 'WBT-001',
      category: 'White-Box Testing',
      technique: 'Statement Coverage',
      objective: 'Achieve 100% statement coverage on evaluateReservationEligibility() decision logic.',
      preconditions: 'All logic statements reachable through curated test fixtures.',
      testInputs: 'Suite of 6 distinct student-course-reservation tuples.',
      executionSteps: [
        'Execute test vector hitting every executable code line.',
        'Track statement execution markers.',
      ],
      expectedResult: '100% of statements in eligibility evaluator executed at least once.',
      actualResult: 'All 28 statements in evaluation function executed and verified.',
      status: 'Pass',
      executionDate: '2026-10-10',
      isAutomated: true,
      notes: 'Statement coverage: 100% (28/28 lines executed).',
    },
    {
      id: 'WBT-002',
      category: 'White-Box Testing',
      technique: 'Branch Coverage',
      objective: 'Exercise TRUE and FALSE outcomes for every conditional branch in reservation validation algorithm.',
      preconditions: 'Branching tree: isAuthenticated, isCoursePublished, hasAvailableSeats, noActiveDuplicate, isWithinDeadline.',
      testInputs: 'Permutations representing (T,T,T,T,T), (F,-,-,-,-), (T,F,-,-,-), (T,T,F,-,-), (T,T,T,F,-), (T,T,T,T,F).',
      executionSteps: [
        'Feed all 6 input combinations into validator.',
        'Inspect decision outcomes for both True and False branches.',
      ],
      expectedResult: 'All 10 decision branch edges traversed.',
      actualResult: '10/10 branches exercised successfully. 100% branch coverage.',
      status: 'Pass',
      executionDate: '2026-10-10',
      isAutomated: true,
      notes: 'Branch coverage: 100% (10/10 branch edges).',
    },
    {
      id: 'WBT-003',
      category: 'White-Box Testing',
      technique: 'Condition Testing',
      objective: 'Test each boolean sub-condition in compound predicates: (course.status == "published" && course.availableSeats > 0 && !hasDuplicate).',
      preconditions: 'Compound expression evaluator exposed.',
      testInputs: 'Truth table inputs: T-T-T, F-T-T, T-F-T, T-T-F.',
      executionSteps: [
        'Execute evaluation with modified individual sub-conditions.',
        'Verify short-circuiting and boolean evaluations.',
      ],
      expectedResult: 'Each individual sub-condition evaluates to both True and False independently.',
      actualResult: 'Independent condition evaluation verified across 8 condition states.',
      status: 'Pass',
      executionDate: '2026-10-10',
      isAutomated: true,
    },
    {
      id: 'WBT-004',
      category: 'White-Box Testing',
      technique: 'Path Testing',
      objective: 'Basis Path Testing using Cyclomatic Complexity: identify and test all linearly independent paths through reservation workflow.',
      preconditions: 'Control Flow Graph (CFG) constructed: V(G) = E - N + 2P = 14 - 10 + 2 = 6 independent paths.',
      testInputs: 'Path 1: Success; Path 2: Unauthenticated; Path 3: Unpublished; Path 4: Zero Seats; Path 5: Duplicate; Path 6: Expired Deadline.',
      executionSteps: [
        'Execute inputs corresponding to basis paths 1 through 6.',
        'Confirm control flow traverses intended CFG routes.',
      ],
      expectedResult: 'All 6 cyclomatic basis paths executed without unhandled exceptions.',
      actualResult: 'All 6 linearly independent paths executed and validated.',
      status: 'Pass',
      executionDate: '2026-10-10',
      isAutomated: true,
      notes: 'Cyclomatic complexity V(G) = 6. All basis paths covered.',
    },

    // BLACK-BOX TESTING
    {
      id: 'BBT-001',
      category: 'Black-Box Testing',
      technique: 'Equivalence Partitioning',
      objective: 'Partition input domains into valid and invalid equivalence classes for student registration fields.',
      preconditions: 'Registration form endpoint /api/auth/register.',
      testInputs: 'Class 1 (Valid): Standard email, 8+ char password with symbols; Class 2 (Invalid): Malformed email; Class 3 (Invalid): Weak password; Class 4 (Invalid): Empty name.',
      executionSteps: [
        'Submit payloads representative of each equivalence class.',
        'Assert classification outcomes.',
      ],
      expectedResult: 'Valid partition accepts registration (201); invalid partitions return corresponding 400 validation errors.',
      actualResult: 'All 4 equivalence classes produced expected outputs.',
      status: 'Pass',
      executionDate: '2026-10-10',
      isAutomated: true,
    },
    {
      id: 'BBT-002',
      category: 'Black-Box Testing',
      technique: 'Boundary Value Analysis',
      objective: 'Test course capacity boundaries at availableSeats = -1 (illegal), 0 (full), 1 (single seat), capacity (empty), capacity+1 (overfill).',
      preconditions: 'Course capacity = 30.',
      testInputs: 'Boundaries: seats=0 (CS-301), seats=1 (CS-102), seats=30 (new course).',
      executionSteps: [
        'Attempt reservation when seats = 0: verify rejection.',
        'Attempt reservation when seats = 1: verify success and decrement to 0.',
        'Attempt capacity update with capacity < current enrolled: verify admin boundary rejection.',
      ],
      expectedResult: 'Extreme boundary conditions handled gracefully without negative counters or buffer overflow.',
      actualResult: 'Boundary checks prevented negative seats and illegal capacities.',
      status: 'Pass',
      executionDate: '2026-10-10',
      isAutomated: true,
    },
    {
      id: 'BBT-003',
      category: 'Black-Box Testing',
      technique: 'Decision Table Testing',
      objective: 'Evaluate decision table with 8 rules combining: Published (Y/N), Seats Available (Y/N), Prior Reservation (Y/N).',
      preconditions: 'System seeded with course and user fixtures.',
      testInputs: 'Rules R1: Y-Y-N (Allow), R2: Y-Y-Y (Block Duplicate), R3: Y-N-N (Block Full), R4: N-Y-N (Block Unpublished), R5: N-N-Y (Block All).',
      executionSteps: [
        'Iterate through decision table permutations.',
        'Compare actual actions with decision table expected outputs.',
      ],
      expectedResult: 'System actions strictly conform to decision table logic for all 8 rule permutations.',
      actualResult: 'All decision table rules produced exact matching actions.',
      status: 'Pass',
      executionDate: '2026-10-10',
      isAutomated: true,
    },
    {
      id: 'BBT-004',
      category: 'Black-Box Testing',
      technique: 'Error Guessing',
      objective: 'Probe system for common software vulnerabilities: SQL/JSON injection strings, XSS payloads in course title, repeated rapid cancellation requests.',
      preconditions: 'Server endpoints running.',
      testInputs: '\' OR \'1\'=\'1, <script>alert(1)</script>, double cancellation of same reservation ID in parallel.',
      executionSteps: [
        'Send crafted injection payloads in search and name parameters.',
        'Send double cancellation for an already cancelled reservation.',
      ],
      expectedResult: 'Injections sanitized without execution; second cancellation returns 400 "Reservation is already cancelled" without restoring capacity twice.',
      actualResult: 'Capacity restored exactly once. Zero script execution; second cancel safely blocked.',
      status: 'Pass',
      executionDate: '2026-10-10',
      isAutomated: true,
    },

    // GENERATIVE AI-ASSISTED TESTING
    {
      id: 'AIT-001',
      category: 'Generative AI-Assisted Testing',
      technique: 'Prompt-Engineered Validation',
      objective: 'AI Prompt Generation: Test system behavior when student cancels reservation within 2 hours of course start date.',
      preconditions: 'Course starts in 90 minutes. Student has active reservation.',
      testInputs: 'Cancel request sent at T-90 minutes when policy stipulates 24-hour minimum notice.',
      executionSteps: [
        'Evaluate prompt against SRS clause 5.4 "Late Cancellation Policy".',
        'Assert rejection with late cancellation warning or fee forfeit.',
      ],
      expectedResult: 'System applies late cancellation policy rules according to college syllabus settings.',
      actualResult: 'Pending automated harness execution.',
      status: 'Not Run',
      isAutomated: false,
      aiGenerated: true,
      aiReviewStatus: 'accepted',
      aiReviewNotes: 'Accepted by QA Lead: Excellent edge case generated from SRS requirements document.',
    },
    {
      id: 'AIT-002',
      category: 'Generative AI-Assisted Testing',
      technique: 'Prompt-Engineered Validation',
      objective: 'AI Prompt Generation: Verify international character encodings and diacritics in student full name (e.g. "José Peña-Müller").',
      preconditions: 'Registration endpoint.',
      testInputs: 'Student name: "José Peña-Müller", "Zoë Åkesson", "张伟".',
      executionSteps: [
        'Register student with Unicode multilingual plane names.',
        'Verify proper storage and UTF-8 round-trip display in dashboard and confirmation receipt.',
      ],
      expectedResult: 'Characters preserved accurately without byte truncation or encoding corruption.',
      actualResult: 'Validated: UTF-8 encoding maintained across DB, API, and UI.',
      status: 'Pass',
      executionDate: '2026-10-10',
      isAutomated: true,
      aiGenerated: true,
      aiReviewStatus: 'accepted',
      aiReviewNotes: 'Human Verified: Crucial for diverse international collegiate enrollment.',
    },
    {
      id: 'AIT-003',
      category: 'Generative AI-Assisted Testing',
      technique: 'Prompt-Engineered Validation',
      objective: 'AI Prompt Generation: Test edge case where administrator reduces capacity below current active reservation count.',
      preconditions: 'Course has 15 active reservations. Admin edits course capacity to 10.',
      testInputs: 'PUT /api/courses/:id with capacity = 10 while activeReservations = 15.',
      executionSteps: [
        'Submit capacity reduction payload.',
        'Observe administrative validator response.',
      ],
      expectedResult: 'System rejects reduction with error: "Capacity cannot be less than current active reservations (15)".',
      actualResult: 'Admin update rejected with clear conflict explanation.',
      status: 'Pass',
      executionDate: '2026-10-10',
      isAutomated: true,
      aiGenerated: true,
      aiReviewStatus: 'accepted',
      aiReviewNotes: 'Approved: Protects existing reservations from inadvertent administrative truncation.',
    },
    {
      id: 'AIT-004',
      category: 'Generative AI-Assisted Testing',
      technique: 'Prompt-Engineered Validation',
      objective: 'AI Prompt Generation: Simulated network timeout during reservation commit and rollback verification.',
      preconditions: 'Mock network interruption right after seat decrement.',
      testInputs: 'Injected transient failure during transaction commit.',
      executionSteps: [
        'Trigger artificial rollback exception in transaction pipeline.',
        'Verify atomic rollback of seat counter.',
      ],
      expectedResult: 'Reservation aborted, seats restored, no orphan reservation created in database.',
      actualResult: 'Requires fault-injection test bed setup.',
      status: 'Blocked',
      isAutomated: false,
      defectId: 'DEF-104',
      notes: 'Blocked pending automated chaos-monkey network interceptor hook.',
      aiGenerated: true,
      aiReviewStatus: 'needs_revision',
      aiReviewNotes: 'Needs revision: Specify exact timeout threshold in milliseconds and retry strategy.',
    },
  ];

  return { users, courses, reservations, auditLogs, testCases };
}

// Persistent Store Handler
class Database {
  private data: DatabaseSchema;

  constructor() {
    this.data = this.loadData();
  }

  private loadData(): DatabaseSchema {
    try {
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      }
      if (fs.existsSync(DB_FILE)) {
        const raw = fs.readFileSync(DB_FILE, 'utf-8');
        const parsed = JSON.parse(raw);
        if (parsed.users && parsed.courses && parsed.reservations) {
          return parsed;
        }
      }
    } catch (err) {
      console.warn('Could not read existing db.json, initializing fresh seed:', err);
    }

    const seed = getInitialSeed();
    this.persist(seed);
    return seed;
  }

  private persist(schema?: DatabaseSchema): void {
    try {
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      }
      const dataToSave = schema || this.data;
      fs.writeFileSync(DB_FILE, JSON.stringify(dataToSave, null, 2), 'utf-8');
    } catch (err) {
      console.error('Failed to persist database to disk:', err);
    }
  }

  public resetToSeed(): DatabaseSchema {
    this.data = getInitialSeed();
    this.persist();
    return this.data;
  }

  // User queries
  public findUserByEmail(email: string): StoredUser | undefined {
    return this.data.users.find((u) => u.email.toLowerCase() === email.toLowerCase());
  }

  public findUserById(id: string): StoredUser | undefined {
    return this.data.users.find((u) => u.id === id);
  }

  public createUser(user: StoredUser): User {
    this.data.users.push(user);
    this.persist();
    const { passwordHash, salt, ...safeUser } = user;
    return safeUser;
  }

  public updateUser(id: string, updates: Partial<StoredUser>): User | undefined {
    const idx = this.data.users.findIndex((u) => u.id === id);
    if (idx === -1) return undefined;
    this.data.users[idx] = { ...this.data.users[idx], ...updates };
    this.persist();
    const { passwordHash, salt, ...safeUser } = this.data.users[idx];
    return safeUser;
  }

  public getAllStudents(): User[] {
    return this.data.users
      .filter((u) => u.role === 'student')
      .map(({ passwordHash, salt, ...safeUser }) => safeUser);
  }

  // Course queries
  public getCourses(options?: {
    search?: string;
    category?: string;
    status?: string;
    includeUnpublished?: boolean;
    sortBy?: 'title' | 'fee' | 'startDate' | 'availableSeats';
    sortOrder?: 'asc' | 'desc';
  }): Course[] {
    let list = [...this.data.courses];

    if (!options?.includeUnpublished) {
      list = list.filter((c) => c.status === 'published');
    } else if (options?.status && options.status !== 'all') {
      list = list.filter((c) => c.status === options.status);
    }

    if (options?.category && options.category !== 'all') {
      list = list.filter((c) => c.category.toLowerCase() === options.category!.toLowerCase());
    }

    if (options?.search) {
      const q = options.search.toLowerCase();
      list = list.filter(
        (c) =>
          c.title.toLowerCase().includes(q) ||
          c.code.toLowerCase().includes(q) ||
          c.description.toLowerCase().includes(q) ||
          c.instructor.toLowerCase().includes(q) ||
          c.category.toLowerCase().includes(q)
      );
    }

    if (options?.sortBy) {
      const order = options.sortOrder === 'desc' ? -1 : 1;
      list.sort((a, b) => {
        if (options.sortBy === 'fee') return (a.fee - b.fee) * order;
        if (options.sortBy === 'availableSeats') return (a.availableSeats - b.availableSeats) * order;
        if (options.sortBy === 'startDate') return a.startDate.localeCompare(b.startDate) * order;
        return a.title.localeCompare(b.title) * order;
      });
    }

    return list;
  }

  public getCourseById(id: string): Course | undefined {
    return this.data.courses.find((c) => c.id === id || c.code.toLowerCase() === id.toLowerCase());
  }

  public createCourse(course: Course): Course {
    this.data.courses.push(course);
    this.persist();
    return course;
  }

  public updateCourse(id: string, updates: Partial<Course>): Course | undefined {
    const idx = this.data.courses.findIndex((c) => c.id === id);
    if (idx === -1) return undefined;
    this.data.courses[idx] = {
      ...this.data.courses[idx],
      ...updates,
      updatedAt: new Date().toISOString(),
    };
    this.persist();
    return this.data.courses[idx];
  }

  public deleteCourse(id: string): boolean {
    const idx = this.data.courses.findIndex((c) => c.id === id);
    if (idx === -1) return false;
    this.data.courses.splice(idx, 1);
    this.persist();
    return true;
  }

  // Reservation queries
  public getReservations(options?: {
    studentId?: string;
    courseId?: string;
    status?: string;
    search?: string;
  }): Reservation[] {
    let list = [...this.data.reservations];

    if (options?.studentId) {
      list = list.filter((r) => r.studentId === options.studentId);
    }

    if (options?.courseId) {
      list = list.filter((r) => r.courseId === options.courseId);
    }

    if (options?.status && options.status !== 'all') {
      list = list.filter((r) => r.reservationStatus === options.status);
    }

    if (options?.search) {
      const q = options.search.toLowerCase();
      list = list.filter(
        (r) =>
          r.confirmationCode.toLowerCase().includes(q) ||
          r.courseTitle?.toLowerCase().includes(q) ||
          r.courseCode?.toLowerCase().includes(q) ||
          r.studentName?.toLowerCase().includes(q) ||
          r.studentEmail?.toLowerCase().includes(q)
      );
    }

    // Sort newest first
    list.sort((a, b) => new Date(b.reservedAt).getTime() - new Date(a.reservedAt).getTime());
    return list;
  }

  public getReservationById(id: string): Reservation | undefined {
    return this.data.reservations.find(
      (r) => r.id === id || r.confirmationCode.toLowerCase() === id.toLowerCase()
    );
  }

  // ATOMIC RESERVATION WORKFLOW
  public async reserveSeatAtomically(
    student: User,
    courseId: string
  ): Promise<{ success: boolean; reservation?: Reservation; error?: string; status: number }> {
    const release = await dbMutex.acquire();
    try {
      const course = this.data.courses.find((c) => c.id === courseId);
      if (!course) {
        return { success: false, error: 'Course not found in catalogue.', status: 404 };
      }

      if (course.status !== 'published') {
        return { success: false, error: 'Course is not currently open or published for reservations.', status: 400 };
      }

      // Business Rule: Check seat count
      if (course.availableSeats <= 0) {
        return { success: false, error: 'Course has reached full capacity. No available seats remaining.', status: 409 };
      }

      // Business Rule: Prevent duplicate active reservation for same student + course
      const existing = this.data.reservations.find(
        (r) => r.studentId === student.id && r.courseId === course.id && r.reservationStatus === 'active'
      );
      if (existing) {
        return {
          success: false,
          error: `You already have an active reservation (${existing.confirmationCode}) for this course.`,
          status: 409,
        };
      }

      // Atomic seat decrement
      course.availableSeats = Math.max(0, course.availableSeats - 1);
      course.updatedAt = new Date().toISOString();

      // Generate unique reservation ID
      const randomPart = Math.floor(10000 + Math.random() * 90000).toString();
      const uniqueCode = `RES-2026-${randomPart}`;
      const reservationId = `res_${Date.now()}_${randomPart}`;

      const newReservation: Reservation = {
        id: reservationId,
        confirmationCode: uniqueCode,
        studentId: student.id,
        studentName: student.fullName,
        studentEmail: student.email,
        courseId: course.id,
        courseCode: course.code,
        courseTitle: course.title,
        courseCategory: course.category,
        courseSchedule: course.schedule,
        courseStartDate: course.startDate,
        courseFee: course.fee,
        reservationStatus: 'active',
        reservedAt: new Date().toISOString(),
      };

      this.data.reservations.push(newReservation);

      // Audit Log
      this.data.auditLogs.unshift({
        id: `log_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
        userId: student.id,
        userEmail: student.email,
        userRole: student.role,
        action: 'RESERVATION_CREATED',
        entityType: 'reservation',
        entityId: newReservation.id,
        details: `Student ${student.fullName} reserved seat in ${course.code} ${course.title}. Available seats left: ${course.availableSeats}.`,
        timestamp: new Date().toISOString(),
      });

      this.persist();

      return { success: true, reservation: newReservation, status: 201 };
    } finally {
      release();
    }
  }

  // ATOMIC CANCELLATION WORKFLOW
  public async cancelReservationAtomically(
    reservationId: string,
    requestedByUser: User,
    reason?: string
  ): Promise<{ success: boolean; reservation?: Reservation; error?: string; status: number }> {
    const release = await dbMutex.acquire();
    try {
      const reservation = this.data.reservations.find(
        (r) => r.id === reservationId || r.confirmationCode === reservationId
      );
      if (!reservation) {
        return { success: false, error: 'Reservation record not found.', status: 404 };
      }

      // Ownership authorization check
      if (requestedByUser.role !== 'admin' && reservation.studentId !== requestedByUser.id) {
        return { success: false, error: 'Unauthorized: You may only cancel your own reservations.', status: 403 };
      }

      // Check if already cancelled
      if (reservation.reservationStatus === 'cancelled') {
        return { success: false, error: 'Reservation has already been cancelled previously.', status: 400 };
      }

      if (reservation.reservationStatus === 'completed') {
        return { success: false, error: 'Completed courses cannot be cancelled.', status: 400 };
      }

      // Mark cancelled
      reservation.reservationStatus = 'cancelled';
      reservation.cancelledAt = new Date().toISOString();
      reservation.cancellationReason = reason || 'Cancelled by user request.';

      // Atomically restore capacity
      const course = this.data.courses.find((c) => c.id === reservation.courseId);
      if (course) {
        // Enforce boundary: never exceed total capacity
        course.availableSeats = Math.min(course.capacity, course.availableSeats + 1);
        course.updatedAt = new Date().toISOString();
      }

      // Audit Log
      this.data.auditLogs.unshift({
        id: `log_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
        userId: requestedByUser.id,
        userEmail: requestedByUser.email,
        userRole: requestedByUser.role,
        action: 'RESERVATION_CANCELLED',
        entityType: 'reservation',
        entityId: reservation.id,
        details: `Reservation ${reservation.confirmationCode} cancelled by ${requestedByUser.fullName} (${requestedByUser.role}). Seat restored in course ${reservation.courseCode || reservation.courseId}.`,
        timestamp: new Date().toISOString(),
      });

      this.persist();

      return { success: true, reservation, status: 200 };
    } finally {
      release();
    }
  }

  // Audit Logs
  public getAuditLogs(limit = 100): AuditLog[] {
    return this.data.auditLogs.slice(0, limit);
  }

  public addAuditLog(log: Omit<AuditLog, 'id' | 'timestamp'>): void {
    this.data.auditLogs.unshift({
      ...log,
      id: `log_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      timestamp: new Date().toISOString(),
    });
    this.persist();
  }

  // Stats calculation
  public getStats(): AdminStats {
    const totalCourses = this.data.courses.length;
    const publishedCourses = this.data.courses.filter((c) => c.status === 'published').length;
    const totalStudents = this.data.users.filter((u) => u.role === 'student').length;
    const activeReservations = this.data.reservations.filter((r) => r.reservationStatus === 'active').length;
    const completedReservations = this.data.reservations.filter((r) => r.reservationStatus === 'completed').length;
    const cancelledReservations = this.data.reservations.filter((r) => r.reservationStatus === 'cancelled').length;

    let totalCapacity = 0;
    let totalAvailableSeats = 0;
    let fullCoursesCount = 0;

    for (const c of this.data.courses) {
      totalCapacity += c.capacity;
      totalAvailableSeats += c.availableSeats;
      if (c.availableSeats === 0) {
        fullCoursesCount++;
      }
    }

    // Revenue calculation from active reservations
    const estimatedRevenue = this.data.reservations
      .filter((r) => r.reservationStatus === 'active' || r.reservationStatus === 'completed')
      .reduce((sum, r) => sum + (r.courseFee || 0), 0);

    // Category breakdown
    const categoryMap = new Map<string, { courses: number; reservations: number }>();
    for (const c of this.data.courses) {
      const cur = categoryMap.get(c.category) || { courses: 0, reservations: 0 };
      cur.courses += 1;
      categoryMap.set(c.category, cur);
    }
    for (const r of this.data.reservations) {
      if (r.reservationStatus === 'active' && r.courseCategory) {
        const cur = categoryMap.get(r.courseCategory) || { courses: 0, reservations: 0 };
        cur.reservations += 1;
        categoryMap.set(r.courseCategory, cur);
      }
    }

    const categoryBreakdown = Array.from(categoryMap.entries()).map(([category, val]) => ({
      category,
      courses: val.courses,
      reservations: val.reservations,
    }));

    const capacityUtilization =
      totalCapacity > 0 ? Math.round(((totalCapacity - totalAvailableSeats) / totalCapacity) * 100) : 0;

    return {
      totalCourses,
      publishedCourses,
      totalStudents,
      activeReservations,
      completedReservations,
      cancelledReservations,
      totalAvailableSeats,
      totalCapacity,
      fullCoursesCount,
      estimatedRevenue,
      categoryBreakdown,
      capacityUtilization,
    };
  }

  // Lab Test Cases
  public getTestCases(): LabTestCase[] {
    return this.data.testCases;
  }

  public updateTestCase(id: string, updates: Partial<LabTestCase>): LabTestCase | undefined {
    const idx = this.data.testCases.findIndex((t) => t.id === id);
    if (idx === -1) return undefined;
    this.data.testCases[idx] = { ...this.data.testCases[idx], ...updates };
    this.persist();
    return this.data.testCases[idx];
  }

  public bulkUpdateTestCases(results: { id: string; status: 'Pass' | 'Fail'; actualResult: string; executionDate: string }[]): void {
    for (const res of results) {
      const tc = this.data.testCases.find((t) => t.id === res.id);
      if (tc) {
        tc.status = res.status;
        tc.actualResult = res.actualResult;
        tc.executionDate = res.executionDate;
      }
    }
    this.persist();
  }
}

export const db = new Database();
