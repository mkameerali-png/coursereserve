import { describe, it, expect, beforeEach } from 'vitest';
import { db } from '../server/db';
import { 
  validateEmailFormat, 
  validatePasswordStrength, 
  validateCoursePayload, 
  evaluateReservationEligibility 
} from '../server/validation';
import { User, Course } from '../src/types/index';

describe('CourseReserve — Software Engineering Unit & Integration Tests', () => {
  beforeEach(() => {
    db.resetToSeed();
  });

  describe('1. Input & Security Validation (Unit)', () => {
    it('UT-001: should validate RFC 5322 email formats correctly', () => {
      expect(validateEmailFormat('student@college.edu').valid).toBe(true);
      expect(validateEmailFormat('alex.rivera+lab@ac.in').valid).toBe(true);
      expect(validateEmailFormat('not-an-email').valid).toBe(false);
      expect(validateEmailFormat('@college.edu').valid).toBe(false);
      expect(validateEmailFormat('missing@domain').valid).toBe(false);
    });

    it('UT-002: should enforce password complexity rules', () => {
      const weak = validatePasswordStrength('weak');
      expect(weak.valid).toBe(false);
      expect(weak.errors.length).toBeGreaterThan(0);

      const strong = validatePasswordStrength('SecurePass2026!');
      expect(strong.valid).toBe(true);
      expect(strong.score).toBeGreaterThanOrEqual(4);
    });

    it('UT-003: should validate course creation payloads', () => {
      const invalid = validateCoursePayload({ title: '', fee: -10, capacity: 0 });
      expect(invalid.valid).toBe(false);

      const valid = validateCoursePayload({
        title: 'New AI Course',
        code: 'CS-499',
        category: 'Artificial Intelligence',
        instructor: 'Dr. Turing',
        fee: 300,
        capacity: 25,
        startDate: '2026-12-01',
      });
      expect(valid.valid).toBe(true);
    });
  });

  describe('2. Course Reservation Workflow & Eligibility (Integration & White-Box)', () => {
    it('IT-001: should atomically decrement seat count on valid reservation', async () => {
      const student: User = {
        id: 'test_std_01',
        fullName: 'Test Student',
        email: 'test_std@college.edu',
        role: 'student',
        createdAt: new Date().toISOString(),
      };

      const courseBefore = db.getCourseById('crs_101');
      expect(courseBefore).toBeDefined();
      const seatsBefore = courseBefore!.availableSeats;

      const res = await db.reserveSeatAtomically(student, 'crs_101');
      expect(res.success).toBe(true);
      expect(res.reservation).toBeDefined();
      expect(res.reservation!.confirmationCode).toMatch(/^RES-2026-\d{5}$/);

      const courseAfter = db.getCourseById('crs_101');
      expect(courseAfter!.availableSeats).toBe(seatsBefore - 1);
    });

    it('IT-002: should restore capacity exactly once upon valid cancellation', async () => {
      const student: User = {
        id: 'test_std_02',
        fullName: 'Test Student Two',
        email: 'test_std2@college.edu',
        role: 'student',
        createdAt: new Date().toISOString(),
      };

      const courseBefore = db.getCourseById('crs_101');
      const seatsBefore = courseBefore!.availableSeats;

      const res = await db.reserveSeatAtomically(student, 'crs_101');
      expect(res.success).toBe(true);

      const cancelRes = await db.cancelReservationAtomically(res.reservation!.id, student, 'Change of mind');
      expect(cancelRes.success).toBe(true);
      expect(cancelRes.reservation!.reservationStatus).toBe('cancelled');

      const courseRestored = db.getCourseById('crs_101');
      expect(courseRestored!.availableSeats).toBe(seatsBefore);
    });

    it('IT-003: should reject duplicate active reservations for same course', async () => {
      const student: User = {
        id: 'test_std_03',
        fullName: 'Test Student Three',
        email: 'test_std3@college.edu',
        role: 'student',
        createdAt: new Date().toISOString(),
      };

      const res1 = await db.reserveSeatAtomically(student, 'crs_101');
      expect(res1.success).toBe(true);

      const res2 = await db.reserveSeatAtomically(student, 'crs_101');
      expect(res2.success).toBe(false);
      expect(res2.status).toBe(409);
      expect(res2.error).toContain('already have an active reservation');
    });

    it('IT-004: should reject reservation if course has zero available seats', async () => {
      const student: User = {
        id: 'test_std_04',
        fullName: 'Test Student Four',
        email: 'test_std4@college.edu',
        role: 'student',
        createdAt: new Date().toISOString(),
      };

      // CS-301 is seeded with 0 available seats
      const res = await db.reserveSeatAtomically(student, 'crs_301');
      expect(res.success).toBe(false);
      expect(res.status).toBe(409);
      expect(res.error).toContain('full capacity');
    });

    it('IT-005: should serialize concurrent requests and prevent overbooking (ACID Mutex)', async () => {
      // Course with only 1 seat
      const singleSeatCourse: Course = {
        id: 'crs_concurrency_race',
        code: 'RACE-01',
        title: 'Single Seat Race Course',
        description: 'Test single seat concurrency',
        category: 'Software Engineering',
        instructor: 'Dr. Concurrency',
        duration: '2 Weeks',
        fee: 100,
        startDate: '2026-12-01',
        schedule: 'TBA',
        capacity: 1,
        availableSeats: 1,
        status: 'published',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      db.createCourse(singleSeatCourse);

      const clients: User[] = Array.from({ length: 5 }, (_, i) => ({
        id: `concur_client_${i}`,
        fullName: `Concur Client ${i}`,
        email: `concur_${i}@college.edu`,
        role: 'student',
        createdAt: new Date().toISOString(),
      }));

      // Fire 5 requests simultaneously
      const results = await Promise.all(
        clients.map((c) => db.reserveSeatAtomically(c, singleSeatCourse.id))
      );

      const successes = results.filter((r) => r.success);
      const failures = results.filter((r) => !r.success);

      expect(successes.length).toBe(1);
      expect(failures.length).toBe(4);

      const courseFinal = db.getCourseById(singleSeatCourse.id);
      expect(courseFinal!.availableSeats).toBe(0);
    });

    it('IT-006: should prevent unauthorized cancellation across students', async () => {
      const owner: User = { id: 'usr_owner', fullName: 'Owner', email: 'owner@col.edu', role: 'student', createdAt: '' };
      const intruder: User = { id: 'usr_intruder', fullName: 'Intruder', email: 'intruder@col.edu', role: 'student', createdAt: '' };

      const res = await db.reserveSeatAtomically(owner, 'crs_101');
      expect(res.success).toBe(true);

      const cancelAttempt = await db.cancelReservationAtomically(res.reservation!.id, intruder);
      expect(cancelAttempt.success).toBe(false);
      expect(cancelAttempt.status).toBe(403);
    });
  });

  describe('3. White-Box Decision Logic Coverage', () => {
    it('WBT-001: statement and branch coverage on evaluateReservationEligibility()', () => {
      const std: User = { id: 'std_wb', fullName: 'WB', email: 'wb@col.edu', role: 'student', createdAt: '' };
      const crs: Course = {
        id: 'c_wb',
        code: 'WB-01',
        title: 'WB',
        description: 'D',
        category: 'Cat',
        instructor: 'I',
        duration: '1w',
        fee: 50,
        startDate: '2026-11-20',
        schedule: 'S',
        capacity: 10,
        availableSeats: 5,
        status: 'published',
        createdAt: '',
        updatedAt: '',
      };

      // Unauthenticated branch
      const resUnauth = evaluateReservationEligibility(null, crs);
      expect(resUnauth.eligible).toBe(false);
      expect(resUnauth.reasonCode).toBe('UNAUTHENTICATED');

      // Unpublished branch
      const resUnpub = evaluateReservationEligibility(std, { ...crs, status: 'unpublished' });
      expect(resUnpub.eligible).toBe(false);
      expect(resUnpub.reasonCode).toBe('COURSE_UNAVAILABLE');

      // Zero seats branch
      const resZero = evaluateReservationEligibility(std, { ...crs, availableSeats: 0 });
      expect(resZero.eligible).toBe(false);
      expect(resZero.reasonCode).toBe('COURSE_FULL');

      // All criteria met
      const resSuccess = evaluateReservationEligibility(std, crs, [], '2026-10-10');
      expect(resSuccess.eligible).toBe(true);
      expect(resSuccess.reasonCode).toBe('SUCCESS');
    });
  });
});
